import argparse,datetime,gzip,hashlib,json,os,pathlib,re,subprocess,sys,time
P=pathlib.Path('/dev/shm/pachka-1510-3');R=P/'repo';D=pathlib.Path('/workspace/scratch/pachka-1510-3-proof');S=R/'джерела'
SHA='ff565d5dca86edfb1171ae9675a7432523635740';TREE='77e63dae55bd5036dcff5e4883591757288e4ad7';MAIN='47ac855c51b249c6112f0ba0ca64924a50bc32e4'
E={**os.environ,'GIT_NO_LAZY_FETCH':'1','TMPDIR':str(P/'tmp'),'PYTHONDONTWRITEBYTECODE':'1','PYTHONPYCACHEPREFIX':str(P/'pycache'),'NODE_PATH':'/workspace/kod-shi-data/джерела/node_modules'}
def git(*a,input=None):return subprocess.check_output(['git','--git-dir='+str(R/'.git'),*a],env=E,input=input)
def sha256(b):return hashlib.sha256(b).hexdigest()
def gitblob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def save(name,data):
 raw=json.dumps(data,ensure_ascii=False,indent=2).encode();(P/name).write_bytes(raw)
 try:(D/name).write_bytes(raw)
 except OSError as exc:
  if exc.errno!=28:raise
  with (P/'durable-mirror-errors.log').open('a') as f:f.write(str(exc)+'\n')
def stages():
 syntax="import pathlib,py_compile,subprocess,sys; p=pathlib.Path('.'); fs=[x for x in p.rglob('*') if x.is_file() and 'node_modules' not in x.parts]; py=[x for x in fs if x.suffix=='.py']; js=[x for x in fs if x.suffix=='.js']; [py_compile.compile(str(x),doraise=True) for x in py]; rs=[subprocess.run(['node','--check',str(x)]).returncode for x in js]; print('Синтаксис Python',len(py),'JS',len(js),'збоїв',sum(x!=0 for x in rs)); sys.exit(any(rs))"
 split="import pathlib,subprocess,sys; fs=sorted(pathlib.Path('проби').glob('поділ_*_ast.py')); rs=[subprocess.run([sys.executable,str(f)]).returncode for f in fs]; print('Проби поділу',len(fs),'ВПАЛО',sum(x!=0 for x in rs)); sys.exit(any(rs))"
 prep="import чистка_каталогу as ч,feed as Ф; print('фід:',ч.забезпечити_чистим('каталог_повний.xml')); print('фікстура:',Ф.каталог_на_диску('каталог_brief.xml'))"
 return [('01-синтаксис',[sys.executable,'-c',syntax]),('02-поділ',[sys.executable,'-c',split]),('03-каталоги',[sys.executable,'-c',prep]),('04-дим',[sys.executable,'стенд_знімок.py','--дим']),('05-живий-шлях',[sys.executable,'тест_живого_шляху.py']),('06-протокол',[sys.executable,'тест_протоколу.py']),('07-гейти',[sys.executable,'прилади/розділи_гейтів.py']),('08-контракти',[sys.executable,'audit_contracts.py']),('09-показ',['node','тест_показу.js']),('10-міст',['node','тест_мосту.js']),('11-досяжність',[sys.executable,'досяжність.py'])]
def prepare():
 assert git('rev-parse',SHA+'^{tree}').decode().strip()==TREE
 expected=json.loads((P/'inputs-expected.json').read_text());assert sum(x['path'].startswith('джерела/') for x in expected)==1537
 for h in [MAIN,'dae4c840070d597f00c47aa921272dfbcad1d40d','4f57cf74b95e9105ecbdb31d8948657ce7f07435','1e1da4d1f3e4054ac288856ed96ed11d54e7561c']:git('merge-base','--is-ancestor',h,SHA)
 provenance={'pr':1078,'sha':SHA,'tree':TREE,'main':MAIN,'sources':{'1049':'dae4c840070d597f00c47aa921272dfbcad1d40d','1058':'4f57cf74b95e9105ecbdb31d8948657ce7f07435','1067':'1e1da4d1f3e4054ac288856ed96ed11d54e7561c'},'inputs_sha256':sha256((P/'inputs-expected.json').read_bytes()),'source_entries':1537,'workflow_blob':next(x['sha'] for x in expected if x['path']=='.github/workflows/zbirka.yml'),'fixture_root_blob':'04d84f5556cf4654f10a594128c3531530773649','previous_sha':'5b31bf178dad949109e3c2b769b0892e20166616','previous_stages_started':0,'existing_native_actor':'/root/review_updates_1045_1056','existing_native_comment':None,'existing_final_comment':None,'existing_native_proof':'PENDING_NEW_COMPOSITION_NATIVE' ,'commands':dict(stages()),'status':'PREPARED_WAIT_DIRECT_HEAVY_TOKEN','battery_started':False}
 save('battery-provenance.json',provenance);save('inputs-expected.json',expected)
 print('ПІДГОТОВЛЕНО: лише provenance/команди, батарея не запускалася',SHA,flush=True)
def export():
 expected=json.loads((P/'inputs-expected.json').read_text());verified=[]
 for x in expected:
  dst=R/x['path'];dst.parent.mkdir(parents=True,exist_ok=True)
  if x['path']=='каталог_повний.xml.gz':
   shared=pathlib.Path('/workspace/kod-shi-data/каталог_повний.xml.gz');assert gitblob(shared.read_bytes())==x['sha'];
   if not dst.exists():dst.symlink_to(shared)
  elif not dst.exists() or gitblob(dst.read_bytes())!=x['sha']:
   data=git('cat-file','blob',x['sha']);assert gitblob(data)==x['sha'];dst.write_bytes(data)
  assert gitblob(dst.read_bytes())==x['sha'],x['path'];verified.append({**x,'sha256':sha256(dst.read_bytes())})
 git('update-ref','refs/heads/codex/pachka-1510-3',SHA);git('symbolic-ref','HEAD','refs/heads/codex/pachka-1510-3')
 save('inputs-verified.json',verified)
 assert (pathlib.Path(E['NODE_PATH'])/'jsdom').is_dir() and (pathlib.Path(E['NODE_PATH'])/'fake-indexeddb').is_dir()
 local_deps=S/'node_modules'
 if not local_deps.exists():local_deps.symlink_to(pathlib.Path(E['NODE_PATH']),target_is_directory=True)
 assert local_deps.is_symlink() and local_deps.resolve()==pathlib.Path(E['NODE_PATH']).resolve()
 return sha256(json.dumps(verified,ensure_ascii=False,sort_keys=True).encode())
def run(token_path):
 token=json.loads(pathlib.Path(token_path).read_text());assert token['holder']=='build_batch_1510_3' and token['sha']==SHA and token['authorized_by'] in ['root','broken_5571_first','review_updates_1045_1056'],token
 save('heavy-token.json',token)
 state_path=P/'battery-checkpoint-current.json';state=json.loads(state_path.read_text()) if state_path.exists() else {'sha':SHA,'tree':TREE,'stages':{},'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 assert state['sha']==SHA and state['tree']==TREE
 if 'verified_input_sha256' not in state:state['verified_input_sha256']=export();save('battery-checkpoint-current.json',state)
 for name,command in stages():
  old=state['stages'].get(name,{})
  if old.get('status')=='completed':assert old['rc']==0,('Потрібне явне рішення щодо завершеного збою',name,old);continue
  log=P/(name+'.log');rec={'status':'running','sha':SHA,'input_sha256':state['verified_input_sha256'],'command':command,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'log':log.name};state['stages'][name]=rec;state['current']=name;save('battery-checkpoint-current.json',state);print('СТАРТ',name,flush=True);t=time.monotonic()
  with log.open('ab' if old else 'wb') as f:
   if old:f.write(b'\nRESUME ONLY UNFINISHED STAGE\n')
   rc=subprocess.call(command,cwd=S,env=E,stdout=f,stderr=subprocess.STDOUT)
  if name=='11-досяжність' and rc==0:
   hits=re.findall(r'«НІХТО» = (\d+)',log.read_text());assert hits and hits[-1]=='0',hits
  rec.update(status='completed',rc=rc,seconds=round(time.monotonic()-t,2),log_sha256=sha256(log.read_bytes()));state['current']=None;save('battery-checkpoint-current.json',state)
  try:
   with gzip.open(D/(log.name+'.gz'),'wb') as f:f.write(log.read_bytes())
  except OSError as exc:
   if exc.errno!=28:raise
   with (P/'durable-mirror-errors.log').open('a') as f:f.write(str(exc)+'\n')
  print('КІНЕЦЬ',name,'rc',rc,flush=True)
  if rc:raise SystemExit(rc)
 state['status']='COMPLETED';state['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save('battery-checkpoint-current.json',state);print('БАТАРЕЯ ЗАВЕРШЕНА',SHA,flush=True)
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('action',choices=['prepare','run']);a.add_argument('--token');v=a.parse_args();P.mkdir(exist_ok=True);D.mkdir(exist_ok=True)
 if v.action=='prepare':prepare()
 else:assert v.token;run(v.token)
