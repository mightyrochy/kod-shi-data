import subprocess,pathlib,os,json,time
p=pathlib.Path('/dev/shm/worker5634');r=p/'repo/джерела';e={**os.environ,'TMPDIR':str(p/'tmp'),'NODE_PATH':str(r/'node_modules'),'PYTHONDONTWRITEBYTECODE':'1','GIT_NO_LAZY_FETCH':'1'}
checks=[['python3','стенд_знімок.py','--дим'],['python3','тест_живого_шляху.py'],['python3','тест_протоколу.py'],['python3','прилади/розділи_гейтів.py'],['python3','audit_contracts.py'],['node','тест_показу.js']]
state=[]
for i,cmd in enumerate(checks):
 log=p/f'батарея-{i}.log';t=time.time()
 with log.open('w') as f: rc=subprocess.run(cmd,cwd=r,env=e,stdout=f,stderr=subprocess.STDOUT).returncode
 state.append({'команда':cmd,'код':rc,'секунд':round(time.time()-t,2),'журнал':str(log)})
 (p/'батарея-стан.json').write_text(json.dumps(state,ensure_ascii=False,indent=2))
print(json.dumps(state,ensure_ascii=False))
