import os,sys,re,gzip,json,hashlib,copy,tempfile,xml.etree.ElementTree as ET
os.chdir('/dev/shm/worker5641/repo/джерела');sys.path.insert(0,'.')
import feed as Ф
from композитор_придатні import _придатні
к=Ф._прочитати_каталог('каталог_повний.xml',ліміт_фото=0)['каталог'];до=json.load(open('/dev/shm/worker5641/before.json'))
assert json.loads(json.dumps([{k:v for k,v in r.items() if k!='available'} for r in к]))==до
ні=set(re.findall(r'<offer id="([^"]+)" available="false"',gzip.open('../каталог_повний.xml.gz','rt',encoding='utf-8').read()))
пул,відс=_придатні(к,[],[],{})
print('ПІСЛЯ',len(к),len(ні),len(ні&{str(r['id']).split('@')[0] for r in к}),sum('available' in r for r in к))
print('недоступні у пулі',sum(r['available'] is False for r in пул),'пул',len(пул),'відсів',відс)
print('інші поля JSON рівні',len(к))
root=ET.parse('каталог_повний.xml').getroot(); offers=root.find('.//offers');by={r['id'] for r in к}
seed=next(o for o in offers if o.get('id') in by or any(i.split('@')[0]==o.get('id') for i in by))
for o in list(offers):offers.remove(o)
for i,a in enumerate(('true','false',None)):
 o=copy.deepcopy(seed);o.set('id','availability-'+str(i))
 if a is None:o.attrib.pop('available',None)
 else:o.set('available',a)
 q=o.find('stock_quantity')
 if q is not None:o.remove(q)
 offers.append(o)
f=tempfile.NamedTemporaryFile(suffix='.xml',delete=False);f.close();ET.ElementTree(root).write(f.name,encoding='utf-8')
try:
 records=Ф._прочитати_каталог(f.name,ліміт_фото=0)['каталог'];states={r['id'].split('@')[0]:r['available'] for r in records}
 assert states=={'availability-0':True,'availability-1':False,'availability-2':None},states
 pool,_=_придатні(records,[],[],{});assert {r['available'] for r in pool}=={True,None}
 print('producer → record → composer true/false/unknown',states,'залишились',[r['available'] for r in pool])
finally:os.unlink(f.name)
print('raw bytes',len(gzip.open('../каталог_повний.xml.gz','rb').read()))
