import os,sys,json,gzip,re,hashlib,importlib.util,copy,tempfile,xml.etree.ElementTree as ET,contextlib,io,socket
from pathlib import Path
root=Path('/dev/shm/qa5641'); src=root/'джерела'; os.chdir(src);sys.path.insert(0,str(src))
def deny(*a,**k):raise AssertionError('Мережа не дозволена в QA')
socket.create_connection=deny
import фід_каталог as after
from композитор_придатні import _придатні
sp=importlib.util.spec_from_file_location('before_qa',src/'producer_before_qa.py');before=importlib.util.module_from_spec(sp);sp.loader.exec_module(before)
def catalog(m,path):
 with contextlib.redirect_stdout(io.StringIO()):return m._прочитати_каталог(str(path),ліміт_фото=0)['каталог']
raw=gzip.open('/dev/shm/worker5641/repo/каталог_повний.xml.gz','rb').read(); rawtree=ET.fromstring(raw); rawoffers=rawtree.findall('.//offer'); clean=src/'каталог_повний.xml'
raw_false={o.get('id') for o in rawoffers if o.get('available')=='false'}
print('Сирий gzip:',len(raw),'байтів;',len(rawoffers),'оферів;',len(raw_false),'false')
tree=ET.parse(clean); print('Очищений вхід:',clean.stat().st_size,'байтів;',len(tree.findall('.//offer')),'оферів; SHA256',hashlib.sha256(clean.read_bytes()).hexdigest())
a=catalog(before,clean); b=catalog(after,clean)
for name,c in [('ДО',a),('ПІСЛЯ',b)]:
 pool,drop=_придатні(c,[],[],{})
 print(name,len(c),len(raw_false),len(raw_false&{str(r['id']).split('@')[0] for r in c}),sum('available' in r for r in c),'пул',len(pool),'raw false в пулі',len(raw_false&{str(r['id']).split('@')[0] for r in pool}), 'відсів',drop)
assert len(a)==len(b)==11887
norm=lambda v:json.loads(json.dumps(v,ensure_ascii=False))
assert norm(a)==norm([{k:v for k,v in r.items() if k!='available'} for r in b])
print('Інші JSON поля рівні:',len(b))
assert all(type(r['available']) in (bool,type(None)) for r in b)
assert sum(r['available'] is False for r in b)==1308
pa,_=_придатні(a,[],[],{});pb,_=_придатні(b,[],[],{})
assert {r['id'] for r in pb}=={r['id'] for r in pa if next(x for x in b if x['id']==r['id'])['available'] is not False}
print('Збережені усі true/unknown записи; видалені тільки False')
offers=tree.find('.//offers'); ids={r['id'].split('@')[0] for r in b}; seed=next(o for o in offers if o.get('id') in ids)
for o in list(offers):offers.remove(o)
cases=[('true',None,True),('false',None,False),(None,None,None),('unrecognized',None,None),('',None,False),('1',None,True),('0',None,False),('true','0',False)]
for n,(state,stock,expected) in enumerate(cases):
 o=copy.deepcopy(seed);o.set('id','qa5641-'+str(n));o.attrib.pop('available',None)
 if state is not None:o.set('available',state)
 for q in o.findall('stock_quantity'):o.remove(q)
 if stock is not None:ET.SubElement(o,'stock_quantity').text=stock
 offers.append(o)
fixture=root/'стани.xml';tree.write(fixture,encoding='utf-8')
rs=catalog(after,fixture);states={r['id'].split('@')[0]:r['available'] for r in rs}
expected={'qa5641-'+str(n):case[2] for n,case in enumerate(cases)}
assert states==expected,(states,expected)
passed,_=_придатні(rs,[],[],{})
assert {r['id'].split('@')[0] for r in passed}=={k for k,v in expected.items() if v is not False}
print('Вісім станів producer→record→composer:',states,'у пулі',[r['id'] for r in passed])
# Чинний reader приймає також старі записи без ключа.
assert _придатні([{'id':'missing'},{'id':'none','available':None},{'id':'true','available':True},{'id':'false','available':False}],[],[],{})[0]==[{'id':'missing'},{'id':'none','available':None},{'id':'true','available':True}]
print('Старі missing-key/None/True записи лишились; False відсіяно')
