import sys,os,json,contextlib,io
from pathlib import Path
p=Path('/dev/shm/qa5641/джерела');os.chdir(p);sys.path.insert(0,str(p))
import таблиця_каталогу as T,фід_розбір as F,фід_каталог as K
fixture='/dev/shm/qa5641/стани.xml'
with contextlib.redirect_stdout(io.StringIO()):
 table=T.зібрати(fixture)
 offers,_=F.читати_yml(fixture)
 restored=T.відновити(table,offers)
 direct=K._прочитати_каталог(fixture,ліміт_фото=0)
assert T.однакові(restored,direct)
states={x['id'].split('@')[0]:x['available'] for x in restored['каталог']}
assert set(states.values())=={True,False,None}
key_after=T.ключ(fixture,str(p))
key_before=T.ключ(fixture,str(p),байти_модулів={'фід_каталог':(p/'producer_before_qa.py').read_bytes()})
assert key_after!=key_before
assert [k for k,v in key_after['код'].items() if v!=key_before['код'][k]]==['фід_каталог']
print('Таблиця: producer→serialize→restore JSON рівні; 8 значень наявності збережено.',states)
print('Ключ кеша змінюється саме за фід_каталог; старий кеш не застосовується.')
