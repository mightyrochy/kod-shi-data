import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import path from 'node:path';

const p = '/workspace/scratch/n2-dual';
const get = name => fs.readFileSync(path.join('джерела/показ', name), 'utf8');
const extract = (file, name) => {
  const match = new RegExp('^(?:async )?function ' + name + '\\([\\s\\S]*?^\\}', 'm').exec(get(file));
  assert.ok(match, name);
  return match[0];
};
let повідомлення;
const ctx = vm.createContext({
  async модельП_блоки(блоки, модель, історія, заголовки) {
    повідомлення = [...історія, {role:'user', content:блоки}];
    заголовки.кадри = {дійшло:блоки.filter(б=>б.type==='image').length};
    return [];
  },
  блокиВТекст: () => '',
  збійМоделіЗВинятку: error => {throw error;},
});
const рядок=get('приміряння.js').match(/^const розмірЗапитуП = .*;$/m)[0];
vm.runInContext([рядок, extract('міст.js','підписатиКадри'), extract('ядро.js','відповідьМоделіЯдруП')].join('\n'),ctx);
for(const name of fs.readdirSync(p).filter(n=>n.endsWith('-messages.json')).sort()){
  const блоки=JSON.parse(fs.readFileSync(path.join(p,name),'utf8'));
  for(const {stage,attempt,text,photos,size} of блоки) {
    await ctx.відповідьМоделіЯдруП({фото:photos, модель:{max_tokens:4000,messages:[{role:'user',content:text}]}});
    ctx.повідомлення=повідомлення;
    const actual=vm.runInContext('розмірЗапитуП(повідомлення)',ctx);
    assert.equal(actual,size);
    if(name.startsWith('after')) assert.ok(actual<=396000, name);
    console.log(JSON.stringify({name,stage,attempt,photos:photos.length,actual}));
  }
}

const сбор = extract('ядро.js','зібратиОбразиЯдромП');
for (const [імʼя, відповідь, готові] of [
  ['late-budget', {збій:{частина:'запит',вид:'вікно_моделі',дані:{stage:'вибір'}},картки:[]}, 0],
  ['all-failed', {картки:[{рука:1,збій:{вид:'інше'}}]}, 0],
  ['mixed', {картки:[{рука:1,збій:{вид:'вікно_моделі'}},{рука:2,збій:null}]}, 1],
]) {
  let переклади=0, відмова=null, вхід;
  const бездія = () => {};
  const globals = vm.createContext({
    ЗБИРАННЯ_ЗАЙНЯТО_П:false, ЗБ:null, ТОКЕНИ_П:null, МОДЕЛІ_ПРОГОНУ:null,
    ВЕРСІЯ_ЯДРА_П:0, СЦ:{ід:'fixture'}, ПАСПОРТ_П:{}, ФІД_П:[], МАКС_ТОКЕНІВ_П:4000,
    МОДЕЛЬ_П:'fixture', МІСТ_П:{адреса:''}, НАЛАШТУВАННЯ_РУШІЯ_П:{},
    СТЕЛЯ_ЗАПИТУ_П:400000, ЗАПАС_ЗАПИТУ_П:4000, СПОСІБ_ВИБОРУ_П:'list',
    КОРОТКИЙ_ЗАПИС_П:false, ЧАСТИН_РУКИ_1_П:1, ЗБІРКА_ПОКАЗУ:'fixture',
    КАТАЛОГ_ПІДПИС_П:'fixture', ПІДПИС_БЕЗІМЕННОЇ_П:'fixture', П:null,
    зібратиВхід:()=>({}), резервВиходуКаналуП:()=>({}), показатиТокени:бездія,
    статусЗбиранняП:бездія, показатиЗбирання:бездія, поступЗміненоП:бездія,
    містП:(_,payload)=>{вхід=payload.вхід;return {кінець:true,звіт:[], ...відповідь};},
    відповідьМоделіЯдруП:()=>{throw Error('queued transport unexpectedly');},
    карткаЯдраНаЕкранП:к=>к, мовоюКарткуП:()=>{переклади++;},
    оголоситиВідмовуЗбиранняП:код=>{відмова=код;}, режим:бездія, рендер:бездія,
    показатиДіагноз:бездія, новийІдПрогону:()=>1, завершитиДіюЯдра:бездія,
    console:{error:e=>{throw e;}}
  });
  await vm.runInContext(сбор+'\nзібратиОбразиЯдромП()',globals);
  assert.equal(вхід.модель.межа_повідомлень,396000);
  assert.equal(globals.ЗБ.успіх,готові>0);
  assert.equal(переклади,готові);
  if(імʼя==='late-budget')assert.equal(відмова,'запит_понад_межу');
  console.log(JSON.stringify({імʼя,успіх:globals.ЗБ.успіх,переклади,відмова}));
}
