"""Challenge on saved R2 projections with local semantic replies. No scene runner or transport."""
from pathlib import Path
from hashlib import sha256
import json
import pickle
import socket
import sys
from unittest.mock import patch

from ядро import запит, протокол, річ, пул
from ядро.поняття import Збій
from ядро.тести import обвязка
from ядро.тести.тест_н2 import _запис, _відповідь

HERE = Path(__file__).resolve().parent
CACHE = HERE.parent / 'n2-4678-fibre' / 'catalogue.pkl'
TOKEN_LIMIT, TRANSPORT, PAGE, EXTRA = 25_334, 396_000, 4_000, 12_000
URL_FIXTURE = 'https://offline.invalid/fixture.png'

def guard(*_, **__):
    raise AssertionError('external transport is prohibited')
socket.socket = socket.getaddrinfo = socket.create_connection = guard

def wire(x):
    return json.dumps(x, ensure_ascii=False, separators=(',', ':'))
def hash_(x):
    return sha256(x if isinstance(x,bytes) else wire(x).encode()).hexdigest()
def read(path):
    return json.loads(path.read_text())
def value(x):
    return x.get('value') if isinstance(x,dict) else x
def save(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2)+'\n')
def wrap(text, photos):
    blocks=[]
    for f in photos:
        blocks += [{'type':'text','text':f"Catalogue photo for item {f['n']}:"},
                   {'type':'image','source':{'type':'url','url':f['url']}}]
    return [{'role':'user','content':blocks+[{'type':'text','text':text}]}]

def inputs(case, catalogue):
    p=read(HERE/f'{case}-profile.json')
    log=HERE/f'типове-{case}-обміни.jsonl'
    rows=[json.loads(x) for x in log.read_text().splitlines()]
    old=json.loads(rows[-1]['запит'])
    choice=json.loads(next(r['відповідь'] for r in rows if r['тип'].startswith('вибір палітри')))
    keys={'occasion':'нагода','role':'роль','month':'місяць','weekday':'день_тижня',
          'weather_band':'смуга_погоди','precipitation':'опади','formality':'ступінь_ошатності',
          'movement':'рух','walk_min':'дорога_пішки_хв','surface':'поверхня','duration_hours':'тривалість_год',
          'season':'пора','formality_range':'смуга_ошатності','light':'світло','salt':'сіль'}
    passport={dst:value(old['day'][src]) for src,dst in keys.items()
              if value(old['day'].get(src)) not in (None,'unknown','невідомо')}
    stage=old['day']['stages'][0]
    for src,dst in {'place':'місце','outdoors':'надворі','part_of_day':'частина_дня'}.items():
        if value(stage.get(src)) not in (None,'unknown','невідомо'):
            passport[dst]=value(stage[src])
    for src,dst in {'intent':'намір','goal':'мета','goal_priorities':'мета_важливо','goal_zones':'мета_зони',
                    'wishes':'бажання','refusals':'жорстке_ні'}.items():
        v=value(old['case'].get(src))
        if v not in (None,'unknown','невідомо',[]):
            passport[dst]=v
    profile={'в':'ВХІД-V1','джерело':'показ','колір':{'шкіра':p['skin'],'волосся':p['hair'],'очі':p['eyes'],'кільце':p['ring']},
             'мірки':{'зріст':p['мірки']['зріст'],'обхвати':{k:v for k,v in p['мірки'].items() if k!='зріст'}},
             'палітра':{'схема':choice['scheme']}}
    return dict(розмова=case, версія=old['version_of_day'], сід=3, дата='2026-11-25',
                паспорт=passport, профіль=profile, каталог=catalogue,
                перемикачі={'вибір':'list','запис':'повний','частин':1},
                модель={'вихід':PAGE,'надбавка_каналу':EXTRA,'канал':'worker','межа_повідомлень':TRANSPORT,'вікно':1_000_000})

def proof(mode, label, saved, count=1, *, with_photos=False, forced=None):
    entry={**saved,'розмова':label}
    journal=[]; queued=[]; frames=[]; calls={}; maps={}; captured=[]
    build,fit=запит.запит,запит._під_вікно
    def capture(*a,**k):
        out=fit(*a,**k)
        captured.append(out[0])
        return out
    def observe(stage, candidates, *a,**k):
        calls[stage]=calls.get(stage,0)+1
        start=len(captured)
        out=build(stage,candidates,*a,**k)
        if stage=='складання':
            maps.update({r['н']:r['ід'] for r in candidates.речі})
        item={'stage':stage,'attempt':k['спроба'],'request':not isinstance(out,Збій),
              'removed':None if isinstance(out,Збій) else out.знято,
              'size':out.дані if isinstance(out,Збій) else out.розмір}
        if len(captured)>start and not isinstance(out,Збій):
            msg=wrap(captured[-1],out.фото)
            size=len(wire(msg).encode('utf-16-le'))//2
            assert out.розмір.get('messages_utf16_units',size)==size
            item.update(messages_utf16=size, wire_sha256=hash_(msg))
            frames.append({'stage':stage,'attempt':k['спроба'],'text':captured[-1],'photos':out.фото,'size':size})
        journal.append(item)
        return out

    def stub(q):
        stage=q['вид']
        queued.append(stage)
        body=json.loads(q['модель']['messages'][0]['content'])
        if stage=='складання':
            by={}
            part=body['pool']; col=part['cols']
            available={r[col.index('n')] for r in part['rows']}
            for row in part['rows']:
                by.setdefault(row[col.index('kind')],[]).append(row[col.index('n')])
            outfits=[]
            if forced is not None:
                for i,ids in enumerate(forced,1):
                    addr={i:n for n,i in maps.items() if n in available}
                    outfits.append({'id':f'o{i}','items':[addr[r] for r in ids]})
            else:
                kinds=['dress'] if 'dress' in by else (['set'] if 'set' in by else ['top','bottom'])
                kinds=list(dict.fromkeys(kinds+body['required_kinds']+(['bag'] if 'bag' in by else [])))
                assert all(k in by for k in kinds), (mode,label,kinds,list(by))
                for i in range(count):
                    items=[by[k][i%len(by[k])] for k in kinds]
                    if not any(o['items']==items for o in outfits):
                        outfits.append({'id':f'o{len(outfits)+1}','items':items})
            return _відповідь(outfits=outfits)
        if stage=='ремонт':
            return _відповідь(outfits=[{'id':v['id'],'items':v['items']} for v in body['verdict']])
        if stage=='вибір':
            return _відповідь(chosen='o1')
        assert stage=='опис'
        ids=body['verdict'][0]['items']
        assert set(ids)=={r['n'] for r in body['outfit']['items']}
        desc=dict(_відповідь(text='Offline fixture.',about_items=[{'n':n,'text':'Offline item.'} for n in ids]),
                  фото=[f['n'] for f in q['фото']])
        return desc

    with patch.object(запит,'_під_вікно',side_effect=capture), patch.object(запит,'запит',side_effect=observe):
        v=обвязка.почати(протокол,entry)
        if v['запити'] and journal[0]['messages_utf16']>TRANSPORT:
            v=None
        if v is not None and not v['кінець']:
            v,_=обвязка.довезти(протокол,v,stub)
    card=next((k for k in (v or {}).get('картки',()) if k['рука']==1),{})
    successful=bool(card and not card['збій'] and card['речі'])
    if successful:
        desc=next(f for f in reversed(frames) if f['stage']=='опис')
        body=json.loads(desc['text'])
        assert card['образ']==card['вирок']==body['verdict'][0]['id']
        assert [maps[n] for n in body['verdict'][0]['items']]==[r['ід'] for r in card['речі']]
    save(HERE/f'{mode}-{label}-messages.json',frames)
    return {'input_sha256':hash_({**entry,'каталог':hash_(entry['каталог'])}), 'builds':calls,'queued':queued,
            'journal':journal,'ok_card':successful,'composition':[r['ід'] for r in card.get('речі',())],
            'failure':(v or {}).get('збій') or card.get('збій'), 'browser_preflight_would_refuse':v is None,
            'bad_records':sum(z.get('заява')=='bad_record' for z in (v or {}).get('звіт',()))}

def source_controls(cat):
    indexes={r['id']:r for r in cat}
    listed=indexes['ж-00487@stolyarchuk.com.ua']
    fibre=indexes['ж-00002@cultboutique.com.ua']
    seasonal=indexes['ж-05273@bella-bicchi.com']
    broken=read(HERE/'broken.json')
    rows={'list': listed,'string_variant':{**listed,'тканина_за_чим':'слово назви'},
          'fibre':fibre,'season':seasonal,'15647':{**indexes[broken['id']],**broken['поля']}}
    def take(row):
        r=річ.читати(row)
        p=пул.зібрати(__import__('ядро.поняття',fromlist=['Ситуація']).Ситуація(1,{},{}),1,3,[row])
        return {'id':r.ід,'fabric':запит._поле(r.поля['тканина']),
                'season':запит._поле(r.поля['сезон_тканини']),'item_errors':[z.поле for z in r.збої],
                'pool_rejections':p.відкинуто,'pool':len(p.речі)}
    return {key:take(r) for key,r in rows.items()}

if __name__=='__main__':
    mode=sys.argv[1]
    catalogue=pickle.loads(CACHE.read_bytes())
    proofset={'catalogue_sha256':hash_(CACHE.read_bytes()),'source':source_controls(catalogue),'cases':{}}
    out=HERE/f'{mode}-proof.json'
    for case in ('с3','с5','с8'):
        ent=inputs(case,catalogue)
        proofset['cases'][case]=proof(mode,case,ent)
        save(out,proofset)
    # An independently pinned small, unchanged request. Synthetic URLs prove
    # the photo wrapping and are never passed to a transport.
    small=[_запис('dress','сукня',тип='сукня',фото=[URL_FIXTURE]),
           _запис('shoe','взуття',тип='лофери',фото=[URL_FIXTURE])]
    inp=обвязка.вхід_с5(паспорт={'бажання':['Edge: quote " slash \\ Cyrillic колір 😀\n']},
                       каталог=small, модель={'вихід':PAGE,'надбавка_каналу':EXTRA,'канал':'worker','межа_повідомлень':TRANSPORT})
    proofset['cases']['small']=proof(mode,'small',inp)
    save(out,proofset)
