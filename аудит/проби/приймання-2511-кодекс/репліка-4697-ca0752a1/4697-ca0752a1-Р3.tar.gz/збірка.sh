#!/usr/bin/env bash
set -eu
package=$(cd -- "$(dirname -- "$0")" && pwd)
cd -- "$package/../дерево/джерела"
export GIT_NO_LAZY_FETCH=1 PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
export LYUSTERKO_CATALOG=повний
export LYUSTERKO_PYC_PYTHON=/tmp/liusterko-n2-build-artifacts/інструменти/pyodide-cpython.cjs
set +e
python3 build_артефакт.py . "$package/index.html" показ-повний > "$package/build.log" 2>&1
status=$?
printf '%s\n' "$status" > "$package/exit-code.txt"
exit "$status"
