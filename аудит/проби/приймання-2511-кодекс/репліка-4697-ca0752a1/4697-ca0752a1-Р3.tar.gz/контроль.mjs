import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { spawnSync } from 'node:child_process';

const deps = process.argv[2];
const source = (file) => readFileSync(deps + '/показ/' + file, 'utf8');
function extract(code, name) {
  const result = code.match(new RegExp('^(?:async )?function ' + name + '\\([\\s\\S]+?^\\}', 'm'));
  if (!result) throw new Error('Could not find ' + name);
  return result[0];
}

async function run(fixture, invalid) {
  const product = source('мовний_шар.js');
  const test = readFileSync(fixture, 'utf8').split('1е-і. ІНСТРУМЕНТ РОЗМОВИ НАСКРІЗЬ')[1];
  const stub = test.match(/    w\._модель = async п => [\s\S]+?(?=\n    w\.eval)/)[0];
  const code = [extract(product, 'розмоваШаромП'), extract(product, 'реплікоюП'), extract(product, 'ходомРозмовиП'),
    extract(source('інструменти.js'), 'інструментомП'), extract(source('паспорт.js'), 'розмоваЯкMainП'),
    extract(source('паспорт.js'), 'паспортПоРозмовіП')].join('\n');
  const callPython = data => {
    const run = spawnSync('python3', ['-c',
      'import sys, мовний_шар; print(мовний_шар.мова(sys.argv[1]))', JSON.stringify(data)],
      {encoding: 'utf8', timeout: 10000, env: {...process.env, PYTHONPATH: deps, PYTHONDONTWRITEBYTECODE: '1'}});
    if (run.status !== 0) throw new Error(run.stderr || String(run.error));
    return JSON.parse(run.stdout);
  };
  const result = await new Function('callPython', 'invalid', code + `
    let ПАСПОРТ_П = null, ВИПАДОК_ПАСПОРТА_П, ВИПАДОК_ЛЮДИНІ_П, ВИПАДОК_ШМАТКИ_П, ВИПАДОК_ПІДТВЕРДЖЕНО_П, ОСТАННІ_ТЕМИ_П;
    const МОДЕЛЬ_МОВИ_П = 'fixture';
    const СЦ = {ід:'case-a', назва:'Співбесіда в банку'}, ЧАТ_П = [{хто:'людина', текст:'Збережи цей сценарій'}];
    const ДОВІДНИК = {поля_паспорта:{}, показ:{поля_перекладу:[]}};
    let збережень = 0; const профілі = []; const ПРОФІЛІ = профілі, АКТИВНИЙ = 'synthetic'; const turnPrompts = [];
    const endpoints = [], replies = [];
    function оновитиДовідникП(){}
    function вхідМостаП(){return {сценарій:{}, вимоги:''};}
    function довжинаЖурналуКадрівП(){return 0;}
    function текстРепліки(r){return r.текст;}
    function колоритП(){return {};}
    function змінитиПаспортП(_, дія, в){ПАСПОРТ_П = дія === 'замінити' ? в : Object.assign({}, ПАСПОРТ_П, в);}
    function застосуватиПаспортДоЕкрана(){}
    function показатиМежі(){}
    function латинкаЧатуП(text){return text;}
    function живийХідП(){return () => true;}
    function реплікиСценарію(){return ЧАТ_П;}
    function новіФотоРечейП(){return [];}
    async function зберегтиСценарій(назва){збережень++; return {назва,час:'2026-11-25'};}
    function усіСценарії(){return [СЦ];}
    function проЩоСценарійП(){return '';}
    function перелікОбразівП(){return [];}
    function перелікиПалітриП(){return [];}
    const w = {}, промпти = [], відповіді = [];
    const tool = args => JSON.stringify({update:{}, need:'none', text:[], tool:{name:'save_scenario', args}});
    const args = invalid ? {as_new:'yes', name:"Інтерв'ю в банку"} : {};
    відповіді.push(tool(args));
    if (invalid) відповіді.push(tool(args));
    ${stub}
    async function модельМовиП(prompt){
      if (/her_new_message/.test(prompt))
        turnPrompts.push({invalidAsNew:prompt.includes('tool.args.as_new: must be boolean'),
          invalidName:prompt.includes('tool.args.name: not an argument')});
      return w._модель(prompt);
    }
    async function містП(ім, d){
      const result = ім === 'мова' ? callPython(d) : {помилка: 'не цей ендпойнт: ' + ім};
      endpoints.push(ім === 'мова' ? (d.розмова ? (d.відповідь_моделі ? 'мова:суд_ходу' : 'мова:промпт_ходу') : d.паспорт_з ? 'мова:паспорт_з' : d.відповідь_моделі ? 'мова:суд_репліки' : 'мова:промпт_репліки') : ім);
      if (d.відповідь_моделі && d.репліка) replies.push({required:d.репліка.required, текст:result.текст, причина:result.причина});
      return result;
    }
    return (async () => {
      const words = ЧАТ_П[0].текст;
      const result = await розмоваШаромП(words, [], null, false, 'сценарій');
      let fallbackError = null;
      if (result.відмова){
        try{await розмоваЯкMainП(words, [], false, 'сценарій', result.записи);}
        catch(error){fallbackError = error.message;}
      }
      return {збережень, endpoints, replies, відмова:result.відмова, fallbackError,
        останнє:ЧАТ_П.at(-1).інструмент || null, текст:ЧАТ_П.at(-1).текст, turnPrompts,
        запаснийДоговір:(ЧАТ_П.at(-1).мова_шару?.[0]?.запасний_договір || '').split(' Previous value:')[0],
        залишилосьУЧерзі:відповіді.length};
    })();
  `)(callPython, invalid);
  return result;
}
const original = deps + '/тест_показу.js';
const changed = process.argv[3];
for (const invalid of [false, true]) {
  const до = await run(original, invalid);
  const після = await run(changed, invalid);
  const turns = invalid ? 2 : 1;
  assert.equal(до.fallbackError, 'не цей ендпойнт: паспорт');
  assert.equal(до.replies.length, 2);
  assert(до.replies.every(reply => reply.причина === 'required_question_missing: occasion'));
  assert.equal(після.збережень, 1);
  assert.equal(після.останнє.tool, 'save_scenario');
  assert.equal(після.останнє.done, true);
  assert.equal(після.останнє.as_new, false);
  assert.equal(після.останнє.name, 'Співбесіда в банку');
  assert.equal(після.відмова, false);
  assert.equal(після.fallbackError, null);
  assert.equal(після.endpoints.filter(item => item === 'паспорт').length, 0);
  assert.equal(після.текст, 'Куди ти збираєшся?');
  assert.deepEqual(після.replies, [{required:['occasion'], текст:після.текст, причина:null}]);
  assert.equal(після.turnPrompts.length, turns);
  assert.deepEqual(після.turnPrompts, до.turnPrompts);
  assert.equal(після.залишилосьУЧерзі, 0);
  if (invalid) {
    assert.deepEqual(після.turnPrompts[1], {invalidAsNew:true, invalidName:true});
    assert.match(після.запаснийДоговір, /tool\.args\.as_new: must be boolean/);
    assert.match(після.запаснийДоговір, /tool\.args\.name: not an argument/);
  } else {
    assert.equal(після.запаснийДоговір, '');
  }
  console.log(JSON.stringify({branch: invalid ? 'повтор' : 'звичайний', до, після}));
}
