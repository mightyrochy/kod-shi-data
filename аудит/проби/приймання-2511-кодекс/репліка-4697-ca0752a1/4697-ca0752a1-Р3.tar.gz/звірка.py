import base64
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import sys
from zipfile import ZipFile

package = Path(__file__).resolve().parent

def sha256(data):
    return hashlib.sha256(data).hexdigest()

inputs_before = (package / 'вхідні_джерела_до.json').read_bytes()
inputs_after = (package / 'вхідні_джерела_після.json').read_bytes()
assert inputs_before == inputs_after, 'Входи змінилися'
inputs = json.loads(inputs_before)
runtime = json.loads((package / 'CPython.json').read_text())
pyodide = json.loads((package / 'Pyodide.json').read_text())
assert {item['name']: item['sha256'] for item in inputs['runtime_cache']} == pyodide['SHA-256']

result = int((package / 'exit-code.txt').read_text())
log = (package / 'build.log').read_bytes()
receipt = {'commit': inputs['commit'], 'tree': inputs['tree'], 'build_exit': result,
           'build_log_sha256': sha256(log), 'inputs_identical': True,
           'input_files': len(inputs['files']), 'input_manifest_sha256': sha256(inputs_before),
           'python_runtime': runtime, 'pyodide_runtime': pyodide,
           'node_dependencies': inputs['node_dependencies'],
           'adapter_sha256': inputs['adapter']['sha256'], 'desktop_python': sys.version,
           'node': subprocess.check_output(['node', '--version'], text=True).strip(),
           'command': 'bash ' + str(package / 'збірка.sh'),
           'command_sha256': sha256((package / 'збірка.sh').read_bytes())}
if result == 0:
    jsdom = re.search(r'тест показу: ВИКОНАНО ЗВІРОК: (\d+) у (\d+) розділах · ПОКАЗ: усе зелене',
                      log.decode())
    assert jsdom, 'У журналі немає підтвердження штатної JSDOM-батареї'
    html = (package / 'index.html').read_bytes()
    text = html.decode()
    def js_constant(name):
        return re.search(r'const\s+' + name + r'\s*=\s*"([^"]+)"', text).group(1)
    stamp = js_constant('ЗБІРКА_ПОКАЗУ')
    fingerprint = js_constant('ВІДБИТОК_ПОКАЗУ')
    assert stamp == inputs['commit']
    assert re.fullmatch('[0-9a-f]{12}', fingerprint)
    assert re.search(r'^  ' + stamp + r' · html .* · код ' + fingerprint + r'$', log.decode(), re.M)
    assert not any(mark in text for mark in ('__МОДУЛІ_ПОКАЗУ__', '__ЗБІРКА_ПОКАЗУ__', '__ВІДБИТОК__'))
    bundle = base64.b64decode(js_constant('МОДУЛІ_ПОКАЗУ'), validate=True)
    source_sum = hashlib.sha256()
    with ZipFile(io.BytesIO(bundle)) as zipped:
        packed_names = sorted(name[:-3] for name in zipped.namelist() if name.endswith('.py'))
        code_hash = hashlib.md5()
        for name in packed_names:
            code_hash.update(name.encode('utf-8'))
            code_hash.update(zipped.read(name + '.py'))
        assert code_hash.hexdigest()[:12] == fingerprint
        manifest = zipped.read('байткод.json')
        m = json.loads(manifest)
        assert m['python'] == runtime['version_info'][:3] == [3, 12, 1]
        assert m['cache_tag'] == runtime['cache_tag'] == 'cpython-312'
        assert m['magic'] == runtime['magic'] == 'cb0d0d0a'
        assert m['pyodide'] == pyodide['Pyodide']['version'] == '0.26.4'
        assert m['компілятор'] == runtime['version']
        for name, meta in sorted(m['модулі'].items()):
            source = zipped.read(name)
            source_sum.update(name.encode('utf-8') + b'\0' + source)
            bytecode = zipped.read(meta['pyc'])
            assert sha256(source) == meta['source_sha256'], name
            assert sha256(bytecode) == meta['pyc_sha256'], meta['pyc']
            assert bytecode[:4].hex() == m['magic'] and int.from_bytes(bytecode[4:8], 'little') == 3, name
        assert source_sum.hexdigest() == m['source_sha256']
    (package / 'байткод.json').write_bytes(manifest)
    receipt.update({'stamp': stamp, 'code_fingerprint': fingerprint,
                    'html_sha256': sha256(html), 'html_bytes': len(html),
                    'bundle_sha256': sha256(bundle), 'bytecode_manifest_sha256': sha256(manifest),
                    'bytecode_modules_verified': len(m['модулі']),
                    'packed_python_source_sha256': m['source_sha256'],
                    'jsdom_checks': int(jsdom[1]), 'jsdom_sections': int(jsdom[2])})
else:
    receipt['html_verified'] = False
    receipt['note'] = 'Штатна збірка завершилась помилкою. HTML з цієї спроби не здавати.'

(package / 'квитанція.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(receipt, ensure_ascii=False, indent=2))
