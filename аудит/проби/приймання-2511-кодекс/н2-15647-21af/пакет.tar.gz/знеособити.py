import hashlib
import json
from pathlib import Path
import sys


def digest(value):
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


path = Path(sys.argv[1])
source = json.loads(path.read_text(encoding="utf-8"))
for variant in source["виходи"].values():
    if "картка" in variant:
        к = variant["картка"]
        variant["картка"] = {
            "sha256": digest(к), "рука": к["рука"], "образ": к["образ"], "вирок": к["вирок"],
            "склад": [{поле: р[поле] for поле in ("ід", "н", "слот")} for р in к["речі"]],
            "опис_є": bool(к["опис_en"]), "збій": к["збій"], "збій_опису": к["збій_опису"],
        }
    if "вироки" in variant:
        variant["вироки"] = [{"образ": v.get("образ"), "sha256": digest(v)} for v in variant["вироки"]]
    for diag in variant.get("звіт_цілі", []):
        diag["збої"] = [{k: z[k] for k in ("вид", "частина", "поле")} for z in diag["збої"]]
    variant["проблеми_руки_1"] = [
        {"вид": r["збій"]["вид"], "поле": r["збій"]["поле"]}
        for r in variant["проблеми_руки_1"]
    ]
print(json.dumps(source, ensure_ascii=False, indent=2))
