const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');

const [tree, resultPath] = process.argv.slice(2);
const record = JSON.parse(fs.readFileSync(resultPath, 'utf8'));
const code = fs.readFileSync(path.join(tree, 'джерела/показ/ядро.js'), 'utf8');
const context = vm.createContext({
  повідомленняОписуБезФотоП: () => ({code: 'description_written_without_photos'}),
  повідомленняБезОписуП: () => { throw Error('Придатна Картка несподівано втратила опис'); },
  збійРукиП: () => { throw Error('Гілка збою для успішної Картки'); },
});
vm.runInContext(code, context, {filename: 'джерела/показ/ядро.js'});
for (const [name, variant] of Object.entries(record.виходи)) {
  assert.equal(variant.картка.збій, null);
  context.картка = variant.картка;
  const data = vm.runInContext('карткаЯдраНаЕкранП(картка, 3)', context);
  assert.equal(data.рука, 1);
  assert.equal(data.збій, false);
  assert.ok(data.опис);
  assert.ok(!data.неповний && !data.неповний_чому);
  assert.ok(!data.речі.find(item => item.id === record.id));
  const userData = JSON.stringify({опис: data.опис, питання: data.питання, як_носити: data.як_носити,
    неповний: data.неповний, неповний_чому: data.неповний_чому, невідоме: data.невідоме});
  assert.ok(!/bad_record|послаб|прибрати (?:меж|вимог)|relax (?:the|your)|remove (?:the|your) (?:limit|requirement)/iu.test(userData));
  console.log(record.sha.slice(0, 8), name, 'JS-дані картки', data.речі.length, 'речей');
}
