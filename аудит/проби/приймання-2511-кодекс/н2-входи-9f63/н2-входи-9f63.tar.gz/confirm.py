"""Additional assertions on the narrow predicate and on the two output receipts."""
from pathlib import Path
import json
from ядро import знання
ev = Path(__file__).resolve().parent
base = json.loads((ev/'base.json').read_text())['cases']
head = json.loads((ev/'head.json').read_text())['cases']
cases = [k for k in base if k not in ('one_measured','one_interval')]
assert len(cases)==9 and all(base[k]==head[k] for k in cases)
predicate = знання._вхід_гілки
key = 'одна_вагома_поверхня'
items = {'dress': {}, 'jewel': {}}
checks = []
for held,ids,expected in [(True,['dress'],True), (False,['dress'],False),
                          (True,['elsewhere'],False), (True,[],False),
                          (True,['dress','jewel'],False)]:
    outcome = predicate(key,{},items,ids,утримано=held)
    assert outcome is expected
    checks.append({'held':held,'ids':ids,'admitted':outcome})
for c in ('one_measured','one_interval'):
    assert head[c]['readers']['full_verdict_requires_repair'] is False
print(json.dumps({'unchanged_cases': cases,'single_surface_predicate':checks},ensure_ascii=False,indent=2))
