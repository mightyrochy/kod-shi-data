"""Project one held statement through the ordinary wire and card readers."""
import json
from dataclasses import replace
from unittest.mock import patch
import суд_від_моделі as legacy
from ядро import суд, запит, знання, картка, розбір
from ядро.тести.тест_н2 import _опис


def readers(case, pool, scene, outfit, verdict):
    target = 'one_weighty_surface'
    number, = (r['н'] for r in outfit.речі if r['ід'] == 'dress')
    dress = знання.старий_запис(pool.записи[number])
    assert (dress['колір_тип'], dress.get('lab') is not None) == (
        ('інтервал', False) if case=='one_interval' else ('вимір', True))
    if case=='one_interval':
        assert list(dress['колір_не_вимір']['вікно']) == [27,72,0,7,None]
    ids = [f.ід for f in verdict.заяви if f.код==target]
    result = {'dress_source_type':dress['колір_тип'], 'dress_lab':dress.get('lab'),
              'verdict_ids':ids, 'requests':{}}
    isolated = replace(verdict, заяви=tuple(f for f in verdict.заяви if f.код==target))
    assert not суд.потребує_ремонту(isolated)
    result['held_only_requires_repair'] = суд.потребує_ремонту(isolated)
    result['full_verdict_requires_repair'] = суд.потребує_ремонту(verdict)

    with patch.object(legacy, 'перевірити_від_моделі', side_effect=AssertionError('readers must reuse the verdict')):
        for kind in ('ремонт','вибір','опис'):
            req = запит.запит(kind,pool,scene,{},образи=(outfit,),вироки={outfit.ід:verdict},без_фото=True)
            message = json.loads(req.модель['messages'][0]['content'])
            row, = message['verdict']
            findings = [f for f in row['findings'] if f['code']==target]
            assert [f['id'] for f in findings] == ids
            assert all(f['rule']=='K-COL-01' and f['items']==[number] and f['weight']==0 and f['withheld'] is True for f in findings)
            table = message['pool' if kind=='опис' else 'candidates']
            item, = (r for data in table['rows'] if (r := dict(zip(table['cols'],data)))['n']==number)
            if case=='one_interval':
                assert item['L']=='unknown' and item['hex']=='unknown'
            result['requests'][kind] = {'id':ids,'dress_number':number,'dress_L':item['L'],'findings':findings}
        desc = розбір.прочитати(_опис(outfit),'опис',pool,образ=outfit)
        card = картка.зібрати(outfit,verdict,desc,pool,фото_були=())
        assert card.збій is None and card.вирок==outfit.ід
        unknown = [x for x in card.невідоме if x['код']==target]
        ordinary = [x for x in card.заяви_картки if x['код']==target]
        assert [x['ід'] for x in unknown]==ids and not ordinary
        assert all(tuple(x['речі'])==('dress',) and x['вага']==0 and x['утримано'] for x in unknown)
        result.update(card_unknown=unknown,card_ordinary=ordinary)
    return result
