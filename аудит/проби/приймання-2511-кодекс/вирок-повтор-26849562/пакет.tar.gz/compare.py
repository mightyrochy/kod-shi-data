from collections import Counter
import difflib
import hashlib
import json
from pathlib import Path
import socket
import sys


def no_network(*args, **kwargs):
    raise AssertionError("offline probe tried network access")


socket.socket.connect = no_network
socket.socket.connect_ex = no_network
socket.create_connection = no_network
socket.getaddrinfo = no_network

import міст_оцінка as bridge

root = Path(__file__).resolve().parent
reference = Path(sys.argv[1])
diff_dir = root / "diffs"
diff_dir.mkdir(exist_ok=True)
cases = (
    ("без-пальта", "outputs/{rev}/незастосовне", "не стосується", set()),
    ("нуль-вимірів", "outputs/{rev}/бракує-вимірів", "без входу", {"її-ф1", "її-ф2"}),
    ("один-вимір", "evidence/один-вимір/{rev}", "без входу", {"її-ф2"}),
    ("60-100", "outputs/{rev}/перевірено", "пройдено", set()),
    ("70-100", "evidence/граничний-розрив/{rev}", "утримано", set()),
)
states = ("провал", "пройдено", "без входу", "не стосується", "утримано")
model_fixture = json.dumps({"answer": "Синтетична відповідь для перевірки даних картки.",
                            "verdict": "unknown", "works": [], "change": []}, ensure_ascii=False)


def read(path):
    return json.loads(path.read_bytes())


def formatted(data):
    return json.dumps(data, ensure_ascii=False, indent=2) + "\n"


def card(court):
    result = json.loads(bridge.оцінка({"крок": "оцінка", "суд": court, "відповідь_моделі": model_fixture}))
    assert result["причина"] is None and result["картка"]["не_знаю"]
    return result["картка"]["не_знаю"]


def facts(root_dir, file):
    path = root_dir / file
    blob = path.read_bytes()
    return {"path": str(path.relative_to(root_dir)), "bytes": len(blob), "sha256": hashlib.sha256(blob).hexdigest()}


results = {}
for label, relative, expected, missing_ids in cases:
    old, prev, current = [
        directory / relative.format(rev=rev)
        for directory, rev in ((reference, "before"), (reference, "after"), (root, "candidate"))
    ]
    original, before, after = [read(d / "суд.json") for d in (old, prev, current)]
    assert (prev / "вхід.json").read_bytes() == (current / "вхід.json").read_bytes()
    checklist = after["суд"]["checklist"]
    counts = Counter()
    for block in checklist.values():
        assert len(block["пункти"]) == len({cell["код"] for cell in block["пункти"]})
        count = Counter(cell["стан"] for cell in block["пункти"])
        for state in states:
            val = block[state.replace(" ", "_")]
            assert count[state] == (len(val) if isinstance(val, list) else val)
        counts.update(count)
    assert set(counts) <= set(states) and sum(counts.values()) == 61
    assert read(current / "перевірка-схеми.json") == []
    get_cell = lambda s: next(c for c in s["суд"]["checklist"]["надлишок"]["пункти"]
                              if c["код"] == "layer_hems_apart")
    cell = get_cell(after)
    assert cell["стан"] == expected, (label, cell)
    missing = [row for row in after["без_входу"] if row.get("point") == "layer_hems_apart"]
    if missing_ids:
        assert (cell["чому"], len(cell["бракує"])) == ("system:довжина_виробу_см", 1)
        missing_fact = cell["бракує"][0]
        assert missing_fact["fields"] == ["довжина_виробу_см"]
        assert set(missing_fact["items"]) == missing_ids
        assert missing_fact["facts"] == {"reason": "edge_not_measured"}
        assert len(missing) == 1 and missing[0]["missing"] == [missing_fact]
        measured = read(current / "краї.json")
        assert measured["розрив_пальто_сукня"] == [None, None, "edge_not_measured"]
        producer = next(z for z in after["без_входу"] if z.get("rule") == ["K-OUT-03"] and z.get("kind") == "утримано")
        statement = next(s for s in producer["statements"] if s["code"] == "outer_edges_gap_not_judged")
        values = {i["item_id"]: i for i in statement["values"]["items"]}
        assert {i for i, item in values.items() if item["length_cm"] is None} == missing_ids
        assert all(values[i]["point"] is None and values[i]["error_cm"] is None for i in missing_ids)
    else:
        assert "бракує" not in cell and not missing
    if label == "без-пальта":
        assert cell["чому"] == "object_absent:верхній_шар"
    assert (prev / "краї.json").read_bytes() == (current / "краї.json").read_bytes()
    assert before["суд"]["weight"] == after["суд"]["weight"]
    assert before["суд"]["findings"] == after["суд"]["findings"]
    before_list, after_list = [card(court) for court in (before, after)]
    assert before_list == after_list, label
    for prefix, listing in (("до", before_list), ("після", after_list)):
        (current / f"картка-брак-{prefix}.json").write_text(formatted(listing))
    for kind in ("оцінка", "допит"):
        file = f"{kind}.json"
        assert (prev / file).read_bytes() == (current / file).read_bytes(), (label, kind)
        prompt = read(current / file)
        points = prompt["check"]["points"]
        assert ("layer_hems_apart" in points["passed"]) == (expected == "пройдено")
        assert "layer_hems_apart" not in points["failed"] and "interest_sources" in points["failed"]
        assert not any("item_length_cm" in row.get("no_input", []) for row in prompt["unknown"])
        if label == "70-100":
            assert cell["чому"] and "похибки" in cell["чому"]
            row = next(f for f in prompt["check"]["findings"] if f["rule"] == "K-OUT-03")
            assert row["strength"] == "утримано" and row["sila_np"] == 0
            statement = next(s for s in row["statements"] if s["code"] == "outer_edges_gap_measured")
            assert (statement["values"]["gap_cm"], statement["values"]["error_cm"]) == (30, 21.34)
    old_and_new = [get_cell(s)["стан"] for s in (original, before, after)]
    results[label] = {"states": old_and_new, "missing_ids": sorted(missing_ids),
                      "counts": dict(counts), "prompts_byte_equal": True, "card_missing_equal": True,
                      "files": [facts(current, p.name) for p in sorted(current.glob("*.json"))]}
    diff = difflib.unified_diff(formatted(before).splitlines(keepends=True), formatted(after).splitlines(keepends=True),
                                f"cbd4c95b/{label}/суд.json", f"26849562/{label}/суд.json")
    (diff_dir / f"{label}.diff").write_text("".join(diff))
    print(label, " → ".join(old_and_new), "бракує", sorted(missing_ids), "61 клітинка; 2/2 запити; картковий брак збігся")
(root / "results.json").write_text(formatted(results))
print("PASS: 5 штатних входів, 10/10 повних тіл, 5/5 списків браку картки.")
