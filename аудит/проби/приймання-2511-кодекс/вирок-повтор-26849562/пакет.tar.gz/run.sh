#!/usr/bin/env bash
set -euo pipefail
review=${1:-/tmp/liusterko-verdict-held-review}
review=$(cd "$review" && pwd)
cd "$(dirname "$0")"
mkdir -p outputs evidence/{один-вимір,граничний-розрив}
export PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 PYTHONPATH="$PWD/candidate/джерела"
python3 probe.py candidate > outputs/candidate.log
python3 probe.py candidate --one-measure-only > evidence/один-вимір/candidate.log
python3 probe.py candidate --boundary-only > evidence/граничний-розрив/candidate.log
node task-blocks.mjs
python3 compare.py "$review" | tee receipt.log
test_class=тест_інваріанти.Е3_ПолеБезПисача
python3 -m unittest -v \
 "$test_class.test_вирок_розрізняє_пять_станів_клітинки" \
 "$test_class.test_пізнє_утримання_не_входить_до_перевірених" \
 "$test_class.test_вирок_пара_вікон_відрізняє_утриманий_вхід" \
 "$test_class.test_брак_входу_палітри_й_аксесуарів_перед_утриманням" \
 "$test_class.test_вхід_порівняння_країв_потребує_обох_вимірів" \
 "$test_class.test_вирок_країв_через_міст_оцінки" 2>&1 | tee author-tests.log
