import json
import sys
from pathlib import Path
from unittest.mock import patch


def заборонити_мережу(подія, _):
    if подія.startswith("socket."):
        raise RuntimeError(f"Мережеву дію заборонено: {подія}")


sys.addaudithook(заборонити_мережу)
sys.path.insert(0, sys.argv[1])

import міст_опис
import розбір_відповідей

фікстура = json.loads(Path(sys.argv[2]).read_text(encoding="utf-8"))
ціль = фікстура["target"]
виходи = []
for сценарій in фікстура["cases"]:
    # Межа з каталогом підставна. Складання запиту і розбір відповіді працюють штатно.
    товари = [
        {"id": f"ж-{19002 + к}@photo-fixture.invalid", "слот": слот, "назва": слот,
         "фото": None, "фото_усі": []}
        for к, слот in enumerate(фікстура["catalog_slots"][:сценарій["additional_items"]])
    ]
    картка = [ціль, *товари]
    каталог = [dict(річ) for річ in картка]
    if сценарій["enriched"]:
        каталог[0].update(фікстура["enrichment"])
    пул = {річ["слот"]: [{"id": річ["id"]}] for річ in каталог}
    номери = {
        ід: f"#{номер}·{код}"
        for номер, (ід, код) in розбір_відповідей.за_номером(пул).items()
    }
    склад = [річ["id"] for річ in картка]
    with (
        patch.object(міст_опис, "показ", return_value=json.dumps(картка, ensure_ascii=False)),
        patch.object(міст_опис, "_каталог_із", return_value=("synthetic", None)),
        patch.object(міст_опис._Ф, "база_прогону", return_value={"каталог": каталог}),
    ):
        запит = json.loads(міст_опис.опис({
            "речі": склад, "номери": номери, "мова_тексту": "англійська",
            **фікстура["profile"],
        }))
    номер = next(річ["н"] for річ in запит["опис"]["образ"]["речі"] if річ["н"] == номери[ціль["id"]])
    відповідь = {
        "version": "1",
        "text": "The outfit is ready.",
        "how_to_wear": [],
        "wrong_photos": [номер],
        "about_items": [
            {"n": номери[ід], "text": "This item is in the outfit."} for ід in склад
        ],
    }
    опис = розбір_відповідей.опис_відповідь_з_json(
        json.dumps(відповідь, ensure_ascii=False), кандидати=пул, каталог=каталог, склад=склад,
        з_причинами=запит["з_причинами"],
    )
    assert not опис["помилки"] and not опис.get("повторний_виклик"), опис
    assert опис["фото_не_те"] == [номер], опис
    assert len(запит["фото"]) == сценарій["delivered"], запит["фото"]
    виходи.append({
        "fixture": сценарій, "raw_response": відповідь, "catalog": каталог, "card_feed": картка,
        "request": запит, "python_output": опис, "number": номер,
    })

print(json.dumps(виходи, ensure_ascii=False, indent=2))
