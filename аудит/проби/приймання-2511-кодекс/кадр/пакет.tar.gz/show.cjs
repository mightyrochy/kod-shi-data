const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const [tree, pythonOutput, repository] = process.argv.slice(2);
const {JSDOM} = require(path.join(repository, 'джерела/node_modules/jsdom'));
const inputs = JSON.parse(fs.readFileSync(pythonOutput, 'utf8'));
const scriptFiles = {
  'джерела/показ/збирання_руки.js': null,
  'джерела/показ/картки.js': ['кадриРечі'],
  'джерела/показ/екран/картка.js': ['силуетКадру', 'підставитиКадр', 'рендерКартку'],
};

async function перевірити(вхід) {
  const {fixture, card_feed, raw_response, request, python_output, number} = вхід;
  const id = card_feed[0].id;
  const dom = new JSDOM();
  const document = dom.window.document;
  // Режим JSDOM за замовчуванням не завантажує підресурси.
  // Спостерігач лише записує присвоєння src та передає їх звичайному DOM-властивості.
  const proto = dom.window.HTMLImageElement.prototype;
  const src = Object.getOwnPropertyDescriptor(proto, 'src');
  const адреси = new Map();
  Object.defineProperty(proto, 'src', {
    ...src,
    set(url) {
      if (!адреси.has(this)) адреси.set(this, []);
      адреси.get(this).push(url);
      src.set.call(this, url);
    },
  });
  const ел = (tag, cls, text) => {
    const element = document.createElement(tag);
    if (cls) element.className = cls;
    if (text) element.textContent = text;
    return element;
  };
  const нічого = () => {};
  const network = () => { throw Error('Мережевий виклик у пробі'); };
  const діагноз = [];
  const deliveries = [];
  const calls = {local_model_fixture: 0, python_fixture: 0, bridge: []};
  const підтвердження = {надіслано: request.фото.length, дійшло: fixture.delivered};
  const контекст = vm.createContext({
    document, ел, елЖінціП: ел,
    fetch: network, XMLHttpRequest: network, WebSocket: network,
    Екран: {змінити: нічого, дія: нічого, малювач: нічого},
    ЧИСЛА: ['Перший'], НАПИСИ_БЕЗ_ШАРУ_П: new Set(), ВЕЛИКІ_СЛОТИ: [],
    закріпитиСвоїШаруП: нічого, своїЕкрануП: нічого, текстЖінціП: нічого, розміткаЖінціП: нічого,
    замінюванаРічП: () => false, крамниця: () => '', грн: () => '', людською: () => ['', []],
    рядокПідПереліком: () => '', НЕ_ЦЯ_П: new Set(), чекаютьРозгортанняП: () => false,
    вердиктДотикиЙПолеП: нічого,
    ЗБ: {діагноз}, СТАДІЯ_П: {опис: 'опис'}, ОСТАННІ_ЗАГОЛОВКИ_П: {},
    П: {картки: []}, МОДЕЛЬ_МОВИ_П: null, МОДЕЛЬ_П: 'підставний-рядок',
    містП: async (метод, дані) => {
      calls.bridge.push(метод);
      assert.deepEqual(Array.from(дані.речі), card_feed.map(р => р.id));
      if (метод === 'опис') return request;
      if (метод === 'показ') return card_feed;
      throw Error('Незапланований виклик мосту: ' + метод);
    },
    підписатиКадри: (кадри, підписи) => кадри.flatMap((кадр, i) => [
      {type: 'text', text: підписи[i]}, кадр,
    ]),
    довжинаЖурналуКадрівП: () => deliveries.length,
    дійшлоКадрівЗаП: mark => deliveries.slice(mark),
    модельРукиП: async blocks => {
      calls.local_model_fixture++;
      assert.equal(calls.local_model_fixture, 1);
      assert.deepEqual(Array.from(blocks.filter(b => b.type === 'image'), b => b.source.url), request.фото);
      deliveries.push(підтвердження);
      return JSON.stringify(raw_response);
    },
    кадрівНеДійшлоП: () => підтвердження,
    показатиТокени: нічого,
    звестиПитанняП: x => x,
    етапиПрогону: нічого, етапиРозмови: нічого, етапиСуду: нічого, довідникРечейЕтапів: нічого,
  });
  for (const [file, functions] of Object.entries(scriptFiles)) {
    const source = fs.readFileSync(path.join(tree, file), 'utf8');
    const selected = functions?.map(name => {
      const singleLine = name === 'силуетКадру';
      const pattern = singleLine ? '.*' : '[\\s\\S]*?^}';
      const match = source.match(new RegExp('^function ' + name + '\\(' + pattern, 'm'));
      assert.ok(match, name);
      return match[0];
    }).join('\n');
    vm.runInContext(selected ?? source, контекст, {filename: file});
  }

  const склад = card_feed.map(р => р.id);
  контекст.к = {
    рука: '1', зКаталогом: true, вх: {}, мітка: нічого, станОбриву: нічого, зОбривом: (_, x) => x,
    лічильники: {викликів: 0}, запамʼятатиЗапит: нічого, отриматиЗапитОстанній: нічого,
    відМоделіРуки: async дані => {
      calls.python_fixture++;
      assert.equal(calls.python_fixture, 1);
      assert.deepEqual(JSON.parse(дані.текст_моделі), raw_response);
      return {опис: python_output, перевірено: true, речі: card_feed};
    },
    етапиВикликів: [], мовПорушення: [], моделіРуки: new Set(), мапаМіток: {},
    отриматиПовторПрогону: нічого, описБезКадрів: () => false,
  };
  контекст.стан = {
    обрані: склад, обраніІД: склад, оголКартки: [], в: {речі: card_feed},
    ітерацій: 1, збій: false, дібраніКодом: {},
  };
  const опис = await vm.runInContext('стадіяОпису(к, стан)', контекст);
  const {картка} = await vm.runInContext('збиранняКарткиРуки(к, обʼєднанийСтан)',
    Object.assign(контекст, {обʼєднанийСтан: {...контекст.стан, ...опис}}));
  assert.deepEqual(calls, {local_model_fixture: 1, python_fixture: 1, bridge: ['опис', 'показ']});
  assert.deepEqual(Array.from(картка.речі, р => р.id), склад);
  assert.equal(картка.збій, false);
  контекст.П.картки = [картка];
  const вузол = vm.runInContext('рендерКартку(0)', контекст);
  const колаж = Array.from(вузол.querySelectorAll('.ф')).find(в => в.dataset.id === id);
  const мініатюра = вузол.querySelector('.річ');
  assert.ok(колаж && мініатюра);
  const підсумок = слот => ({
    slot_present: !!слот,
    src: слот.querySelector('img')?.getAttribute('src') ?? null,
    silhouette: !!слот.querySelector('.арка'),
  });
  const показ = {};
  for (const [назва, слот] of Object.entries({collage: колаж, thumbnail: мініатюра})) {
    const img = слот.querySelector('img');
    const before = підсумок(слот);
    let events = 0;
    if (img) {
      while (img.onerror && events < 8) {
        events++;
        img.dispatchEvent(new dom.window.Event('error'));
      }
      assert.equal(img.onerror, null);
    }
    показ[назва] = {initial: before, all_src_assignments: адреси.get(img) || [], error_events_dispatched: events, after_errors: підсумок(слот)};
  }
  const запис = {
    scenario: fixture.name,
    number,
    raw_wrong_photos: raw_response.wrong_photos,
    delivered_photo_urls_fixture: request.фото,
    delivery_counts_fixture: підтвердження,
    python: {
      фото_не_те: python_output.фото_не_те,
      фото_не_ті: python_output.фото_не_ті,
      фото_не_ті_знято: python_output.фото_не_ті_знято,
      schema_errors: python_output.помилки,
    },
    diagnoses: діагноз.filter(x => x.includes('photo_mismatch')),
    card: {фото_не_ті: картка.фото_не_ті, відхилення_кадрів: картка.відхилення_кадрів ?? null},
    display: показ,
  };
  dom.window.close();
  return запис;
}

Promise.all(inputs.map(перевірити)).then(rows => {
  process.stdout.write(JSON.stringify(rows, null, 2));
}).catch(error => {
  console.error(error);
  process.exitCode = 1;
});
