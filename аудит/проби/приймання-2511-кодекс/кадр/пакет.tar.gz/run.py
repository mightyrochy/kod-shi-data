import difflib
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile

корінь = Path(__file__).resolve().parent
репозиторій = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path("/workspace/kod-shi-data")
зрізи = {
    "base": "f0d1b453cad614e95c8abbdd4b2cd0766714a90d",
    "candidate": "1e580d34e3530f632d1dbbf885437ef00062f9a4",
}
js = {
    "джерела/показ/збирання_руки.js",
    "джерела/показ/екран/картка.js",
    "джерела/показ/картки.js",
}


def гіт(*аргументи):
    return subprocess.check_output(("git", "-C", репозиторій, *аргументи))


def записати_json(шлях, дані):
    шлях.write_text(json.dumps(дані, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


результати = {}
for назва, sha in зрізи.items():
    assert гіт("rev-parse", sha).decode().strip() == sha
    файли = [
        шлях for шлях in гіт("ls-tree", "-r", "-z", "--name-only", sha, "--", "джерела").decode().split("\0")
        if шлях in js or (шлях.count("/") == 1 and шлях.endswith((".py", ".json")))
    ]
    тека = корінь / назва
    тека.mkdir(exist_ok=True)
    архів = гіт("archive", sha, "--", *файли)
    with tarfile.open(fileobj=io.BytesIO(архів)) as tar:
        tar.extractall(тека, filter="data")
    маніфест = {}
    for шлях in файли:
        дані = (тека / шлях).read_bytes()
        blob = hashlib.sha1(f"blob {len(дані)}\0".encode() + дані).hexdigest()
        маніфест[шлях] = blob
    очікувані = {
        рядок.split("\t")[1]: рядок.split("\t")[0].split()[2]
        for рядок in гіт("ls-tree", "-r", "-z", sha, "--", *файли).decode().strip("\0").split("\0")
    }
    assert маніфест == очікувані
    записати_json(корінь / f"{назва}.manifest.json", {"commit": sha, "blobs": маніфест})
    python = subprocess.check_output(
        [sys.executable, "-B", корінь / "input_python.py", тека / "джерела", корінь / "fixture.json"],
        cwd=тека,
    )
    (корінь / f"{назва}.python.json").write_bytes(python)
    вивід_js = subprocess.check_output(
        ["node", корінь / "show.cjs", тека, корінь / f"{назва}.python.json", репозиторій],
        cwd=тека,
    )
    результати[назва] = json.loads(вивід_js)
    записати_json(корінь / f"{назва}.result.json", результати[назва])


фікстура = json.loads((корінь / "fixture.json").read_text(encoding="utf-8"))
ціль = фікстура["target"]
id_речі = ціль["id"]
туфлі, сумка = ціль["фото_усі"]
for назва, rows in результати.items():
    assert [row["scenario"] for row in rows] == [вхід["name"] for вхід in фікстура["cases"]]
    for row, сценарій in zip(rows, фікстура["cases"]):
        знято = сценарій["enriched"]
        один = сценарій["delivered"] == 1
        python = row["python"]
        assert row["raw_wrong_photos"] == python["фото_не_те"] == [row["number"]]
        assert row["number"].startswith("#") and "·" in row["number"]
        assert python["фото_не_ті"] == row["card"]["фото_не_ті"] == ([] if знято else [id_речі])
        assert [причина["id"] for причина in python["фото_не_ті_знято"]] == ([id_речі] if знято else [])
        assert row["delivered_photo_urls_fixture"] == ([туфлі] if один else [туфлі, сумка])
        if назва == "base":
            відхилення = None
        elif знято:
            відхилення = []
        else:
            відхилення = [{"id": id_речі, "адреси": [туфлі] if один else [], "неоднозначно": not один}]
        assert row["card"]["відхилення_кадрів"] == відхилення
        адреси = [туфлі, сумка, туфлі, сумка] if знято else ([сумка, сумка] if назва == "base" else [])
        for поверхня in row["display"].values():
            assert поверхня["initial"] == {
                "slot_present": True, "src": адреси[0] if адреси else None, "silhouette": not адреси,
            }
            assert поверхня["all_src_assignments"] == адреси
            assert поверхня["error_events_dispatched"] == len(адреси)
            assert поверхня["after_errors"] == {"slot_present": True, "src": None, "silhouette": True}

до = (корінь / "base.result.json").read_text(encoding="utf-8").splitlines(keepends=True)
після = (корінь / "candidate.result.json").read_text(encoding="utf-8").splitlines(keepends=True)
diff = difflib.unified_diff(до, після, fromfile=зрізи["base"], tofile=зрізи["candidate"])
(корінь / "result.diff").write_text("".join(diff), encoding="utf-8")
записати_json(корінь / "comparison.json", {"commits": зрізи, **результати})

def відмінності(до, після, шлях=()):
    if до == після:
        return []
    if isinstance(до, dict) and isinstance(після, dict) and до.keys() == після.keys():
        return [
            зміна for ключ in до
            for зміна in відмінності(до[ключ], після[ключ], (*шлях, ключ))
        ]
    return [{"path": list(шлях), "base": до, "candidate": після}]


записати_json(корінь / "diff.json", {
    "commits": зрізи,
    "changes": [
        зміна for до_випадок, після_випадок in zip(результати["base"], результати["candidate"])
        for зміна in відмінності(до_випадок, після_випадок, (до_випадок["scenario"],))
    ],
})
print("Зіставлено по три випадки на двох точних деревах.")
