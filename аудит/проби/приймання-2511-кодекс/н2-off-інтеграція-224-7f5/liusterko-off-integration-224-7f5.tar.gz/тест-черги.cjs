'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs'), os = require('node:os'), path = require('node:path');
const vm = require('node:vm');
const {sha256} = require('./доказ_прогону.js');
const {записувач, джерелоВідповідей} = require('./off.cjs');

async function тест() {
  const тека = fs.mkdtempSync(path.join(os.tmpdir(), 'н2-черга-'));
  try {
    const тіла = [Buffer.from('{"номер":1}'), Buffer.from('{"номер":2}')];
    const відповіді = ['{"відповідь":1}', '{"відповідь":2}'];
    const записати = записувач(path.join(тека, 'архів'));
    for (const [і, тіло] of тіла.entries())
      записати(і + 1, тіло, {status: 200, contentType: 'application/json', headers: {}, body: відповіді[і]});
    const архів = джерелоВідповідей(path.join(тека, 'архів'));
    const код = fs.readFileSync(path.join(__dirname, 'контролер.cjs'), 'utf8');
    const початок = 'await контекст.route(/.*/, ';
    const кінець = ');\n  await контекст.addInitScript';
    const з = код.indexOf(початок) + початок.length;
    assert(з >= початок.length && код.indexOf(кінець, з) > з);
    const обробник = код.slice(з, код.indexOf(кінець, з));
    const резервування = [], доставлено = [];
    let увійшлиВCDP, відпуститиCDP;
    const вCDP = new Promise(р => { увійшлиВCDP = р; });
    const паузаCDP = new Promise(р => { відпуститиCDP = р; });
    const стан = {
      URL, Buffer, Date, setTimeout, fs, path, sha256, МІСТ: 'http://127.0.0.1:8787',
      ВИХІД: тека, знімокЗроблено: true, запитів: 0, віддано: 0, обмінДоЗнімка: false,
      паузОбміну: 0, очікуванняПаузи: null, зупинка: null, перша_розбіжність: null,
      вПольоті: new Set(), останнійОбмін: 0, події: [], ТЕМП: [0, 0], пиши() {},
      читач: {взяти(тіло) { const в = архів.взяти(тіло); резервування.push(в.номер); return в; }},
      писачПовтору() {}, стор: {evaluate: async ф => ф()},
      контекст: {clock: {pauseAt: async () => {}, resume: async () => {}}},
      cdp: {async send(метод) {
        if (метод === 'Debugger.pause') { увійшлиВCDP(); await паузаCDP; }
      }}
    };
    const route = і => ({
      request() { return {url: () => стан.МІСТ + '/', method: () => 'POST', postDataBuffer: () => тіла[і]}; },
      async fulfill(в) { доставлено.push(в.body); },
      async abort() { throw new Error('Сумісний запит відхилено'); }
    });
    const обмін = vm.runInNewContext('(' + обробник + ')', стан);
    const перший = обмін(route(0));
    await вCDP;
    const другий = обмін(route(1));
    assert.deepEqual(резервування, [1, 2], 'Перший CDP ще чекає, а обидві відповіді вже зарезервовано по порядку');
    assert.deepEqual(доставлено, [], 'Другий запит також чекає спільної паузи');
    відпуститиCDP();
    await Promise.all([перший, другий]);
    assert.deepEqual(доставлено, відповіді);
    assert.deepEqual(архів.завершити(), {взято: 2, записів: 2});
    assert.equal(стан.перша_розбіжність, null);
    console.log('Синтетична черга: обидва callback зарезервували №1→№2 до затриманого CDP, потім отримали точні відповіді.');
  } finally {
    fs.rmSync(тека, {recursive: true, force: true});
  }
}

тест().catch(е => { console.error(е); process.exitCode = 1; });
