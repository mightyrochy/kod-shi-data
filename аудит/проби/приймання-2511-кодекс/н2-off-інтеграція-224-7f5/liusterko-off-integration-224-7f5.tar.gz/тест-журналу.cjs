'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs'), os = require('node:os'), path = require('node:path');
const {ролі, почати, прочитати} = require('./журнал.cjs');

const корінь = fs.mkdtempSync(path.join(os.tmpdir(), 'н2-журнал-'));
const план = {походження: 'відтворення запису 912', контролер_sha256: 'контролер',
  налаштування_часу_sha256: 'час', темп_джерела_sha256: 'темп'};
const хеш = 'план';
try {
  const невдала = path.join(корінь, 'невдала'), успішна = path.join(корінь, 'успішна');
  fs.mkdirSync(невдала);
  fs.mkdirSync(успішна);
  assert.throws(() => почати(невдала, план, хеш, 'джерело'), /Невідома роль/);
  assert.throws(() => почати(невдала, план, хеш, 'база'), /порядок спроб порушено/);
  function початиТест(тека, роль) {
    const завершити = почати(тека, план, хеш, роль);
    fs.mkdirSync(path.join(тека, роль));
    fs.writeFileSync(path.join(тека, роль, 'лог.txt'), 'тест ' + роль);
    return завершити;
  }
  const завершитиНевдалу = початиТест(невдала, 'еталон');
  assert.throws(() => почати(невдала, план, хеш, 'еталон'), /попередня спроба/);
  завершитиНевдалу({run_id: 'id1', rc: 1, перша_розбіжність: {номер: 11}});
  assert.throws(() => почати(невдала, план, хеш, 'база'), /завершилася невдачею/);
  assert.throws(() => завершитиНевдалу({run_id: 'id2', rc: 0, перша_розбіжність: null}), /EEXIST/);
  for (const роль of ролі) початиТест(успішна, роль)({run_id: роль, rc: 0, перша_розбіжність: null});
  assert.deepEqual(прочитати(успішна, план, хеш).map(з => з.роль), ролі);
  fs.writeFileSync(path.join(успішна, 'спроби', '04-старт.json'), '{}');
  assert.throws(() => прочитати(успішна, план, хеш), /додатковий хід/);
  console.log('7 синтетичних контролів порядку та незмінності спроб. Контролер Chromium не запускали.');
} finally {
  fs.rmSync(корінь, {recursive: true, force: true});
}
