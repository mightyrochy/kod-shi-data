'use strict';
/* Інтеграційний OFF. Адаптовано зі штатного стенда #4717 (Git blob 71991c0f). */
const fs = require('fs'), path = require('path'), crypto = require('crypto');
const assert = require('node:assert/strict');
const [історія, історичнийHTML, новаТека, РОЛЬ, HTML] = process.argv.slice(2);
const журнал = require('./журнал.cjs');
const off = require('./off.cjs');
const {ключЗапиту} = require('./записаний_обмін.js');
const {перевіритиІсторію, читатиПлан} = require('./інтеграція.cjs');
assert(process.argv.length === 7 && журнал.ролі.includes(РОЛЬ),
  'Вжиток: node контролер.cjs ІСТОРИЧНА_ТЕКА 912.html НОВА_ТЕКА [еталон|база|кандидат] HTML_РОЛІ');
const ІСТОРІЯ = fs.realpathSync(історія), ТЕКА = fs.realpathSync(новаТека);
assert(ТЕКА !== ІСТОРІЯ && !ТЕКА.startsWith(ІСТОРІЯ + path.sep) && !ІСТОРІЯ.startsWith(ТЕКА + path.sep),
  'Теки історичного запису й інтеграційних проходів мають бути окремими');
const sha256 = б => crypto.createHash('sha256').update(б).digest('hex');
const rj = ф => JSON.parse(fs.readFileSync(ф, 'utf8'));
const БАЗА = 'http://127.0.0.1:8765', МІСТ = 'http://127.0.0.1:8787';
const ФІКС = path.join(ТЕКА, 'фікстури');
const ВХІД = rj(path.join(ТЕКА, 'повтор.json'));
const ФІКСТУРА = rj(path.join(ТЕКА, 'фікстура.json'));
const ДІЇ = rj(path.join(ФІКС, 'дії.json'));
const СХОВИЩЕ = rj(path.join(ФІКС, 'сховище.json'));
const ГОДИННИК = rj(path.join(ФІКС, 'годинник.json'));
const СІД = ВХІД.сід;
const ВИХІД = path.join(ТЕКА, РОЛЬ);
перевіритиІсторію(ІСТОРІЯ, історичнийHTML);
assert.deepEqual(off.вхідніФайли(ТЕКА).хеші, off.вхідніФайли(ІСТОРІЯ).хеші,
  'Початкові файли інтеграції розходяться з архівом');
const темпФайл = path.join(ІСТОРІЯ, 'джерело/виклики-каналу.json');
const темпХеш = sha256(fs.readFileSync(темпФайл));
const {план, планХеш} = читатиПлан(ТЕКА, темпХеш);
assert.equal(план.контролер_sha256, sha256(fs.readFileSync(__filename)), 'Запущено контролер поза планом');
assert.deepEqual(rj(path.join(ТЕКА, 'налаштування-часу.json')),
  {годинник: ГОДИННИК, тиша_до_знімка_мс: ВХІД.змінні.тиша_до_знімка_мс, темп_джерела_sha256: темпХеш},
  'Налаштування часу не відповідають фактичному входові');
const штампи = off.збірка(HTML, РОЛЬ === 'кандидат' ? off.кандидат : off.інтеграційнаБаза);
const html = fs.readFileSync(HTML);
assert.equal(sha256(html), штампи.sha256, 'Байти HTML змінилися під час читання');
const завершитиСпробу = журнал.почати(ТЕКА, план, планХеш, РОЛЬ);
fs.mkdirSync(ВИХІД);
fs.mkdirSync(path.join(ВИХІД, 'VIDPOVIDI'));
const лог = [];
const пиши = (...а) => { const р = new Date().toISOString() + ' ' + а.join(' '); лог.push(р); console.log(р); };
const події = [];
let паузОбміну = 0, очікуванняПаузи = null, стор = null, cdp = null;
let знімокЗроблено = false, обмінДоЗнімка = false, запитів = 0, віддано = 0;
const run_id = 'off-' + РОЛЬ + '-' + crypto.randomUUID();
let перша_розбіжність = null;
const вПольоті = new Set();
let останнійОбмін = Date.now();
const писачПовтору = off.записувач(path.join(ВИХІД, 'VIDPOVIDI/обмін'));
const читач = off.джерелоВідповідей(path.join(ІСТОРІЯ, 'джерело/VIDPOVIDI/обмін'));
const ТЕМП = rj(темпФайл).map(в => в.стіна_мс);
assert(ТЕМП.every(мс => Number.isFinite(мс) && мс >= 0), 'Нема повного темпу джерела');
let зупинка = null;

(async () => {
  const {chromium} = require('playwright');
  const браузер = await chromium.launch();
  const контекст = await браузер.newContext({viewport: {width: 390, height: 844}, deviceScaleFactor: 1,
    locale: ГОДИННИК.локаль, timezoneId: ГОДИННИК.часовий_пояс, serviceWorkers: 'block', acceptDownloads: false});
  /* ізоляція й журнал — до будь-якої навігації */
  await контекст.routeWebSocket(/.*/, с => { події.push({url: с.url(), вид: 'заблоковано'}); return с.close({code: 1008}); });
  await контекст.route(/.*/, async route => {
    const з = route.request(), url = з.url(), u = new URL(url);
    if (u.origin === МІСТ) {
      if (з.method() !== 'POST') { події.push({url, вид: 'заблоковано'}); return route.abort('blockedbyclient'); }
      if (зупинка) return route.abort('blockedbyclient');
      const тіло = з.postDataBuffer();
      const номер = ++запитів;
      if (!знімокЗроблено) обмінДоЗнімка = true;
      вПольоті.add(номер); останнійОбмін = Date.now();
      let булаПауза = false;
      try {
        if (!знімокЗроблено) throw new Error('Запит до початкового знімка');
        /* Номер і резервування архівної відповіді йдуть синхронно в порядку перехоплення. */
        const в = читач.взяти(тіло);
        if (в.номер !== номер) throw new Error('номер запису ' + в.номер + ' ≠ ' + номер);
        булаПауза = true;
        if (паузОбміну++ === 0) {
          /* Один бар’єр часу для паралельних обмінів. Жодна відповідь не йде до паузи. */
          очікуванняПаузи = (async () => {
            const т = await стор.evaluate(() => Date.now());
            await контекст.clock.pauseAt(т + 1);
            await cdp.send('Debugger.enable');
            await cdp.send('Debugger.pause');
          })();
        }
        await очікуванняПаузи;
        if (зупинка) throw new Error(зупинка);
        const т0 = Date.now();
        const відповідь = в.відповідь;
        const чекати = ТЕМП[номер - 1] - (Date.now() - т0);
        if (чекати > 0) await new Promise(р => setTimeout(р, чекати));
        if (зупинка) throw new Error(зупинка);
        писачПовтору(номер, тіло, відповідь);
        пиши('обмін', номер, 'з запису', 'темп', ТЕМП[номер - 1]);
        await route.fulfill({status: відповідь.status, contentType: відповідь.contentType, headers: відповідь.headers, body: відповідь.body});
        віддано++;
        події.push({url, вид: 'обмін', номер, запит_sha256: sha256(тіло), відповідь_sha256: sha256(Buffer.from(відповідь.body, 'utf8'))});
      } catch (е) {
        зупинка = зупинка || ('обмін ' + номер + ': ' + е.message);
        if (!перша_розбіжність) {
          перша_розбіжність = {номер, причина: е.message};
          if (Buffer.isBuffer(тіло))
            fs.writeFileSync(path.join(ВИХІД, 'незбіг-' + String(номер).padStart(5, '0') + '.запит'), тіло, {flag: 'wx'});
        }
        пиши('ЗУПИНКА', зупинка);
        await route.abort('blockedbyclient').catch(() => {});
      } finally {
        вПольоті.delete(номер); останнійОбмін = Date.now();
        if (булаПауза && --паузОбміну === 0) {
          очікуванняПаузи = null;
          /* disable знімає і паузу, і ще не спрацьовану заявку на неї */
          await cdp.send('Debugger.disable').catch(е => { зупинка ||= 'Пуск JS: ' + е.message; });
          await контекст.clock.resume().catch(е => { зупинка ||= 'Пуск годинника: ' + е.message; });
        }
      }
      return;
    }
    if (u.origin === БАЗА && з.method() === 'GET' && !u.search) {
      if (u.pathname === '/index.html') {
        події.push({url, вид: 'збірка', sha256: sha256(html)});
        return route.fulfill({status: 200, contentType: 'text/html; charset=utf-8', body: html});
      }
      if (decodeURIComponent(u.pathname) === '/засів.html') {
        const б = fs.readFileSync(path.join(ФІКС, 'засів.html'));
        події.push({url, вид: 'локально', файл: 'засів.html', sha256: sha256(б)});
        return route.fulfill({status: 200, contentType: 'text/html; charset=utf-8', body: б});
      }
    }
    if (u.origin === 'https://cdn.jsdelivr.net' && /^\/pyodide\/v0\.26\.4\/full\/[\w.-]+$/.test(u.pathname) && з.method() === 'GET') {
      const ім = 'pyodide/' + u.pathname.split('/').pop();
      if (ФІКСТУРА.файли[ім]) {
        const б = fs.readFileSync(path.join(ФІКС, ім));
        події.push({url, вид: 'локально', файл: ім, sha256: sha256(б)});
        const тип = ім.endsWith('.wasm') ? 'application/wasm' : /\.m?js$/.test(ім) ? 'application/javascript' : ім.endsWith('.json') ? 'application/json' : 'application/octet-stream';
        return route.fulfill({status: 200, contentType: тип, body: б});
      }
    }
    if (з.resourceType() === 'image' && з.method() === 'GET') {
      const б = fs.readFileSync(path.join(ФІКС, 'синт.png'));
      події.push({url, вид: 'локально', файл: 'синт.png', sha256: sha256(б)});
      return route.fulfill({status: 200, contentType: 'image/png', body: б});
    }
    події.push({url, вид: 'заблоковано'});
    return route.abort('blockedbyclient');
  });
  await контекст.addInitScript(с => { Math.random = () => с / 1e6; }, СІД);
  const P = ГОДИННИК.початок_ms;
  /* годинник стоїть від засіву до розбору сторінки: адреса штампу збірки (`build.txt?t=Date.now()`) однакова в кожній ролі */
  await контекст.clock.install({time: P - ГОДИННИК.запас_до_початку_ms - 1000});
  await контекст.clock.pauseAt(P - ГОДИННИК.запас_до_початку_ms);
  стор = await контекст.newPage();
  cdp = await контекст.newCDPSession(стор);
  const помилкиСторінки = [];
  стор.on('pageerror', е => помилкиСторінки.push(String(е).slice(0, 300)));
  /* початкове сховище — на тому самому origin до відкриття продукту */
  await стор.goto(БАЗА + '/засів.html');
  await стор.evaluate(async сх => {
    for (const [к, з] of Object.entries(сх.localStorage)) localStorage.setItem(к, з);
    for (const [к, з] of Object.entries(сх.sessionStorage)) sessionStorage.setItem(к, з);
    for (const б of сх.indexedDB) {
      const d = await new Promise((р, в) => { const з = indexedDB.open(б.name, б.version);
        з.onupgradeneeded = е => { const db = е.target.result; for (const с of б.сховища) if (!db.objectStoreNames.contains(с.ім)) db.createObjectStore(с.ім, {keyPath: с.keyPath ?? undefined, autoIncrement: с.autoIncrement}); };
        з.onsuccess = () => р(з.result); з.onerror = () => в(з.error); });
      for (const с of б.сховища) {
        await new Promise((р, в) => { const t = d.transaction(с.ім, 'readwrite'); const s = t.objectStore(с.ім);
          for (const [к, з] of с.записи) с.keyPath == null ? s.put(з, к) : s.put(з); t.oncomplete = р; t.onerror = () => в(t.error); });
      }
      d.close();
    }
  }, СХОВИЩЕ);
  пиши('сховище засіяно');
  await стор.goto(БАЗА + '/index.html' + ВХІД.змінні.хеш, {waitUntil: 'domcontentloaded'});
  await контекст.clock.resume();
  await стор.waitForFunction(() => typeof Екран !== 'undefined' && Екран.стан && Екран.стан.запущено, null, {timeout: 120000});
  await стор.waitForTimeout(ВХІД.змінні.тиша_до_знімка_мс);
  await контекст.clock.pauseAt(P);
  const стан = await стор.evaluate(off.початковийЗнімок, СІД);
  знімокЗроблено = true;
  fs.writeFileSync(path.join(ВИХІД, 'початковий-стан.json'), JSON.stringify(стан, null, 1) + '\n');
  пиши('початковий стан записано', 'обмін до знімка:', обмінДоЗнімка);
  await стор.screenshot({path: path.join(ВИХІД, 'до-дії-390x844.png')}).catch(() => {});
  пиши('екран до дії:', JSON.stringify((await стор.evaluate(() => document.body.innerText)).slice(0, 600)));
  const кроки = [];
  for (const [і, дія] of ДІЇ.entries()) {
    const т = P + ГОДИННИК.кроки_ms[і];
    if (т > P || і > 0) await контекст.clock.pauseAt(т);
    const дата = await стор.evaluate(() => Date.now());
    кроки.push({номер: і + 1, дата_ms: дата, дія_sha256: ключЗапиту(дія)});
    await контекст.clock.resume();
    /* дія — DOM-клік елемента (однаково в кожній ролі; кандидат несе з main інший видимий інтерфейс #4681, старий екран у ньому схований) */
    if (дія.вид === 'клік') await стор.$eval(дія.селектор, е => е.click());
    else throw new Error('невідома дія ' + JSON.stringify(дія));
    пиши('дія', і + 1, JSON.stringify(дія));
  }
  fs.writeFileSync(path.join(ВИХІД, 'кроки.json'), JSON.stringify(кроки, null, 1) + '\n');
  /* до всіх кінцевих карток і остаточних текстів */
  const кінецьДо = Date.now() + 45 * 60000;
  let попереднє = null, сталих = 0, готово = false;
  while (Date.now() < кінецьДо && !зупинка) {
    await new Promise(р => setTimeout(р, 5000));
    const с = await стор.evaluate(() => ({готово: typeof ЗБ !== 'undefined' && !!ЗБ && !!ЗБ.готово,
      збій: typeof ЗБ !== 'undefined' && !!ЗБ && (ЗБ.діагноз || []).some(р => /^build · failed/.test(р)),
      карток: document.querySelectorAll('#картки .картка').length,
      текст: [...document.querySelectorAll('#картки .картка')].map(к => к.innerText).join('\n§\n') + '\n¶\n' + document.body.innerText}));
    if ((с.готово || с.збій) && вПольоті.size === 0 && Date.now() - останнійОбмін > 30000) {
      if (с.текст === попереднє) сталих++; else сталих = 0;
      if (сталих >= 3) { готово = true; break; }
    }
    попереднє = с.текст;
  }
  const виходи = await стор.evaluate(() => {
    const кк = [...document.querySelectorAll('#картки .картка')];
    return {кк: кк.map(к => к.innerText), тіло: document.body.innerText,
      успішних: typeof ЗБ !== 'undefined' && !!ЗБ && ЗБ.успіх === true && Array.isArray(ЗБ.картки)
        ? ЗБ.картки.filter(к => к && !к.збій).length : 0};
  });
  const карток = виходи.кк.length;
  fs.writeFileSync(path.join(ВИХІД, 'картки.txt'), виходи.кк.map((т, і) => '═══ картка ' + (і + 1) + ' з ' + карток + ' · видимий текст ═══\n' + т).join('\n\n') + '\n');
  fs.writeFileSync(path.join(ВИХІД, 'текст_екранів.txt'), '═══ екран після збирання ═══\n' + виходи.тіло + '\n');
  await стор.screenshot({path: path.join(ВИХІД, 'екран-390x844.png')}).catch(() => {});
  let повтор = null;
  if (читач) { try { повтор = читач.завершити(); } catch (е) { зупинка = зупинка || ('завершити: ' + е.message); } }
  fs.writeFileSync(path.join(ВИХІД, 'мережа.json'), JSON.stringify({встановлено_до_навігації: true, нагляд_усіх_запитів: true,
    ізольовано: true, знімок_до_першого_обміну: !обмінДоЗнімка, зовнішніх_доставок: 0,
    викликів_моделі: 0, події}, null, 1) + '\n');
  const доведено = готово && виходи.успішних === ВХІД.змінні.карток && !зупинка && !обмінДоЗнімка && карток === ВХІД.змінні.карток && запитів === віддано;
  fs.writeFileSync(path.join(ВИХІД, 'доказ.json'), JSON.stringify({формат: 1, run_id,
    подія: доведено ? 'OFF: видимі виходи збережено' : 'OFF: не завершено', кінець: new Date().toISOString(),
    вердикт: {доведено, ...(доведено ? {} : {чому: зупинка || (!готово ? 'не дочекався сталих текстів' : 'лічильники')})},
    обрив: зупинка, код: {збірка: штампи.збірка, відбиток: штампи.відбиток, каталог: штампи.каталог},
    входи: {сторінка: {sha256: sha256(html)}}, очікувано: {карток_кінцевих_OFF: ВХІД.змінні.карток},
    факт: {карток_кінцевих_OFF: карток, успішних_карток_OFF: виходи.успішних}, помилки_сторінки: помилкиСторінки}, null, 1) + '\n');
  fs.writeFileSync(path.join(ВИХІД, 'лог.txt'), лог.join('\n') + '\n');
  await браузер.close();
  off.квитанція(ТЕКА, РОЛЬ, {rc: доведено ? 0 : 1, запитів, віддано, повтор});
  пиши('КІНЕЦЬ', РОЛЬ, 'доведено', доведено, 'запитів', запитів, 'віддано', віддано, 'карток', карток, 'повтор', JSON.stringify(повтор), 'зупинка', зупинка);
  fs.writeFileSync(path.join(ВИХІД, 'лог.txt'), лог.join('\n') + '\n');
  завершитиСпробу({run_id, rc: доведено ? 0 : 1, перша_розбіжність});
  process.exit(доведено ? 0 : 1);
})().catch(е => {
  console.error(е);
  fs.writeFileSync(path.join(ВИХІД, 'лог.txt'), лог.join('\n') + '\nВИНЯТОК ' + (е.stack || е) + '\n');
  завершитиСпробу({run_id, rc: 2, перша_розбіжність: перша_розбіжність || {причина: е.message}});
  process.exit(2);
});
