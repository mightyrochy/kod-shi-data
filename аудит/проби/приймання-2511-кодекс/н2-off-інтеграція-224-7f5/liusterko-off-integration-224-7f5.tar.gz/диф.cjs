'use strict';

// Лише читання двох тек доказів. Ні мережі, ні браузера, ні відтворення.
const fs = require('node:fs');
const path = require('node:path');
const {sha256} = require('./доказ_прогону.js');

function порівнятиФайли(ліворуч, праворуч) {
  const прочитати = (тека, ім) => fs.readFileSync(path.join(тека, ім));
  const файли = Object.fromEntries(['картки.txt', 'текст_екранів.txt'].map(ім => {
    const а = прочитати(ліворуч, ім), б = прочитати(праворуч, ім);
    return [ім, {однакові: а.equals(б), ліворуч: {байтів: а.length, sha256: sha256(а)},
      праворуч: {байтів: б.length, sha256: sha256(б)}}];
  }));
  const журнали = [ліворуч, праворуч].map(т => JSON.parse(прочитати(т, 'мережа.json')).події);
  const обміни = журнали.map(ряд => ряд.filter(п => п.вид === 'обмін'));
  const різніОбміни = [];
  for (let і = 0; і < Math.max(...обміни.map(ряд => ряд.length)); і++) {
    const [а, б] = обміни.map(ряд => ряд[і]);
    if (а?.номер !== б?.номер || а?.запит_sha256 !== б?.запит_sha256 || а?.відповідь_sha256 !== б?.відповідь_sha256)
      різніОбміни.push({номер: і + 1, ліворуч: а || null, праворуч: б || null});
  }
  const ресурси = журнали.map(ряд => ряд.filter(п => ['локально', 'заблоковано'].includes(п.вид))
    .map(п => [п.вид, п.url, п.файл || '', п.sha256 || ''].join(' ')));
  const лишок = (а, б) => {
    const запас = [...б];
    return а.filter(п => {
      const і = запас.indexOf(п);
      if (і < 0) return true;
      запас.splice(і, 1);
      return false;
    });
  };
  return {файли, обмінів: обміни.map(ряд => ряд.length), різніОбміни,
    ресурси: {лише_ліворуч: лишок(...ресурси), лише_праворуч: лишок(...ресурси.reverse())}};
}

if (require.main === module) {
  const [ліворуч, праворуч] = process.argv.slice(2);
  try {
    if (!ліворуч || !праворуч) throw new Error('Вжиток: node диф.cjs ЛІВА_ТЕКА_РОЛІ ПРАВА_ТЕКА_РОЛІ');
    console.log(JSON.stringify(порівнятиФайли(ліворуч, праворуч), null, 2));
  } catch (е) {
    console.error(е.message);
    process.exitCode = 2;
  }
}
module.exports = {порівнятиФайли};
