'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const off = require('./off.cjs');
const {sha256} = require('./доказ_прогону.js');
const {перевіритиІсторію, читатиПлан} = require('./інтеграція.cjs');
const {ролі} = require('./журнал.cjs');
const очікування = require('./очікування.json');

const [історія, html, тека] = process.argv.slice(2);
assert(історія && html && тека, 'Вжиток: node план.cjs ІСТОРИЧНА_ТЕКА 912.html НОВА_ТЕКА');
const джерело = fs.realpathSync(історія), новаТека = path.resolve(тека);
const батько = fs.realpathSync(path.dirname(новаТека));
const вихід = path.join(батько, path.basename(новаТека));
assert(вихід !== джерело && !вихід.startsWith(джерело + path.sep) && !джерело.startsWith(вихід + path.sep),
  'Теки історії й інтеграції мають бути окремими');
перевіритиІсторію(джерело, html);
fs.mkdirSync(вихід);
for (const ім of ['повтор.json', 'канал.json', 'фікстура.json', 'фікстури'])
  fs.cpSync(path.join(джерело, ім), path.join(вихід, ім), {recursive: true, errorOnExist: true, force: false});
for (const ім of ['контролер.cjs', '782c-хід1-лог.txt'])
  fs.copyFileSync(path.join(__dirname, ім), path.join(вихід, ім), fs.constants.COPYFILE_EXCL);
const час = JSON.parse(fs.readFileSync(path.join(вихід, 'фікстури/годинник.json')));
const вхід = JSON.parse(fs.readFileSync(path.join(вихід, 'повтор.json')));
const темпХеш = sha256(fs.readFileSync(path.join(джерело, 'джерело/виклики-каналу.json')));
off.write(вихід, 'налаштування-часу.json',
  {годинник: час, тиша_до_знімка_мс: вхід.змінні.тиша_до_знімка_мс, темп_джерела_sha256: темпХеш});
const хеш = ім => sha256(fs.readFileSync(path.join(вихід, ім)));
off.write(вихід, 'наперед.json', {версія: 1, походження: 'відтворення запису 912', ролі,
  контролер_sha256: хеш('контролер.cjs'), налаштування_часу_sha256: хеш('налаштування-часу.json'),
  темп_джерела_sha256: темпХеш, невдала_782c_спроба_sha256: очікування.історична_невдала_спроба_sha256});
console.log(JSON.stringify({план_sha256: читатиПлан(вихід, темпХеш).планХеш, K: 0, N: 0}));
