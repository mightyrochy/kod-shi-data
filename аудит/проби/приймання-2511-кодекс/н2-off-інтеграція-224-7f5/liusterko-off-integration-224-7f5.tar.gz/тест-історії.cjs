'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const {перевіритиІсторію} = require('./інтеграція.cjs');

const [історія, html] = process.argv.slice(2);
if (!історія || !html) throw new Error('Вжиток: node тест-історії.cjs ІСТОРИЧНА_ТЕКА_С5 912.html');
const спроба = тека => перевіритиІсторію(тека, html);
const файлРолі = (тека, роль) => path.join(тека, роль, 'VIDPOVIDI/обмін/00011.json');

function змінитиЛишеКонверт(тека, роль) {
  const файл = файлРолі(тека, роль);
  const з = JSON.parse(fs.readFileSync(файл));
  const тіло = з.відповідь.body;
  assert.equal(з.відповідь.status, 200);
  з.відповідь.status = 201;
  з.відповідь.headers['x-images-dropped'] = '999';
  fs.writeFileSync(файл, JSON.stringify(з, null, 1) + '\n');
  assert.equal(JSON.parse(fs.readFileSync(файл)).відповідь.body, тіло);
  assert(fs.readFileSync(path.join(тека, роль, 'off.json'))
    .equals(fs.readFileSync(path.join(історія, роль, 'off.json'))));
}

const оригінал = спроба(історія);
assert.equal(оригінал.обмінів_перевірено, 18);
const тека = fs.mkdtempSync(path.join(os.tmpdir(), 'н2-копія-історії-'));
try {
  fs.cpSync(історія, тека, {recursive: true});
  змінитиЛишеКонверт(тека, 'база');
  assert.throws(() => спроба(тека), /Підмінено байти історичного обміну #4717: база\/00011\.json/);
  змінитиЛишеКонверт(тека, 'джерело');
  assert.throws(() => спроба(тека), /Підмінено байти історичного обміну #4717: джерело\/00011\.json/);
  console.log('3 статичні контроли реального архіву: оригінал 18/18, підміна конверта бази, спільна підміна обох ролей.');
} finally {
  fs.rmSync(тека, {recursive: true, force: true});
}
