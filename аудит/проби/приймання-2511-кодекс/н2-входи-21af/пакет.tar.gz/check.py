"""One real legacy judge per outfit. Emit only the facts named in this review."""
import json
import sys
from unittest.mock import patch
from ядро import пул, знання, суд, розбір
from ядро.тести.тест_н2 import _запис, _збір
from ядро.поняття import Ситуація
import суд_від_моделі as legacy
from колір_світлота import перевірка_value_за_слотом

def check(case):
    colours = {'grey': ([40,0,0], '#5e5e5e'), 'red': ([55,65,40], '#e23234')}
    rows = []
    clothes = [('top','верх','сорочка'),('bottom','низ','штани')] if case in ('two_large','diverges','clean_steps') else [('dress','сукня','сукня')]
    for ident, slot, kind in clothes + [('shoes','взуття','лофери'), ('bag','сумка','сумка')]:
        accented = ident == 'bag' and case in ('red','two_red','unknown_shoe') or ident == 'shoes' and case == 'two_red'
        lab, hexcolour = colours['red' if accented else 'grey']
        if (case == 'diverges' and ident == 'bag' or case == 'clean_steps' and ident == 'bottom'):
            lab, hexcolour = [85,0,0], '#d4d4d4'
        fibre = 'шкіра' if ident == 'bag' and case == 'mixed_fibre' else 'бавовна'
        colour = dict(колір_тип='вимір',колір_джерело='фото',lab=lab,hex=hexcolour)
        if case=='unknown_shoe' and ident=='shoes':
            colour = {}
        rows.append(_запис(ident,slot,тип=kind,волокно=fibre,**colour))
    scene = Ситуація(1, {}, {})
    pool = пул.зібрати(scene, 1, 37, rows)
    outfit, = розбір.прочитати(_збір(pool, *(r['id'] for r in rows)), 'складання', pool)
    captured = []
    original = legacy.перевірити_від_моделі
    def capture(*args, **kwargs):
        result = original(*args, **kwargs)
        captured.append(result)
        return result
    enumerations = []
    def observe(frame,event,arg):
        if event!='return' or frame.f_code is not перевірка_value_за_слотом.__code__:
            return
        variants = frame.f_locals.get('виходи')
        if variants is not None:
            enumerations.append([[s['code'] for f in result for s in f.get('заяви', ())] for result in variants])
    previous = sys.getprofile()
    try:
        sys.setprofile(observe)
        with patch.object(legacy, 'перевірити_від_моделі', side_effect=capture):
            verdict = суд.судити(outfit, scene, pool, {})
    finally:
        sys.setprofile(previous)
    assert len(captured) == 1 and captured[0]['перевірено']
    raw = captured[0]
    names = {'single_focus','lightness_steps','accent_echo','accent_surfaces_differ','declared_column_known','texture_adds','genre_dominant'}
    cells = {p['що']: p['стан'] for g in ['надлишок','прісність','аксесуари'] for p in raw['чеклісти'][g] if p['що'] in names}
    findings = { (f['правило'],c['code'],f.get('сила')) for f in знання._знахідки(raw)
                 if f['правило'] in ('K-COL-01','K-COL-05','K-ACC-10') for c in f['заяви'] }
    after = {k:v for k,v in verdict.чекліст.items() if k.split('.')[-1] in names}
    after_findings = sorted({(f.правило,f.код) for f in verdict.заяви if f.правило in ('K-COL-01','K-COL-05','K-ACC-10')})
    requests = [s['values'].get('fields') for f in знання._знахідки(raw) if f['правило']=='K-ACC-10' for s in f['заяви'] if s['code']=='rule_input_missing']
    resolved = {r['н']:r['ід'] for r in outfit.речі}
    subjects = [(f.код,[resolved[n] for n in f.речі],f.значення.get('гілка')) for f in verdict.заяви if f.правило in ('K-COL-01','K-COL-05','K-ACC-10')]
    return {'lightness_variant_codes':enumerations,'judge_calls':len(captured),'subjects':subjects,'K-ACC-10_requested_fields': requests,'legacy': cells, 'n2': after, 'legacy_findings': sorted(findings,key=repr),'n2_findings': after_findings}
if __name__=='__main__':
    cases = ('red','grey','two_red','mixed_fibre','two_large','unknown_shoe','diverges','clean_steps')
    defaults = {case:check(case) for case in cases}
    backwards = {g:dict(reversed(tuple(items.items()))) for g,items in reversed(tuple(знання.ЧЕКЛІСТИ.items()))}
    test_order = '--base' not in sys.argv
    if test_order:
        with patch.object(знання,'ЧЕКЛІСТИ',backwards), patch.object(знання,'ПРАВИЛА',dict(reversed(tuple(знання.ПРАВИЛА.items())))):
            assert {case:check(case) for case in cases} == defaults
        assert defaults['red']['subjects'] == [('accent_orphan',['bag'],'сирота')]
        assert defaults['two_large']['subjects'] == [('one_lightness_level_reads_flat',['top','bottom'],'перебір_світлоти')]
        assert defaults['two_red']['n2']['accessories.accent_surfaces_differ'] == {'стан':'немає_входу','поле':'заявлена_колона'}
        assert ['заявлена_колона'] in defaults['two_red']['K-ACC-10_requested_fields']
        assert not any(defaults[c]['subjects'] for c in ['grey','mixed_fibre','unknown_shoe','diverges','clean_steps'])
        assert defaults['clean_steps']['legacy']['lightness_steps'] == 'пройдено'
        assert defaults['diverges']['legacy']['lightness_steps'] == 'без входу'
    print(json.dumps({'reordered_equal':True if test_order else None,'cases':defaults}, ensure_ascii=False, indent=2))
