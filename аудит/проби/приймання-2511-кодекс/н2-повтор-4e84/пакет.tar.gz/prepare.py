"""Use only local Git source objects. Retain selected fields from existing archive."""
from pathlib import Path
import subprocess,json,hashlib,sys
d=Path(__file__).resolve().parent
repo=sys.argv[1]
def show(ref,path):
    return subprocess.check_output(['git','-C',repo,'show',ref+':'+path])
base='224bf4efc78c21e35d904963d1e8c6b820ec3545'
path='аудит/проби/Живий-через-міст/стенд/службове/с8_мінус_десять_сніг/обміни.jsonl'
lines=show(base,path).splitlines(); hashes={}
for i in (14,23):
    row=json.loads(lines[i]); req=json.loads(row['запит']); obj=json.loads(req['messages'][0]['content'][0]['text'])
    if i==14:obj={'person':{'palette':{k:obj['person']['palette'][k] for k in ('slot_roles','kind_colours','colour_kinds','base')}}}
    else:obj={'outfit':{'id':obj['outfit']['id'],'items':[{'n':r['n']} for r in obj['outfit']['items']]},'ways_to_wear':[{'item':r['item'],'statements':[{k:s[k] for k in ('code','values')} for s in r['statements']]} for r in obj['ways_to_wear']]}
    (d/f'archive-{i}.json').write_text(json.dumps(obj,ensure_ascii=False,indent=2))
    hashes[str(i)]={'physical_line':i+1,'http':row['статус'],'sha256_without_lf':hashlib.sha256(lines[i]).hexdigest()}
(d/'archive-source.json').write_text(json.dumps({'sha':base,'path':path,'rows':hashes},indent=2,ensure_ascii=False))
old='972077ca2c1c3529251b5dc4ee394e2fa9885e27'
(d/'oldsrc').mkdir(exist_ok=True)
for name in ('brief.py','міст_пакет.py'):
    (d/'oldsrc'/name).write_bytes(show(old,'джерела/'+name))
