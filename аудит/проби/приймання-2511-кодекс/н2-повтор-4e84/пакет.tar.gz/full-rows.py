import json
from pathlib import Path
from ядро.тести.тест_н2 import ЗаписІПул
d=Path(__file__).resolve().parent
ids=['ж-00408@feelyou.com.ua','ж-05273@bella-bicchi.com','ж-09421@favoriteshoes.com.ua','ж-08039@welfare.ua','ж-08337@morandi.ua','ж-07735@honchstudio.com']
ЗаписІПул.setUpClass()
rs={r['id']:r for r in ЗаписІПул.каталог if r['id'] in ids}
(d/'o6-typed.fixture').write_text(repr([rs[i] for i in ids]))
