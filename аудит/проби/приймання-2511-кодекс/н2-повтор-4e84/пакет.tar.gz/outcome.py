"""Run in its own directory with exact 4e84 sources in PYTHONPATH and prepared inputs."""
from ast import literal_eval
from copy import deepcopy
from pathlib import Path
import json
from ядро import пул,річ,розбір,запит,суд
from ядро.перекладач_паспорта import з_входу
from ядро.тести import тест_н2 as u
D=Path(__file__).resolve().parent
raw=literal_eval((D/'o6-typed.fixture').read_text())
expected=json.loads((D/'archive-23.json').read_text())
ids=[r['id'] for r in raw];old=dict(zip(ids,[r['n'] for r in expected['outfit']['items']],strict=True));coat,scarf=ids[1],ids[4]
def statements(rows):
    return {r['item']:[{k:s[k] for k in ('code','values')} for s in r['statements']] for r in rows if 'statements' in r}
arch=statements(expected['ways_to_wear'])
res={}
for mode in ('flat','absent','no_collar','nested','broken_tags','broken_upper','bad_heel'):
    records=deepcopy(raw);x=records[1]
    if mode=='absent':x.pop('комір')
    if mode=='no_collar':x['комір']='без_коміра'
    if mode=='nested':x['ознаки_зі_слів']={'верхні':{'комір':x.pop('комір')}}
    if mode in ('broken_tags','broken_upper'):
        x.pop('комір');x['ознаки_зі_слів']=['broken'] if mode=='broken_tags' else {'верхні':['broken']}
    if mode=='bad_heel':records[2].update(каблук=None,каблук_см='бите')
    day=з_входу({});p=пул.зібрати(day,1,37,records);aliases=u._облік(p)
    if mode in ('broken_tags','broken_upper','bad_heel'):
        target=ids[2] if mode=='bad_heel' else coat;assert set(aliases)==set(ids)-{target}
        bad,=p.відкинуто; errors=[e['поле'] for e in bad['заяви']]
        field={'broken_tags':'ознаки_зі_слів','broken_upper':'ознаки_зі_слів.верхні','bad_heel':'каблук_см'}[mode]
        assert bad['причина']=='bad_record' and field in errors,(mode,bad)
        res[mode]={'kept':len(aliases),'rejected':bad['ід'],'reason':bad['причина'],'fields':errors}
        continue
    assert set(ids)==set(aliases) and not p.відкинуто
    sequence=[aliases[i] for i in ids];o,=розбір.прочитати(u._відповідь(outfits=[{'id':'o6','items':sequence}]),'складання',p)
    v=суд.судити(o,day,p,{});q=запит.запит('опис',p,day,{},образи=(o,),вироки={'o6':v},без_фото=True)
    w=json.loads(q.модель['messages'][0]['content'])
    assert w['outfit']['id']=='o6' and [r['n'] for r in w['outfit']['items']]==sequence
    def archive_labels(obj):
        if isinstance(obj,dict):return {archive_labels(k):archive_labels(v) for k,v in obj.items()}
        if isinstance(obj,list):return [archive_labels(x) for x in obj]
        return dict(zip(sequence,[old[i] for i in ids])).get(obj,obj)
    actual=archive_labels(statements(w['ways_to_wear']));assert actual[old[scarf]]==arch[old[scarf]]
    if mode in ('flat','nested'):assert actual[old[coat]]==arch[old[coat]]
    else:assert old[coat] not in actual
    fact=p.записи[aliases[coat]].поля['комір']
    res[mode]={'fact':fact.значення,'source':fact.джерело,'path':fact.з_чого,'eligible':len(aliases),'outfit_id':o.ід,'real_numbers':sequence,'coat_codes':[r['code'] for r in actual.get(old[coat],[])],'scarf_pairs_equal':len(actual[old[scarf]])}
(D/'o6-results.json').write_text(json.dumps(res,ensure_ascii=False,indent=2))
print('six selected, sources, 2/8, negative, broken containers and genuine bad_heel: PASS')
