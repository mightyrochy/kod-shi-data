"""Run with PYTHONPATH set to exact candidate джерела; offline, no transport."""
from pathlib import Path
from unittest.mock import patch
import json, copy, importlib.util, sys
import brief, міст_пакет as bridge
from ядро import річ, суд, запит, знання
from ядро.тести import тест_н2 as u
from dataclasses import replace

D=Path(__file__).resolve().parent
base=json.loads((D/'archive-14.json').read_text())['person']['palette']
src=json.loads((D/'archive-23.json').read_text())
opt={"база":"графіт","база_назва":"графіт","база_hex":"#4b4b4b","база_тип":"нейтраль"}
cols={"шкіра":["#dbab95"],"волосся":["#473227"],"очі":"#625448"}
real=bridge._поля_палітри_ядра
t=u.ДоговірН2();t.setUp()
snap={}
def intercept(pk,branch,spec,inp,scene):
    snap.update(pk=pk,branch=branch,spec=spec,inp=inp,scene=scene)
    return real(pk,branch,spec,inp,scene)
def palette(choice,colors=cols):
    raw={"профіль":{"колір":colors,"палітра":{"схема":"нейтрали+акцент","вибір_кольору":choice}}}
    with patch.object(bridge,'_поля_палітри_ядра',intercept):
        features,plan=u.підготувати_портрет_і_палітру(raw)
    day=u.з_входу(raw,план_палітри=plan,риси_портрета=features)
    body=json.loads(запит.запит("складання",t.пул,day,{}).модель["messages"][0]["content"])
    return {k:v for k,v in body['person']['palette']['value'].items() if k in ('base','slot_roles','colour_kinds','kind_colours')},any(x.get('обрана_основа') for x in plan['вікна'])
a,window=palette(dict(opt,база_стилістки=True)); assert not window
saved=snap.copy()
for k in a: assert a[k]==base[k],k
b,_=palette(opt); c,_=palette(None); assert b==dict(a,base=dict(a['base'],chosen_by='unknown'));assert c=={k:v for k,v in a.items() if k!='base'}
n,_=palette(opt,{});assert n=={'base':b['base']}
no_spec=real(saved['pk'],saved['branch'],None,saved['inp'],saved['scene']);assert no_spec=={'base':a['base']}
spec=importlib.util.spec_from_file_location("oldbrief",D/'oldsrc/brief.py')
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
res={}
for f,name in [(old.бриф,'old'),(brief.бриф,'new')]:
    from collections import Counter
    calls=Counter()
    def counter(fr,event,arg):
        if event=='call' and fr.f_code.co_name=='бриф' and Path(fr.f_code.co_filename).name=='brief.py':calls['body']+=1
    with patch.object(sys,'getprofile',sys.getprofile):
        sys.setprofile(counter)
        try:
            v1=f(saved['pk'],гілка=saved['branch']);v2=f(saved['pk'],гілка=saved['branch'])
        finally:sys.setprofile(None)
    assert v1==v2
    res[name]={'calls':2,'body_calls':calls['body'],'counter_api':hasattr(f,'лічильник'),'reset_api':hasattr(f,'скинути')}
    if name=='old':refbrief=v1
    else:assert v1==refbrief
report={'palette_archive14_equal':list(a),'palette_positive':a,'no_author':b['base'],'no_choice':list(c),'no_spec':no_spec,'tonal_base_window':window,'old_brief':res}
(D/'palette.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print('palette and brief:',res)
# Evaluate only the two source expressions factored out of the historical legacy bridge.
import ast
legacy=ast.parse((D/'oldsrc/міст_пакет.py').read_text())
for name,node in [(type(n).__name__,n) for n in ast.walk(legacy) if isinstance(n,(ast.ListComp,ast.Call)) and n.lineno in (2046,2104)]:
    if name=='ListComp' and node.lineno==2046:old_accent=node
    if name=='Call' and getattr(node.func,'attr','')=='заява' and node.args and getattr(node.args[0],'value',None)=='scheme_needs_colour':old_claim=node
def ex(node,ctx):return eval(compile(ast.Expression(node),'972077ca:міст_пакет.py','eval'),ctx)
for spec in (saved['spec'],{'слоти':{}}):
    acc=ex(old_accent,{'_сп0':spec['слоти']});assert acc==bridge._акцентні_слоти(spec)
    scheme=saved['spec']['схема']; old_claim_json=ex(old_claim,{'_ВМ':bridge._ВМ,'_акц0':acc,'схема':scheme})
    assert old_claim_json==bridge._заява_носіїв(scheme,acc)
report['legacy_accent_and_claim_source_expressions_on_selected_and_empty_slots']='equal'
(D/'palette.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
