import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";

const tree = process.argv[2];
const source = fs.readFileSync(`${tree}/джерела/показ/ядро.js`, "utf8");
const match = /^function карткаЯдраНаЕкранП\(кя, сід\)\{[\s\S]*?^\}/m.exec(source);
assert.ok(match);
const project = vm.runInNewContext(`(${match[0]})`, {
  повідомленняОписуБезФотоП: () => Object.freeze({ fixture: "description_without_photos" }),
});
const results = {};
for (const name of ["held-70", "registered-mixed"]) {
  const card = JSON.parse(fs.readFileSync(`outputs/${name}/card.json`, "utf8"));
  const screenCard = project(card, 37);
  const held = card.невідоме.filter(item => item.утримано);
  const questions = screenCard.питання.flatMap(q => q.повідомлення.statements.map(z => z.code));
  assert.equal(held.length, name === "held-70" ? 1 : 3);
  assert.ok(questions.includes("rule_input_missing"));
  if (name === "registered-mixed") assert.equal(questions.filter(s => s === "fabric_out_of_season").length, 4);
  assert.ok(held.every(z => !questions.includes(z.код)));
  assert.deepEqual(screenCard.невідоме.filter(z => z.утримано), held);
  results[name] = { held_codes: held.map(z => z.код), question_codes: questions, raw_unknown_count: screenCard.невідоме.length };
}
fs.writeFileSync("display.json", JSON.stringify(results, null, 2) + "\n");
console.log("FAIL screen adapter: both held codes are absent from the input to the card questions; ordinary controls are retained.");
