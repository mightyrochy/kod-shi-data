#!/usr/bin/env bash
set -euo pipefail
tree=$(cd "$1" && pwd)
baseline=$(cd "$2" && pwd)
cd "$(dirname "$0")"
while read -r hash file; do
 test "$(git hash-object "$tree/$file")" = "$hash"
done < blobs.txt
export PYTHONPATH="$tree/джерела" PYTHONHASHSEED=0 PYTHONDONTWRITEBYTECODE=1
python3 probe.py | tee receipt.log
python3 звірити_докази.py "$baseline"
node display.mjs "$tree"
python3 addresses.py
