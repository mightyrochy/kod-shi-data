import json
from pathlib import Path

base = Path("outputs/held-70")
result = {}
for kind in ("ремонт", "вибір", "опис"):
    body = json.loads((base / f"{kind}.json").read_text())
    table = body.get("pool") or body["candidates"]
    rows = [dict(zip(table["cols"], r, strict=True)) for r in table["rows"]]
    expected = body["verdict"][0]["items"]
    row, = [f for f in body["verdict"][0]["findings"] if f["code"] == "outer_edges_gap_measured"]
    supplied = [it["item_id"] for it in row["values"]["items"]]
    addr = {r["n"] for r in rows}
    assert "id" not in table["cols"] and "item_id" not in table["cols"]
    assert set(row["items"]) <= addr and set(row["items"]) <= set(expected)
    assert set(supplied).isdisjoint(addr)
    if body.get("outfit"):
        assert all("id" not in item and "item_id" not in item for item in body["outfit"]["items"])
    result[kind] = {"table_labels": sorted(addr), "top_level_item_refs": row["items"],
                    "nested_item_ids": supplied, "nested_exact_matches": sorted(set(supplied) & addr)}
Path("addresses.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print("Nested values.items.item_id: 0/2 exact matches in each of the three full prompt address tables. Top-level references: 2/2.")
