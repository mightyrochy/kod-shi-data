from collections import Counter
import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parent
reference = Path(sys.argv[1]) / "outputs"
wanted = {
    "0": ("немає_входу", 0, []),
    "1": ("немає_входу", 1, []),
    "held-70": ("суджено", 2, [("outer_edges_gap_measured", 0, True)]),
    "pass-60": ("суджено", 2, []),
    "fail-93": ("суджено", 2, [("outer_edges_nearly_coincide", .31, False)]),
    "na": ("нема_чого", 1, []),
    "registered-mixed": ("суджено", 2, [("fabric_out_of_season", .25, False)] * 4
                         + [("fabric_season_not_judged_indoors", 0, True)] * 3),
}
def load(directory, stem):
    return json.loads((directory / f"{stem}.json").read_bytes())
for label, (status, length_fields, expectation) in wanted.items():
    d = root / "outputs" / label
    court, card, legacy = (load(d, n) for n in ("verdict", "card", "legacy"))
    if label != "na":
        previous = load(reference / label, "legacy")
        assert legacy == previous, label
        assert load(d, "input") == load(reference / label, "input"), label
    assert sum("." in key for key in court["чекліст"]) == 61
    assert all(row["стан"] in {"суджено", "немає_входу", "нема_чого"}
               and (row["стан"] != "немає_входу" or row.get("поле")) for row in court["чекліст"].values())
    hems = court["чекліст"]["excess.layer_hems_apart"]
    assert hems["стан"] == status
    actual_lengths = [r for r in legacy["args"][2] if r["слот"] in ("сукня", "верхній_шар")
                      and r.get("довжина_виробу_см") is not None]
    assert len(actual_lengths) == length_fields
    if status == "немає_входу":
        assert set(hems["поле"].split(", ")) == {"довжина_виробу_см", "довжина_виробу_точка"}
        assert legacy["measured_gap"] == [None, None, "edge_not_measured"]
    target = "K-MAT-03" if label == "registered-mixed" else "K-OUT-03"
    accepted = [z for z in court["заяви"] if z["правило"] == target]
    signature = lambda z: (z["код"], z["значення"]["вага"], z["значення"].get("утримано", False))
    assert Counter(map(signature, accepted)) == Counter(expectation)
    by_id = {z["ід"]: z for z in accepted}
    assert len(by_id) == len(accepted)
    addresses = {row["н"]: row["ід"] for row in card["речі"]}
    unknown = [z for z in card["невідоме"] if z.get("правило") == target]
    finding = [z for z in card["заяви_картки"] if z.get("правило") == target]
    assert len(unknown) + len(finding) == len(by_id)
    for z in unknown + finding:
        expected = by_id[z["ід"]]
        assert z["речі"] == [addresses[n] for n in expected["речі"]]
        assert z["значення"] == expected["значення"]["факти"]
        assert z["вага"] == expected["значення"]["вага"]
        assert (z in unknown) == expected["значення"].get("утримано", False)
    for kind in ("ремонт", "вибір", "опис"):
        prompt = load(d, kind)
        wire = prompt["verdict"][0]
        routed = [z for z in wire["findings"] if z["rule"] == target]
        assert len(routed) == len(by_id) and {z["id"] for z in routed} == by_id.keys()
        assert wire["checklist"] == court["чекліст"]
        for z in routed:
            expected = by_id[z["id"]]
            assert z["items"] == expected["речі"]
            assert z["values"] == expected["значення"]["факти"]
            assert z["weight"] == expected["значення"]["вага"]
            if z.get("withheld"):
                assert z["weight"] == 0 and not z.get("repair")
                assert "withheld" in prompt["knowledge_legend"]
                if kind == "вибір":
                    assert z["id"] not in {r["id"] for refs in prompt["remarks_by_code"].values() for r in refs}
            elif kind == "вибір":
                assert z["id"] in {r["id"] for refs in prompt["remarks_by_code"].values() for r in refs}
    if label == "registered-mixed":
        assert {tuple(z["речі"]) for z in unknown} == {("dress",), ("shoes",), ("bag",)}
    elif label == "held-70":
        z, = unknown
        assert z["значення"]["gap_cm"] == 30 and z["значення"]["error_cm"] == 21.34
        assert z["речі"] == ["coat", "dress"]
    print(label, hems, len(finding), len(unknown), "3/3 full requests")
print("PASS Python: 7 cases / 21 full requests / 7 card payloads / 6 identical legacy outputs.")
