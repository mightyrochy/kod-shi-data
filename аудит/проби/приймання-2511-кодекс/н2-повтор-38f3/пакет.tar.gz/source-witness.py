"""Trace the shop composition and fibre word on one existing fixture offer."""
import ast,gzip,json,tempfile,sys
from pathlib import Path
from copy import deepcopy
import xml.etree.ElementTree as ET
import фід_розбір as reader, фід_атрибути as attrs, verify
from ядро import річ
D=Path(__file__).resolve().parent;root=Path(reader.__file__).resolve().parent.parent
records=ast.literal_eval((D/'o6-typed.fixture').read_text())
dress=records[0];target=dress['id'].split('@')[0]
with tempfile.TemporaryDirectory() as td:
    with gzip.open(root/'каталог_повний.xml.gz') as stream:
        z=ET.parse(stream)
    offers=z.getroot().find('.//offers')
    for item in list(offers):
        if item.get('id')!=target:offers.remove(item)
    path=Path(td)/'one.xml';z.write(path,encoding='utf-8')
    got=reader.офери_фіду(str(path));off=got[0] if isinstance(got,list) else next(iter(got.values()))
    def projection(o):
        o=deepcopy(o);o.pop('запис_речі',None)
        rec=reader.побудувати_запис_речі(o)
        return {'material':rec['матеріал'],'material_witness':rec['матеріал_за_чим'],'fiber':rec['ознаки_зі_слів']['волокно']}
    original=projection(off)
    word,keys=attrs.слова_з_param(off)
    import re
    other=deepcopy(off)
    other['назва']=re.sub(r'трикотаж\w*','',off['назва'],flags=re.I)
    changed=projection(other)
    assert original['material']==changed['material']==dress['матеріал']
    assert original['material_witness']==changed['material_witness']==['param склад']
    assert original['fiber']==dress['волокно']
    chk=річ.читати(dress).поля['тканина']
    res={'id':dress['id'],'original':original,'only_knit_word_removed_from_title':changed,
         'composition_alone_yields_fiber':verify.волокно_зі_слова(original['material']),
         'product_fact':{'value':chk.значення,'source':chk.джерело,'witness':chk.з_чого},
         'title_contributes':original['fiber']!=changed['fiber']}
    assert res['title_contributes'] and res['original']['fiber']=='трикотаж'
    assert res['composition_alone_yields_fiber']==res['only_knit_word_removed_from_title']['fiber']=='еластан'
    assert chk.значення=='трикотаж' and chk.джерело=='крамниця' and not chk.з_чого
    # The same native table builder/reader as the fixed six-row contract. Only the title changes.
    import таблиця_збирання as builder, таблиця_каталогу as table
    variant=Path(td)/'title_only.xml'
    name=offers[0].find('name')
    name.text,n=re.subn(r'трикотаж\w*','',name.text,flags=re.I)
    assert n==1
    z.write(variant,encoding='utf-8')
    def rebuilt(path):
        result=builder.зібрати(str(path),str(root/'джерела'))
        record,=table.відновити(result,reader.офери_фіду(str(path)))['каталог']
        f=річ.читати(record).поля['тканина']
        return {'value':f.значення,'source':f.джерело,'witness':list(f.з_чого),
                'composition':record['матеріал'],'composition_witness':record['матеріал_за_чим']}
    before,after=rebuilt(path),rebuilt(variant)
    assert before['value']=='трикотаж' and after['value']=='еластан', (before,after)
    assert before['source']==after['source']=='крамниця' and before['witness']==after['witness']==[]
    assert before['composition']==after['composition']==dress['матеріал']
    assert before['composition_witness']==after['composition_witness']==['param склад']
    res['stock_table_and_ch2']={'before':before,'after':after}
    season=[]
    for rec in records:
        f=річ.читати(rec).поля['сезон_тканини']
        if rec.get('сезон_за_чим'):
            assert f.джерело=='код' and list(f.з_чого)==rec['сезон_за_чим']
            season.append({'id':rec['id'],'source':f.джерело,'words':list(f.з_чого)})
    res['season_witnesses']=season
    print(json.dumps(res,ensure_ascii=False))
    (D/'provenance.json').write_text(json.dumps(res,ensure_ascii=False,indent=2))
