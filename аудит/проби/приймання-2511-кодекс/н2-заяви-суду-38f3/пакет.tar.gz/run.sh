#!/usr/bin/env bash
set -euo pipefail
tree=${1:-/tmp/liusterko-n2-38f3/tree}
tree=$(cd "$tree" && pwd)
cd "$(dirname "$0")"
while read -r hash file; do
 test "$(git hash-object "$tree/$file")" = "$hash"
done < blobs.txt
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 PYTHONPATH="$tree/джерела" python3 probe.py | tee receipt.log
