from pathlib import Path
from dataclasses import replace
from copy import deepcopy
import json
from ядро import пул,річ,розбір,запит,суд
from ядро.перекладач_паспорта import з_входу
from ядро.тести import тест_н2 as u
D=Path(__file__).resolve().parent
from ast import literal_eval
raw=literal_eval((D/'o6-typed.fixture').read_text())
arch=json.loads((D/'archive-23.json').read_text())
ids=[r['id'] for r in raw]; orig=dict(zip(ids,[r['n'] for r in arch['outfit']['items']]))
coat,scarf=ids[1],ids[4]
def standard(rows):
    return {r['item']:[{'code':s['code'],'values':s['values']} for s in r['statements']] for r in rows if 'statements' in r}
expected=standard(arch['ways_to_wear'])
result={}
for mode in ('real','absent','no_collar','nested','broken_tags','broken_upper'):
    records=deepcopy(raw); c=records[1]
    if mode=='absent':del c['комір']
    if mode=='no_collar':c['комір']='без_коміра'
    if mode=='nested':c['ознаки_зі_слів']={'верхні':{'комір':c.pop('комір')}}
    if mode.startswith('broken'):
        c.pop('комір')
        c['ознаки_зі_слів']=['broken'] if mode=='broken_tags' else {'верхні':['broken']}
        try:r=річ.читати(c)
        except Exception as e:result[mode]={'exception':type(e).__name__,'message':str(e)}
        else:result[mode]={'value':r.поля['комір'].значення}
        try:пул.зібрати(з_входу({}),1,37,records)
        except Exception as e:result[mode]['pool_exception']=type(e).__name__
        continue
    day=з_входу({})
    p=пул.зібрати(day,1,37,records)
    if mode=='real':
        result['stock_pool']={'eligible':len(p.речі),'excluded':[{k:x[k] for k in ('ід','причина','заяви')} for x in p.відкинуто]}
    # Explicit Ch4-only input: preserve unmodified Ch2 facts/diagnostics; stage Ch3 already excluded real items.
    items=tuple({'ід':i,'н':orig[i],'ранг':n,'за':None,'джерело_рангу':(),'факти_рангу':{}} for n,i in enumerate(ids))
    p=replace(p,речі=items,записи={orig[r['id']]:річ.читати(r) for r in records})
    o,=розбір.прочитати(u._відповідь(outfits=[{'id':'o6','items':list(orig.values())}]),'складання',p)
    verdict=суд.судити(o,day,p,{})
    q=запит.запит('опис',p,day,{},образи=(o,),вироки={'o6':verdict})
    wire=json.loads(q.модель['messages'][0]['content'])
    ways=standard(wire['ways_to_wear']); fact=p.записи[orig[coat]].поля['комір']
    assert ways[orig[scarf]]==expected[orig[scarf]],ways
    if mode in ('real','nested'):assert ways[orig[coat]]==expected[orig[coat]],ways
    else:assert orig[coat] not in ways,ways
    result[mode]={'fact':fact.значення,'source':fact.джерело,'path':fact.з_чого,'ways_to_wear':ways}
result['ids']=orig
(D/'ways.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
print({k:(v.get('exception') or v.get('fact')) for k,v in result.items() if k!='ids'})
