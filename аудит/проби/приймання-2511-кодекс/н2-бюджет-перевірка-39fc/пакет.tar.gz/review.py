"""Run the author's unchanged case() on locally verified code and archived inputs.
Keep full intermediate requests private. Save only supports for the independent decision."""
from pathlib import Path
import json,sys,os,subprocess,hashlib,ast
from collections import Counter
from unittest.mock import patch

here=Path(__file__).resolve().parent
spec=json.loads((here/'author/розклад.json').read_bytes())
measure=here/'run/measure.py'
assert hashlib.sha256(measure.read_bytes()).hexdigest()==hashlib.sha256((here/'author/measure.py').read_bytes()).hexdigest()
sys.path.insert(0,str(here/'run'))
os.chdir(here/'inputs')
ctx={'__name__':'independent','__file__':str(measure)}
mod=ast.parse(measure.read_text());mod.body=[node for node in mod.body if node.lineno<203]
exec(compile(mod,str(measure),'exec'),ctx)
def git_source(*args):
    assert args[0]=='rev-parse' and args[1].startswith(spec['archive_sha']+':')
    return subprocess.check_output(['git','-C',os.environ['N2_REVIEW_REPO'],*args],text=True).strip()
ctx['git']=git_source
P=ctx['пул']
evidence={}
for scene,old in spec['cases'].items():
    ids=old['upstream_missing_ids']; ranks=[]
    def observe(*args,**kw):
        rows=sorted(*args,**kw)
        if sys._getframe(1).f_code.co_name=='зібрати' and sys._getframe(1).f_lineno==307:
            context=sys._getframe(1).f_locals; ranks.append({'input_count':len(context['каталог']) if hasattr(context.get('каталог'),'__len__') else None,'eligible_bold':len(rows),'ranks_one_based':{r.ід:i for i,r in enumerate(rows,1) if r.ід in ids},'named_match':{i:i in context['за'] for i in ids}})
        return rows
    with patch.object(P,'sorted',observe,create=True):
        new=ctx['case'](scene,old['repair_archive_index_zero_based'],old['assembly_archive_index_zero_based'])
    minpath=here/'run'/(scene.split('_')[0]+'-minimum.json')
    text=minpath.read_text();body=json.loads(text);m=new['minimum']; expected=old['minimum']
    assert len(text.encode())==m['json_utf8_bytes']
    counter=ctx['знання'].палітрові_знання().оцінити_текст_ядра
    assert counter(text)==m['joint_json_tokens_estimate']
    assert m['total']==m['joint_json_tokens_estimate']+m['reserve']+m['photo_label_tokens_estimate']+m['photo_tokens_estimate']
    check={k:new.get(k)==old.get(k) for k in ['archive','hands','trace','assembly_line_sha256','repair_line_sha256','archive_stocks','profile_pasport_seed_sha256','current_pool_rows','upstream_exclusions','restricted_pool_admitted','measurement_mode','findings_by_outfit','repair_trigger_outfits','minimum_wire_sha256','structured_failure','minimum']}
    outcome=new.get('structured_failure',new.get('under_limit_result'))
    evidence[scene]={'matches':check,'counts':{k:m[k] for k in ('pinned','additional','json_utf8_bytes','joint_json_tokens_estimate','reserve','total','deficit','headroom')},'ranks':ranks,'minimum_wire_sha256':new['minimum_wire_sha256'],'transport_failure':new.get('structured_failure',{}).get('вид'),'non_additive_section_mismatches':[k for k in expected['non_additive_sections'] if expected['non_additive_sections'][k]!=m['non_additive_sections'][k]],'n_outfits':len(body['verdict']),'n_showcase':len(body['showcase'])}
    (here/'verified.json').write_text(json.dumps(evidence,indent=2,ensure_ascii=False))
    print(scene, evidence[scene],flush=True)
