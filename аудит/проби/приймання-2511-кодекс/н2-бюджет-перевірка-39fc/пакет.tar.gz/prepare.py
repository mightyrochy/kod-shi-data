import os,json,subprocess,hashlib
from pathlib import Path
root=Path(__file__).resolve().parent
out=root/'inputs'
d=json.loads((root/'author/розклад.json').read_text())
for scene,r in d['cases'].items():
    for kind in ('archive','trace','hands'):
        src=r[kind];path=src['path'];sha='224bf4efc78c21e35d904963d1e8c6b820ec3545';blob=subprocess.check_output(['git','-C',os.environ['N2_REVIEW_REPO'],'rev-parse',sha+':'+path],text=True).strip()
        content=subprocess.check_output(['git','-C',os.environ['N2_REVIEW_REPO'],'cat-file','blob',blob]);target=out/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(content)
        assert blob==src['blob'] and hashlib.sha256(content).hexdigest()==src['sha256']
