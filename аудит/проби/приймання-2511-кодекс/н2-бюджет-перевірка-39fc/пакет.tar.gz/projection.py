"""Small projections only. No stored model messages or profiles are written to the deliverable."""
from pathlib import Path
import hashlib,json,re
D=Path(__file__).resolve().parent
report=json.loads((D/'author/розклад.json').read_bytes())
verified=json.loads((D/'verified.json').read_bytes())
def compact(x):return json.dumps(x,ensure_ascii=False,separators=(',',':'))
def sha(b):return hashlib.sha256(b).hexdigest()
out={}
for scene,r in report['cases'].items():
 v=verified[scene]
 assert all(v['matches'].values()) and not v['non_additive_section_mismatches']
 raw=(D/'run'/(scene.split('_')[0]+'-minimum.json')).read_bytes(); w=json.loads(raw);assert sha(raw)==r['minimum_wire_sha256']
 cols=w['candidates']['cols'];rows=w['candidates']['rows'];used={n for verdict in w['verdict'] for n in verdict['items']};candidate={row[cols.index('n')] for row in rows}
 assert used==candidate and len(used)==r['minimum']['pinned'] and not w['showcase']
 trace=json.loads((D/'inputs'/r['trace']['path']).read_bytes())['прогони'][0]['спільне']
 line=(D/'inputs'/r['archive']['path']).read_bytes().splitlines()[r['assembly_archive_index_zero_based']]
 a=json.loads(line);q=json.loads(a['запит'])
 history=json.loads(next(b['text'] for b in q['messages'][0]['content'] if b['type']=='text'))
 original_palette=history['person'].get('palette',{})
 fields={'all_pinned_appear_in_outfits':True,'distinct_placed':len(used),'outfits':len(w['verdict']),'archived_candidates_extra':r['archive_candidates']-r['archive_stocks'],
         'budget_section_count':len(r['minimum']['non_additive_sections']),'source_json_bytes_sum':sum(len(compact(x[cols.index('sources')]).encode()) for x in rows),
         'native_repair_triggers':len(r['repair_trigger_outfits']),'source_input_has_colour':'колір' in trace['вхід_прогону'],'archive_wire_has_slot_roles':bool(original_palette.get('slot_roles')),'archive_wire_has_colour_estimates':any(isinstance(x,dict) and x.get('estimate_hex') for x in history['person'].get('colouring',{}).values()),'intent':trace['паспорт'].get('намір'),'measurement_mode':r['measurement_mode']}
 if 'structured_failure' in r:
    f=r['structured_failure'];fields['structured_failure']={**{k:f[k] for k in ('вид','частина','поле','спроба')},**{k:f['дані'][k] for k in ('stage','limit_source','context_tokens','mandatory_total_tokens_estimate')}}
 out[scene]=fields
(D/'projection.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
# Only the three catalogue records named in the author's c8 exclusion table.
# The pickle comes exclusively from the previous local run of catalog.py.
import pickle
records=pickle.loads((D/'run/catalogue.pkl').read_bytes())
case=next(k for k in report['cases'] if k.startswith('с8'))
expected=report['cases'][case]['record_fields_for_upstream_exclusions']
ids=set(report['cases'][case]['upstream_missing_ids'])
fields={r['id']:{k:r.get(k) for k in ('слот','тип','візерунок','візерунок_джерело','реєстр')} for r in records if r['id'] in ids}
assert len(fields)==3 and all(v['візерунок_джерело']=='фото' and v['реєстр'] is None for v in fields.values())
out[case]['catalogue_fields']=fields
(D/'projection.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
