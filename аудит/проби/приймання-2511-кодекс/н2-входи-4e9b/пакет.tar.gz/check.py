"""One real legacy judge per outfit. Emit only the facts named in this review."""
import json
from unittest.mock import patch
from ядро import пул, знання, суд, розбір
from ядро.тести.тест_н2 import _запис, _збір
from ядро.поняття import Ситуація
import суд_від_моделі as legacy

def check(case):
    colours = {'grey': ([40,0,0], '#5e5e5e'), 'red': ([55,65,40], '#e23234')}
    rows = []
    clothes = [('top','верх','сорочка'),('bottom','низ','штани')] if case == 'two_large' else [('dress','сукня','сукня')]
    for ident, slot, kind in clothes + [('shoes','взуття','лофери'), ('bag','сумка','сумка')]:
        accented = ident == 'bag' and case in ('red','two_red') or ident == 'shoes' and case == 'two_red'
        lab, hexcolour = colours['red' if accented else 'grey']
        fibre = 'шкіра' if ident == 'bag' and case == 'mixed_fibre' else 'бавовна'
        rows.append(_запис(ident,slot,тип=kind,волокно=fibre,колір_тип='вимір',колір_джерело='фото',lab=lab,hex=hexcolour))
    scene = Ситуація(1, {}, {})
    pool = пул.зібрати(scene, 1, 37, rows)
    outfit, = розбір.прочитати(_збір(pool, *(r['id'] for r in rows)), 'складання', pool)
    captured = []
    original = legacy.перевірити_від_моделі
    def capture(*args, **kwargs):
        result = original(*args, **kwargs)
        captured.append(result)
        return result
    with patch.object(legacy, 'перевірити_від_моделі', side_effect=capture):
        verdict = суд.судити(outfit, scene, pool, {})
    assert len(captured) == 1 and captured[0]['перевірено']
    raw = captured[0]
    names = {'single_focus','lightness_steps','accent_echo','accent_surfaces_differ','declared_column_known','texture_adds','genre_dominant'}
    cells = {p['що']: p['стан'] for g in ['надлишок','прісність','аксесуари'] for p in raw['чеклісти'][g] if p['що'] in names}
    findings = { (f['правило'],c['code'],f.get('сила')) for f in знання._знахідки(raw)
                 if f['правило'] in ('K-COL-01','K-COL-05','K-ACC-10') for c in f['заяви'] }
    raw_19 = {}
    if hasattr(знання,'стани_чекліста'):
        unavailable = {k for group in знання.ЧЕКЛІСТИ.values() for k,p in group.items() if p['перевірка']=='немає_каналу'}
        raw_19 = {p['що']:p['стан'] for g in ['надлишок','прісність','аксесуари','палітра'] for p in raw['чеклісти'][g] if p['що'] in unavailable}
        assert len(raw_19)==19
    after = {k:v for k,v in verdict.чекліст.items() if k.split('.')[-1] in names}
    after_findings = sorted({(f.правило,f.код) for f in verdict.заяви if f.правило in ('K-COL-01','K-COL-05','K-ACC-10')})
    requests = [s['values'].get('fields') for f in знання._знахідки(raw) if f['правило']=='K-ACC-10' for s in f['заяви'] if s['code']=='rule_input_missing']
    return {'K-ACC-10_requested_fields': requests,'legacy_for_19':raw_19,'legacy': cells, 'n2': after, 'legacy_findings': sorted(findings,key=repr),'n2_findings': after_findings}
if __name__=='__main__':
    print(json.dumps({c:check(c) for c in ('red','grey','two_red','mixed_fibre','two_large')}, ensure_ascii=False, indent=2))
