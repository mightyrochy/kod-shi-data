import base64
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import sys
from zipfile import ZipFile

ART = Path('/tmp/liusterko-n2-build-artifacts')
runtime = json.loads((ART / 'CPython.json').read_text())
pyodide = json.loads((ART / 'Pyodide.json').read_text())
shim = ART / 'інструменти/pyodide-cpython.cjs'
sha256 = lambda data: hashlib.sha256(data).hexdigest()

for prefix in sys.argv[1:]:
    root = ART / prefix
    sources = (root / 'вхідні_джерела.json').read_bytes()
    src = json.loads(sources)
    html = (root / 'index.html').read_bytes()
    text = html.decode()
    def js_constant(name):
        return re.search(r'const\s+' + name + r'\s*=\s*"([^"]+)"', text).group(1)
    stamp = js_constant('ЗБІРКА_ПОКАЗУ')
    fingerprint = js_constant('ВІДБИТОК_ПОКАЗУ')
    assert stamp == src['commit'], (stamp, src['commit'])
    assert re.fullmatch('[0-9a-f]{12}', fingerprint)
    assert not any(mark in text for mark in ('__МОДУЛІ_ПОКАЗУ__', '__ЗБІРКА_ПОКАЗУ__', '__ВІДБИТОК__'))
    bundle = base64.b64decode(js_constant('МОДУЛІ_ПОКАЗУ'), validate=True)
    source_sum = hashlib.sha256()
    with ZipFile(io.BytesIO(bundle)) as z:
        manifest = z.read('байткод.json')
        m = json.loads(manifest)
        assert m['python'] == runtime['version_info'][:3] == [3, 12, 1]
        assert m['cache_tag'] == runtime['cache_tag'] == 'cpython-312'
        assert m['magic'] == runtime['magic'] == 'cb0d0d0a'
        assert m['pyodide'] == pyodide['Pyodide']['version'] == '0.26.4'
        assert m['компілятор'] == runtime['version']
        for name, meta in sorted(m['модулі'].items()):
            data = z.read(name)
            source_sum.update(name.encode('utf-8') + b'\0' + data)
            pyc = z.read(meta['pyc'])
            assert sha256(data) == meta['source_sha256'], name
            assert sha256(pyc) == meta['pyc_sha256'], meta['pyc']
            assert pyc[:4].hex() == m['magic'] and int.from_bytes(pyc[4:8], 'little') == 3, meta['pyc']
        assert source_sum.hexdigest() == m['source_sha256']
    (root / 'байткод.json').write_bytes(manifest)
    result = root / 'exit-code.txt'
    checkout = '/tmp/liusterko-n2-build-7f5e9d88/джерела'
    policy_path = Path(checkout) / 'резерв_каналу.json'
    policy_bytes = policy_path.read_bytes()
    policy = json.loads(policy_bytes)
    assert '__РЕЗЕРВ_КАНАЛУ__' not in text
    function = re.search(r'function\s+резервВиходуКаналуП\s*\([^)]*\)\s*\{(.*?)\n\}', text, re.S).group(1)
    installed = re.search(r'Object\.entries\(\s*(\{[^{}]*\})\s*\)\.find', function).group(1)
    assert json.loads(installed) == policy == {'claude-': 12000}
    source_record = next(f for f in src['files'] if f['path'] == 'джерела/резерв_каналу.json')
    policy_sha = sha256(policy_bytes)
    assert source_record['sha256'] == policy_sha
    receipt = {
        'checkout_cwd': checkout,
        'embedded_channel_reserve': policy,
        'channel_reserve_source_git_blob': source_record['git_blob'],
        'channel_reserve_source_sha256': policy_sha,
        'channel_reserve_placeholder_remaining': False,
        'build_exit_code': int(result.read_text()) if result.exists() else None,
        'build_log_sha256': sha256((root / 'build.log').read_bytes()) if result.exists() else None,
        'git_commit': stamp, 'git_tree': src['tree'], 'stamp_html': stamp, 'code_fingerprint': fingerprint,
        'input_files_count': len(src['files']), 'input_manifest_sha256': sha256(sources),
        'html_sha256': sha256(html), 'html_bytes': len(html),
        'bundle_sha256': sha256(bundle), 'bytecode_manifest_sha256': sha256(manifest),
        'bytecode_modules_verified': len(m['модулі']), 'packed_python_source_sha256': m['source_sha256'],
        'Pyodide': pyodide, 'bytecode_compiler': runtime,
        'compiler_adapter_sha256': sha256(shim.read_bytes()),
        'desktop_python': sys.version, 'node': subprocess.check_output(['node','--version'], text=True).strip(),
        'node_modules': src['залежності'], 'command': (root / 'команда.txt').read_text().strip(),
    }
    (root / 'квитанція.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
    (root / 'SHA256SUMS').write_text(f'{sha256(html)}  index.html\n{sha256(manifest)}  байткод.json\n{sha256(sources)}  вхідні_джерела.json\n')
    print(prefix, stamp, len(m['модулі']), len(html), sha256(html), fingerprint, m['source_sha256'])
