import hashlib
import json
import os
from pathlib import Path
import subprocess

ART = Path('/tmp/liusterko-n2-build-artifacts')
LOCAL = Path('/workspace/kod-shi-data')
VARIANTS = {
    '7f5e9d88': ('7f5e9d880b97e0f89c1c751d4217a15149bd8fc3', '591aee155b763c1f12b878ceee5b52a221ec5c15')
}
ARCHIVES = ('каталог_повний.xml.gz', 'каталог_записи_v1.jsonl.gz')
FIXTURE = 'аудит/проби/б1/ПІСЛЯ-Е3/06_б1_концерт_сміливо/VIDPOVIDI/'
RECORDED = tuple(FIXTURE + name for name in ('seed3_08_ПАКЕТ_V1_ОБРАЗИ_V1.txt', 'seed3_15_ВЕРДИКТ_V1_ОБРАЗИ_V1.txt'))
GIT_ENV = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0')

def git(root, *args):
    return subprocess.check_output(('git', '-C', str(root), *args), env=GIT_ENV)

for key, (commit, tree) in VARIANTS.items():
    root = Path('/tmp/liusterko-n2-build-' + key)
    assert git(root, 'rev-parse', 'HEAD', 'HEAD^{tree}').decode().split() == [commit, tree]
    extra = set(ARCHIVES + RECORDED)
    listed = git(root, 'ls-tree', '-rz', 'HEAD', '--', 'джерела', *sorted(extra))
    records = []
    recovered = []
    for entry in listed.split(b'\0'):
        if not entry:
            continue
        meta, name = entry.split(b'\t', 1)
        mode, kind, blob = meta.decode().split()
        rel = name.decode()
        src = root / rel
        assert kind == 'blob', (rel, kind)
        if rel in extra and not src.exists():
            # The complete existing checkout has these exact tracked blobs.
            data = git(LOCAL, 'cat-file', 'blob', blob)
            src.parent.mkdir(parents=True, exist_ok=True)
            src.write_bytes(data)
            recovered.append(rel)
        assert src.exists(), (key, rel, blob)
        data = os.readlink(src).encode() if mode == '120000' else src.read_bytes()
        head = b'blob ' + str(len(data)).encode() + b'\0'
        assert hashlib.sha1(head + data).hexdigest() == blob, (key, rel, blob)
        records.append({'path': rel, 'git_blob': blob, 'mode': mode,
                        'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)})
    assert extra <= {r['path'] for r in records}, (key, extra)
    node_modules = root / 'джерела/node_modules'
    if not node_modules.is_symlink():
        node_modules.symlink_to(LOCAL / 'джерела/node_modules', target_is_directory=True)
    assert node_modules.resolve() == LOCAL / 'джерела/node_modules'
    package_versions = {package: json.loads((node_modules / package / 'package.json').read_text())['version']
                        for package in ('jsdom', 'fake-indexeddb')}
    metadata = {'commit': commit, 'tree': tree, 'залежності': package_versions,
                'додані_точні_відстежувані_файли': recovered, 'files': records}
    (ART / commit[:8] / 'вхідні_джерела.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + '\n')
    print(key, commit, tree, f'{len(records)} файлів збігаються з Git blob', f'{len(recovered)} матеріалізовано')
