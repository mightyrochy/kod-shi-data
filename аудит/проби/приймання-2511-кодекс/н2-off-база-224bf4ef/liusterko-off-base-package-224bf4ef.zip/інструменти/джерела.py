import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

commit = '224bf4efc78c21e35d904963d1e8c6b820ec3545'
root = Path('/tmp/liusterko-off-base-build-224bf4ef')
pack = Path(__file__).resolve().parents[1]
root_catalogues = ('каталог_повний.xml.gz', 'каталог_записи_v1.jsonl.gz')
recording_directory = 'аудит/проби/б1/ПІСЛЯ-Е3/06_б1_концерт_сміливо/VIDPOVIDI'
recordings = tuple(recording_directory + '/' + name for name in (
    'seed3_08_ПАКЕТ_V1_ОБРАЗИ_V1.txt', 'seed3_15_ВЕРДИКТ_V1_ОБРАЗИ_V1.txt'))
env = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0')

def git(*args, data=None):
    return subprocess.check_output(('git', '-C', str(root), *args), env=env, input=data)

entries = []
extras = root_catalogues + recordings
for row in git('ls-tree', '-rz', commit, '--', 'джерела', *extras).split(b'\0'):
    if not row:
        continue
    meta, path = row.split(b'\t', 1)
    mode, kind, blob = meta.decode().split()
    assert kind == 'blob'
    entries.append((mode, blob, path.decode()))
assert set(extras) <= {path for _, _, path in entries}
blobs = sorted({blob for _, blob, _ in entries})
batch_input = ('\n'.join(blobs) + '\n').encode()
action = sys.argv[1]
if action == 'list-missing':
    checks = git('cat-file', '--batch-check', data=batch_input).decode().splitlines()
    (pack / 'докази/відсутні-об’єкти.txt').write_text(''.join(
        line.split()[0] + '\n' for line in checks if line.endswith(' missing')))
    print(f'{len(entries)} files, {len(blobs)} unique blobs, {sum(row.endswith(" missing") for row in checks)} missing')
    sys.exit(0)
assert action in ('before', 'after')
records = []
for mode, blob, rel in entries:
    path = root / rel
    if action == 'before':
        data = git('cat-file', 'blob', blob)
        path.parent.mkdir(parents=True, exist_ok=True)
        if mode == '120000':
            path.symlink_to(data.decode())
        else:
            path.write_bytes(data)
            path.chmod(0o700 if mode == '100755' else 0o600)
    data = os.readlink(path).encode() if mode == '120000' else path.read_bytes()
    git_header = b'blob ' + str(len(data)).encode() + b'\0'
    assert hashlib.sha1(git_header + data).hexdigest() == blob, rel
    records.append({'path': rel, 'git_blob': blob, 'mode': mode,
                    'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)})
metadata = {'commit': commit, 'tree': git('rev-parse', commit + '^{tree}').decode().strip(),
            'files': records}
manifest_path = pack / f'докази/джерела-{action}.json'
manifest_path.write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + '\n')
print(f'{action}: {len(records)} Git blobs, {sum(record["bytes"] for record in records)} bytes')
