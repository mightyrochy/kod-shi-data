import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";

const tree = process.argv[2];
const file = (name) => fs.readFileSync(`${tree}/джерела/показ/${name}`, "utf8");
const extract = (source, name) => {
  const match = new RegExp(`^(?:async )?function ${name}\\([\\s\\S]*?^\\}`, "m").exec(source);
  assert.ok(match, name);
  return match[0];
};
const plain = (obj) => JSON.parse(JSON.stringify(obj));
const show = file("ядро.js");
const language = file("мовний_шар.js");
const results = {};
for (const name of ["held-70", "registered-mixed"]) {
  const sent = [];
  let callbacks = 0;
  const card = JSON.parse(fs.readFileSync(`outputs/${name}/card.json`, "utf8"));
  const context = {
    МОДЕЛЬ_МОВИ_П: true,
    ПАМ_ЯТЬ_ПИТАНЬ_П: new Map(),
    ЧЕКАЮТЬ_ПИТАННЯ_П: new Map(),
    ПИШУТЬСЯ_РОЗГОРНУТІ_П: new Set(),
    ЗБІЙ_РОЗГОРНУТИХ_П: new WeakSet(),
    НАПИС_БЕЗ_ШАРУ_П: {card_unchecked: "fallback"},
    повідомленняОписуБезФотоП: () => ({fixture: "description_without_photos"}),
    збійЖінціП: (_, __, error) => { throw error; },
    показатиРозгорнутіПитанняКартки: () => { callbacks++; },
    питатиПачкамиП: async (rows, stage) => {
      sent.push({rows: plain(rows), stage});
      const states = rows.map(([key], i) => [key, {текст: `fixture reply ${i}`, стан: "translated"}]);
      return {записи: [], стани: new Map(states)};
    },
  };
  const f = vm.runInNewContext([
    extract(show, "карткаЯдраНаЕкранП"),
    ...["звестиПитанняП", "чекаютьРозгортанняП", "питаннямиП", "дописатиРозгорнутіП"].map(n => extract(language, n)),
    "({ project: карткаЯдраНаЕкранП, count: чекаютьРозгортанняП, ordinary: питаннямиП, expand: дописатиРозгорнутіП })",
  ].join("\n"), context);
  const held = card.невідоме.filter(z => z.утримано);
  assert.equal(held.length, name === "held-70" ? 1 : 3);
  const projected = f.project(card, 37);
  assert.deepEqual(plain(projected.невідоме), card.невідоме);
  const repeated = f.project({...card, невідоме: [...card.невідоме, ...held]}, 37);
  assert.deepEqual(plain(repeated.питання), plain(projected.питання));
  const count = f.count(repeated);
  assert.equal(count, held.length + 2);
  for (const z of held) {
    assert.equal(z.вага, 0);
    const hits = repeated.питання.filter(q => q.ід === z.ід);
    assert.equal(hits.length, 1);
    const q = plain(hits[0]);
    assert.deepEqual(q, {на_розгортання: 1, ід: z.ід, правило: z.правило, речі: z.речі,
      повідомлення: {kind: "card_unchecked", statements: [{code: z.код, values: z.значення, item_ids: z.речі}]}});
  }
  const isSeasonFinding = z => z.code === "fabric_out_of_season";
  const ordinaryProjected = repeated.питання.flatMap(q => q.повідомлення?.statements ?? [])
    .filter(isSeasonFinding).length;
  await f.ordinary(repeated, "synthetic", false);
  assert.ok(sent[0].rows.every(([, , q]) => !held.some(z => q.statements[0].code === z.код)));
  await f.expand(repeated);
  const expanded = sent[1].rows.map(([, , q]) => q.statements[0]);
  assert.ok(expanded.some(z => z.code === "rule_input_missing"));
  const ordinaryDispatched = sent[0].rows.flatMap(([, ,q]) => q.statements)
    .filter(isSeasonFinding).length;
  assert.equal(ordinaryProjected, name === "registered-mixed" ? 4 : 0);
  assert.equal(ordinaryDispatched, name === "registered-mixed" ? 1 : 0);
  for (const z of held) assert.equal(expanded.filter(x => x.code === z.код &&
                 JSON.stringify(x.item_ids) === JSON.stringify(z.речі)).length, 1);
  await f.expand(repeated);
  assert.equal(sent.length, 2);
  assert.equal(callbacks, 1);
  results[name] = {held, ordinaryProjected, ordinaryDispatched, before_expand: sent[0], expanded: sent[1], repeated_expand_no_dispatch: true};
}
fs.writeFileSync("display.json", JSON.stringify(results, null, 2) + "\n");
console.log("PASS projection + actual opening reader: 4/4 held, exact values/IDs, 0 duplicates; normal controls pass.");
