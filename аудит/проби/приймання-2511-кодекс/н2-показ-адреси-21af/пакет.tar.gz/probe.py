from dataclasses import replace
from pathlib import Path
from unittest.mock import patch
import json
import socket


def no_network(*args, **kwargs):
    raise AssertionError("network is disabled for this offline probe")


socket.socket.connect = no_network
socket.socket.connect_ex = no_network
socket.create_connection = no_network
socket.getaddrinfo = no_network

import colorspace
import суд_від_моделі as legacy
import верхнє_довжина as hems
from ядро import картка, знання, пул, розбір, суд, запит
from ядро.поняття import Етап, Ситуація, Факт, Збій

root = Path(__file__).resolve().parent
real_legacy = legacy.перевірити_від_моделі


def offer(id_, slot, kind, color, **data):
    return {"id": id_, "слот": slot, "тип": kind, "назва": id_, "ціна": 1000, "формальність": 5,
            "lab": colorspace.hx(color), "hex": color, "колір_тип": "вимір", "колір_джерело": "фото",
            "сезон_тканини": ["cold"], "сезон_за_чим": ["вовна"], **data}


def dimensions(length, spread):
    if length is None:
        return {}
    return {"довжина_виробу_см": length, "довжина_виробу_точка": "лінія_плеча",
            "довжина_виробу_розкид_см": spread, "край_джерело": "виріб",
            "довжина_виробу_за_чим": "синтетична картка виміру"}


def response(**data):
    return {"текст": json.dumps({"version": "1", **data}, ensure_ascii=False)}


def save(p, obj):
    p.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def run_case(name, dress_len, coat_len, spread, *, target="K-OUT-03", outside=None, no_coat=False):
    mode = Path(root / "outputs" / name)
    mode.mkdir(parents=True, exist_ok=True)
    offers = [
        offer("dress", "сукня", "сукня", "#375647", довжина_рівень="коліно", **dimensions(dress_len, spread)),
        offer("coat", "верхній_шар", "пальто", "#6a594e", довжина_рівень="коліно", **dimensions(coat_len, spread)),
        offer("shoes", "взуття", "лофери", "#403831"),
        offer("bag", "сумка", "сумка", "#594942"),
    ]
    if no_coat:
        offers = [o for o in offers if o["id"] != "coat"]
    fields = {}
    if outside is not None:
        fields["етапи"] = (Етап("локальна фікстура", надворі=outside),)
        fields["смуга_погоди"] = Факт("cool", "форма")
    day = Ситуація(1, fields, {})
    profile = {}
    pool = пул.зібрати(day, 1, 37, offers)
    ids = {row["ід"]:row["н"] for row in pool.речі}
    assert set(ids) == {o["id"] for o in offers}, (name, ids, pool.відкинуто)
    numbers = [ids[o["id"]] for o in offers]
    outfit, = розбір.прочитати(response(outfits=[{"id": "o1", "items": numbers}]), "складання", pool)
    used = [pool.записи[n] for n in numbers]
    calls = []

    def watch(*args, **kwargs):
        result = real_legacy(*args, **kwargs)
        calls.append((args, kwargs, result))
        return result

    with patch.object(legacy, "перевірити_від_моделі", side_effect=watch):
        verdict = суд.судити(outfit, day, pool, profile)
        assert not isinstance(verdict, Збій), verdict.в_json()
        (args, kwargs, observed), = calls
        assert observed["перевірено"] is True
        old_findings = [z for z in знання._знахідки(observed) if z["правило"] == target]
        p17 = "excess.layer_hems_apart"
        state = знання.стан_правил(day, used, profile)
        save(mode / "input.json", {"offers": offers, "day": day.в_json(), "profile": profile})
        save(mode / "legacy.json", {"args": args, "kwargs": kwargs, "measured_gap": (hems.розрив_країв(args[2][1], args[2][0]) if "coat" in ids else None),
                                   "target_findings": old_findings})
        save(mode / "verdict.json", verdict.в_json())
        for kind in ("ремонт", "вибір", "опис"):
            request = запит.запит(kind, pool, day, profile, образи=(outfit,), вироки={outfit.ід:verdict},
                                 без_фото=True, модель={"loaded_context_length": 120000})
            assert not isinstance(request, Збій), request.в_json()
            raw = request.модель["messages"][0]["content"]
            (mode / f"{kind}.json").write_text(raw, encoding="utf-8")
            wire = json.loads(raw)["verdict"][0]
            assert wire["checklist"][p17] == verdict.чекліст[p17], (kind, name)
            assert wire["id"] == outfit.ід and wire["items"] == numbers
        description = розбір.Опис(образ=outfit.ід, склад=tuple(numbers), текст="Synthetic test description.",
                                  носіння=(), фото_не_те=(), про_речі=())
        card = картка.зібрати(outfit, verdict, description, pool, фото_були=())
        assert card.збій is None and card.вирок == outfit.ід
        save(mode / "card.json", card.в_json())
        result = {"case":name, "target":target, "input_state":state.get(target), "p17":verdict.чекліст[p17],
                  "rule_row":verdict.чекліст.get(target), "raw": [(z["сила"],z.get("сила_нп"),z["заяви"][0]["code"]) for z in old_findings],
                  "n2": [z.код for z in verdict.заяви if z.правило == target],
                  "card_unknown":card.невідоме,"card_codes":[z["код"] for z in card.заяви_картки],
                  "repair":суд.потребує_ремонту(verdict)}
        print(json.dumps({k: v for k, v in result.items() if k != "card_unknown"}, ensure_ascii=False), flush=True)
        withheld_only = replace(verdict, заяви=tuple(z for z in verdict.заяви if z.значення.get("утримано")))
        assert not суд.потребує_ремонту(withheld_only)
        assert len(calls) == 1, (name, len(calls))
    return result

if __name__ == "__main__":
    results = [
        run_case("0", None, None, 9.4),
        run_case("1", 100, None, 9.4),
        run_case("held-70", 100, 70, 9.4),
        run_case("pass-60", 100, 60, 9.4),
        run_case("fail-93", 100, 93, 0),
        run_case("na", 100, None, 9.4, no_coat=True),
        run_case("registered-mixed", 100, 60, 9.4, target="K-MAT-03", outside=False),
    ]
    save(root / "results.json", results)

