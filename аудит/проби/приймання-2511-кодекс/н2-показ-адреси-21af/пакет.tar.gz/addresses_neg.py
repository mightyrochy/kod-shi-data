import json
from pathlib import Path

from probe import dimensions, offer, response, save
from ядро import пул, розбір, запит
from ядро.поняття import Ситуація, Вирок, Заява, Збій


def run(name, coat_id):
    rows = [
        offer("dress", "сукня", "сукня", "#375647", **dimensions(100, 9.4)),
        offer(coat_id, "верхній_шар", "пальто", "#6a594e", **dimensions(70, 9.4)),
        offer("shoes", "взуття", "лофери", "#403831"),
        offer("bag", "сумка", "сумка", "#594942"),
    ]
    day = Ситуація(1, {}, {})
    pool = пул.зібрати(day, 1, 37, rows)
    aliases = {row["ід"]: row["н"] for row in pool.речі}
    assert aliases["dress"] == "#1·03" and aliases[coat_id] == "#1·05"
    numbers = [aliases[r["id"]] for r in rows]
    outfit, = розбір.прочитати(response(outfits=[{"id": "o1", "items": numbers}]), "складання", pool)
    facts = {"item_id": aliases["dress"], "item_ids": ["dress", "outside-fixture", aliases["dress"]],
             "free_text": "dress or #1·03; outside-fixture (literal)"}
    application = Заява("f-o1-control", "outer_edges_gap_measured",
                        {"факти": facts, "ремонт": None, "регістр": "утримано", "вага": 0, "утримано": True},
                        "невідоме", (aliases["dress"],), "K-OUT-03")
    verdict = Вирок(outfit.ід, day.версія, tuple(numbers), (application,))
    folder = Path("outputs") / name
    folder.mkdir(exist_ok=True)
    receipt = {}
    for kind in ("ремонт", "вибір", "опис"):
        built = запит.запит(kind, pool, day, {}, образи=(outfit,), вироки={outfit.ід:verdict},
                            без_фото=True, модель={"loaded_context_length": 120000})
        assert not isinstance(built, Збій)
        raw = built.модель["messages"][0]["content"]
        (folder / f"{kind}.json").write_text(raw, encoding="utf-8")
        (fact,) = json.loads(raw)["verdict"][0]["findings"]
        assert fact["items"] == [aliases["dress"]]
        assert fact["values"]["item_ids"][1] == "unknown"
        assert fact["values"]["free_text"] == facts["free_text"]
        receipt[kind] = {"external": fact["items"], "internal": fact["values"]["item_id"],
                         "lower_nested": fact["values"]["item_ids"], "literal": fact["values"]["free_text"]}
    save(folder / "input.json", {"offers": rows, "aliases": aliases, "synthetic_statement": application.в_json()})
    return receipt

regular = run("addresses-unknown", "coat")
ambiguous = run("addresses-ambiguous", "#1·03")
assert all(r["internal"] == "#1·03" for r in regular.values())
assert all(r["internal"] == "#1·05" and r["external"] == ["#1·03"] for r in ambiguous.values())
save(Path("address-negative.json"), {"unambiguous": regular, "ambiguous": ambiguous})
print("PASS unknown becomes unknown, ordinary text unchanged. Synthetic mixed-address collision: #1·03 becomes #1·05 in 3/3 full requests.")
