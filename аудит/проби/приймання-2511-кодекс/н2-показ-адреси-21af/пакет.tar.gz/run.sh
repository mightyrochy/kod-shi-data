#!/usr/bin/env bash
set -euo pipefail
tree=$(cd "$1" && pwd)
cd "$(dirname "$0")"
while read -r hash file; do
  test "$(git hash-object "$tree/$file")" = "$hash"
done < blobs.txt
export PYTHONPATH="$tree/джерела" PYTHONHASHSEED=0 PYTHONDONTWRITEBYTECODE=1
python3 probe.py
python3 звірити_докази.py reference
python3 addresses_neg.py
node display.mjs "$tree"
node "$tree/джерела/ядро/тести/показ_утримань.mjs" outputs/held-70/card.json outputs/registered-mixed/card.json
