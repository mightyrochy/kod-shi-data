'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const read = name => fs.readFileSync(name, 'utf8');
const plain = value => JSON.parse(JSON.stringify(value));
const noop = () => {};
const img = url => ({type:'image', source:{type:'url', url}});
const a = {id:'a@shop', назва:'A', фото:'https://img.invalid/a.jpg'};
const b = {id:'b@shop', назва:'B', фото:'https://img.invalid/b.jpg'};
const c = {id:'c@shop', назва:'C', фото:'https://img.invalid/c.jpg'};
const catalog = [a,b,c];
const addressList = rows => rows.map(row => row.фото);
const all = rows => ({надіслано: rows.length, дійшло: rows.length, жодного:false});
const proof = row => ({id:row.id, адреси:[row.фото], неоднозначно:false});
const stageInput = {обрані:[a.id,b.id], оголКартки:[], ітерацій:0, в:{речі:[a,b]}};

function stageWorld(respond){
  const framesIn = rows => ({
    промпт: '{}', речі: rows.map(row => ({id:row.id, фото:[row.фото]})), фото:addressList(rows)
  });
  const ctx = {
    ЗБ:{діагноз:[], картки:[], готові_мс:[], стадії:[], етап:[], ключ:[]},
    СТАДІЯ_П:{перепис_формули:'rewrite'}, МОДЕЛЬ_МОВИ_П:false, ОСТАННІ_ЗАГОЛОВКИ_П:{},
    ФОРМА_ОПИСУ_П:'no description', БЕЗ_ПРИЧИНИ_П:'no reason',
    містП: async (_action,input) => {
      const ids = [...input.речі, ...(input.заміна?.запасні || [])];
      return framesIn(ids.map(id => catalog.find(row => row.id === id)));
    },
    судКартки:noop, показатиТокени:noop, підписатиКадри:blocks => blocks,
    модельРукиП:async (blocks,_photo,_hist,_abort,out) => {
      out.кадри = all(blocks.filter(block => block.type === 'image'));
      return 'fixture';
    },
    кадрівНеДійшлоП:(_stage,delivery) => delivery,
    шаблонОписуП:v => v,
    фотоДляЗапитуП:async () => [], фотоЗакріпленихП:noop, СТОРОНА_ФОТО_РЕЧІ_П:0,
    стадіяУважногоВибору:async () => ({}), стадіяСкладання:async () => ({}), стадіяРемонту:async () => ({}),
    стадіяВибору:async () => structuredClone(stageInput),
    збиранняКарткиРуки:async (_ctx, state) => { ctx.toCard = state; return {картка:{}}; },
    стадіяМовногоШару:async () => ({}), збійРукиП:name => name,
    поступЗміненоП:noop, показатиДіагноз:noop,
  };
  ctx.рука = {
    вх:{}, поз:0, рука:'1', лічильники:{викликів:0}, мітка:noop,
    станОбриву:() => ({}), зОбривом:(_st,data) => data,
    запамʼятатиЗапит:noop, отриматиЗапитОстанній:noop, моделіРуки:new Set(),
    модельПРуки:async () => 'rewrite fixture', відМоделіРуки:respond,
  };
  ctx.створитиКонтекстРуки = () => ctx.рука;
  vm.createContext(ctx);
  vm.runInContext(read('stages.js'),ctx);
  return ctx;
}

async function failedStage(){
  let calls = 0;
  const ctx = stageWorld(async () => {
    if (++calls === 1) return {речі:[a,b], опис:{текст:'опис', фото_не_ті:[a.id]},
      мова:{порушення:[]}, мова_повтор:{спроб_усього:1}, промпт_мови:'rewrite'};
    assert.deepEqual(plain(ctx.рука.знятиЧастину().в.відхилення_кадрів),[proof(a)]);
    throw new Error('fixture bridge rejects rewrite verdict');
  });
  await ctx.однаРука(0);
  assert.equal(calls,2);
  assert.deepEqual(plain(ctx.toCard.в),{перевірено:false});
  assert.equal(ctx.toCard.збій,'hand_step_failed');
  console.log('ABORT: exact proof before reject; absent in state passed to card; failure state; rendering not exercised');
}

async function failedDescriptionAfterSwap(){
  let calls = 0;
  const ctx = stageWorld(async () => {
    if (++calls === 1) return {речі:[a,b], опис:{текст:'опис', фото_не_ті:[a.id]},
      заміна:{річ:a.id, стан:'spares', запасні:[{id:c.id}]}};
    if (calls === 2) return {речі:[a,b], опис:{фото_не_ті:[]}, заміна:{стан:'kept'}};
    return {речі:[a,b], опис:{фото_не_ті:[b.id]}};
  });
  const result = await ctx.стадіяОпису(ctx.рука,structuredClone(stageInput));
  assert.equal(calls,3);
  assert.equal(result.описНеДійшов,'no description');
  assert.deepEqual(plain(result.в.відхилення_кадрів),[proof(a)]);
  assert.ok(ctx.ЗБ.діагноз.some(line => line.includes('decided_outfit_description_missing')));
  vm.runInContext(read('card.js'),ctx);
  assert.deepEqual(plain(ctx.кадриРечі(b,ctx.відхиленняКадруРечі(result.в,b))),[b.фото]);
  console.log('SWAP: kept outfit A/B; delivered and parsed B mismatch in final response lacking prose; card policy still renders B');
}

async function pairControl(){
  const vmFor = async (file) => {
    const nodes = new Map();
    const src = [];
    const pending = [];
    const look = 'mirror-look-sides';
    const node = id => {
      if (id === 'ф-зріст') return null;
      if (!nodes.has(id)) nodes.set(id,{set innerHTML(markup){
        if (id === look) src.push(...Array.from(markup.matchAll(/\ssrc="([^"]+)"/g), m=>m[1]));
      }});
      return nodes.get(id);
    };
    const card = {рука:'1', речі:[a,b], відхилення_кадрів:[proof(a)]};
    const ctx = vm.createContext({
      window:{MirrorMaterial:{get:() => ''}}, СЦ:null, АКТИВНИЙ:'profile', ЧАТ_П:[],
      Екран:{стан:{образ:{поз:0}}}, БІБЛІОТЕКА_П:{плитки:[], групи:[]},
      зрізЗбиранняП:() => ({}), кадрПоказуП:noop, ключЗаписуОбразуП:() => 'stable',
      document:{documentElement:{dataset:{}}, addEventListener:noop},
      П:{картки:[card]},
      MirrorIndex:{get:id => new Promise(resolve => {assert.equal(id,a.id); pending.push(resolve);})},
      R:{node, button:() => '', escape:String, ik:() => '', money:String, tone:noop, refresh:() => ctx.render()},
    });
    vm.runInContext(read('card.js')+'\n'+read(file)
      +"\nconst pair = window.createMirrorPair(R); function render(){pair.render('образи')}",ctx);
    ctx.render();
    const initial = src.splice(0);
    card.речі = [c,b];
    card.етапи = {заміни:[{ід:a.id, нова:c.id}]};
    ctx.render();
    const cached = src.splice(0);
    card.речі = [c,b];
    nodes.delete(look);
    ctx.П = {картки:[card]};
    ctx.ключЗаписуОбразуП = () => 'different';
    ctx.render();
    assert.equal(pending.length,1);
    const fresh = src.splice(0);
    pending[0]({name:'Catalog A', image:a.фото, price:1});
    await new Promise(resolve => setImmediate(resolve));
    const fallback = src.splice(0);
    return [initial,cached,fresh,fallback];
  };
  const before = await vmFor('pair-before.js');
  const after = await vmFor('pair.js');
  assert.ok(before.every(row => row.includes(a.фото) || row === before[2]));
  assert.ok(after.every(row => !row.includes(a.фото)));
  assert.ok(after[0].includes(b.фото) && after[1].includes(c.фото) && after[2].includes(c.фото));
  console.log('PAIR: old leading, cached old, and fetched old URLs reproduced; candidate excludes rejected A in all three');
}

function itemIsolation(){
  const rejected = 'https://img.invalid/shared.jpg';
  const ctx = vm.createContext({});
  vm.runInContext(read('card.js')+'\n'+read('stages.js').split('const стадіяОпису')[0],ctx);
  const primary = {...a, фото_усі:[a.фото,rejected], кадр_виміру:{стан:'measured'}, клас_кадру:'ціла_річ'};
  const neighbor = {...b, фото:rejected, фото_усі:[rejected]};
  const request = {речі:[{id:a.id,фото:[a.фото,rejected]},{id:b.id,фото:[rejected]}]};
  const images = [img(a.фото),img(rejected),img(rejected)];
  const selection = (row,evidence) => plain(ctx.кадриРечі(row,ctx.відхиленняКадруРечі({відхилення_кадрів:evidence},row)));
  const evidence = ctx.відхиленняКадрівОпису([{id:a.id,url:rejected}],request,images,[{надіслано:3,дійшло:3}]);
  assert.deepEqual(plain(evidence),[{id:a.id,адреси:[rejected],неоднозначно:false}]);
  assert.deepEqual(selection(primary,evidence),[a.фото]);
  assert.deepEqual(selection(neighbor,evidence),[rejected]);
  const partial = ctx.відхиленняКадрівОпису([{id:a.id,url:rejected}],request,images,[{надіслано:3,дійшло:2}]);
  assert.deepEqual(plain(partial),[{id:a.id,адреси:[],неоднозначно:true}]);
  assert.deepEqual(selection(primary,partial),[]);
  assert.deepEqual(selection(neighbor,partial),[rejected]);
  console.log('IDENTITY: exact evidence keys A only; A retains its measured safe frame; B survives with shared URL; partial delivery has no exact proof');
}

async function localDeliveries(){
  const pending = [];
  const ctx = vm.createContext({
    МОДЕЛЬ_П:'fixture', НАЛАШТУВАННЯ_РУШІЯ_П:{}, МАКС_ТОКЕНІВ_П:100,
    стадіяВикликуП:noop, _оцінкаПромптаП:() => 0, вмістити_запит_П:noop,
    врахуватиВикликП:noop, МОДЕЛІ_ПРОГОНУ:new Set(),
    блокиВТекст:content => content[0].text,
    плануватиВикликП: async () => new Promise(resolve => pending.push(resolve)),
  });
  vm.runInContext(read('bridge.js'),ctx);
  const finish = (i,text,dropped) => pending[i]({
    відп: {json:async () => ({content:[{text}]}), headers:new Map([['x-images-dropped',String(dropped)]])},
    запис:{},
  });
  const first = {}, second = {};
  const one = ctx.модельРукиП([img(a.фото),img(b.фото)],null,[],{},first);
  const two = ctx.модельРукиП([img(c.фото)],null,[],{},second);
  await new Promise(resolve => setImmediate(resolve));
  finish(1,'second',1);
  finish(0,'first',1);
  assert.deepEqual(await Promise.all([one,two]),['first','second']);
  assert.deepEqual(plain(first.кадри),{надіслано:2, дійшло:1, жодного:false});
  assert.deepEqual(plain(second.кадри),{надіслано:1, дійшло:0, жодного:true});
  console.log('DELIVERY: overlapping calls with reverse completion retain their own image counts');
}
(async () => {
  await failedStage();
  await failedDescriptionAfterSwap();
  await pairControl();
  itemIsolation();
  await localDeliveries();
})().catch(error => {console.error(error); process.exitCode = 1;});
