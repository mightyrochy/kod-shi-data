'use strict';
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const fixture = require('./15647.json');

const BASE = 'http://127.0.0.1:15647';
const CANARY = 'https://blocked-15647.invalid';
const VIEWPORT = {width: 390, height: 844};
const WARNING = 'Це пояснення написано без фото речей — вони до стилістки не дійшли';
const sha256 = value => crypto.createHash('sha256').update(value).digest('hex');
const syntax = {
  '.js': 'application/javascript', '.json': 'application/json',
  '.wasm': 'application/wasm', '.zip': 'application/zip',
};

function verify(htmlPath, runtimePath) {
  const html = fs.readFileSync(htmlPath);
  assert.equal(sha256(html), fixture.html_sha256, 'SHA-256 index.html');
  assert(html.includes(Buffer.from('const ЗБІРКА_ПОКАЗУ = "' + fixture.head + '"')), 'Штамп HTML');
  assert(html.includes(Buffer.from('const ВІДБИТОК_ПОКАЗУ = "' + fixture.display_fingerprint + '"')), 'Відбиток HTML');
  const runtime = new Map();
  for (const [name, hash] of Object.entries(fixture.runtime_sha256)) {
    const bytes = fs.readFileSync(path.join(runtimePath, name));
    assert.equal(sha256(bytes), hash, name);
    runtime.set('/pyodide/' + name, {body: bytes, contentType: syntax[path.extname(name)]});
  }
  const integrity = /const ЦІЛІСНІСТЬ_PYODIDE_П = 'sha384-([^']+)'/.exec(html.toString('utf8'));
  const loader = runtime.get('/pyodide/pyodide.js').body;
  assert.equal(crypto.createHash('sha384').update(loader).digest('base64'), integrity?.[1], 'SRI Pyodide');
  return {html, runtime};
}

function localResource(method, address, assets) {
  const url = new URL(address);
  if (method !== 'GET' || url.origin !== BASE || url.username || url.password) return null;
  if (url.pathname === '/index.html' && !url.search) {
    return {body: assets.html, contentType: 'text/html; charset=utf-8'};
  }
  if (url.pathname === '/build.txt' && /^\?t=\d+$/.test(url.search)) {
    return {body: fixture.head + '\n', contentType: 'text/plain'};
  }
  if (url.pathname === '/_isolation.html' && !url.search) {
    return {body: '<!doctype html><meta charset="utf-8">', contentType: 'text/html'};
  }
  if (url.search) return null;
  if (assets.runtime.has(url.pathname)) return assets.runtime.get(url.pathname);
  const photo = /^\/synthetic-pics\/([1-4])\.svg$/.exec(url.pathname);
  if (!photo) return null;
  const color = ['#526179', '#807063', '#595360', '#687962'][Number(photo[1]) - 1];
  const body = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 240 320">' +
    '<rect width="240" height="320" fill="' + color + '"/>' +
    '<path d="M55 220L120 70l65 150z" fill="#eee" opacity=".7"/></svg>';
  return {body, contentType: 'image/svg+xml'};
}

// Виконується тільки у сторінці майбутнього приймання. Усі API — зі зібраного HTML.
async function installFixture({caseData, withDamage, worker, origin, warning}) {
  const check = (truth, why) => { if (!truth) throw new Error(why); };
  check(ЗБІРКА_ПОКАЗУ === caseData.head && ВІДБИТОК_ПОКАЗУ === caseData.display_fingerprint, 'Штамп сторінки');
  check(ЯДРО_П && ЄДИНА_СТОРІНКА && ФІД_П === caseData.catalog_file, 'Режим або каталог');
  check(!ПІДЙОМ_МОСТА_П && !МІСТ_ГОТОВИЙ_П, 'Воркер уже стартував до локального налаштування');
  check(МОДЕЛЬ_П === 'claude-sonnet-5-5' && МОДЕЛЬ_МОВИ_П, 'Конфігурація продуктового каналу');
  ДЗЕРКАЛА_П.splice(0, ДЗЕРКАЛА_П.length, ['fixture-local', origin + '/pyodide/']);

  const call = (name, ...values) => приладМостуП({}, 'import json\n' +
    'case15647.' + name + '(*json.loads(' + JSON.stringify(JSON.stringify(values)) + '))').then(JSON.parse);
  const setup = JSON.parse(await приладМостуП({'/показ/case15647.py': worker},
    'import case15647, json\ncase15647.підготувати(*json.loads(' +
    JSON.stringify(JSON.stringify([ФІД_П, caseData.fixture, withDamage])) + '))'));
  check(setup.наявна === withDamage, 'Наведення фікстури');
  check(setup.було === caseData.catalog_records && setup.стало === setup.було - Number(!withDamage), 'Повний вбудований каталог');

  СЦ = {...СЦ, ід: '15647-офлайн', назва: 'Офлайн-фікстура 15647'};
  зібратиВхід = () => structuredClone(caseData.profile);
  змінитиПаспортП('стенд.15647', 'замінити', caseData.passport);

  const stages = [];
  const syntheticAttempts = [];
  const displayPhotos = [];
  const landings = [];
  const modelReplies = new Map();
  const bridge = містП;
  let firstOutfit;
  let final;
  const budget = [];
  містП = async function(name, data, options) {
    if (name === 'ядро' && data.дія === 'почати') {
      const entry = data.вхід;
      check(entry.модель.вихід === 4000 && entry.модель.надбавка_каналу === 12000 &&
        entry.модель.канал === 'worker' && !entry.модель.вікно, 'Штатний резерв або відсутність відомого вікна');
      check(entry.перемикачі.вибір === 'list' && entry.перемикачі.запис === 'повний' &&
        entry.перемикачі.частин === 1, 'Перемикачі будівника');
      budget.push(entry.модель);
      // Єдині зміни в протокольному вході: відтворні сід, дата й паспорт фікстури.
      // Точний паспорт протоколу збігається з наявним офлайн-пакетом.
      data = {...data, вхід: {...entry, сід: caseData.seed, дата: caseData.clock,
        паспорт: structuredClone(caseData.passport)}};
    }
    const output = await bridge(name, data, options);
    if (name === 'ядро') {
      if (output.кінець) final = output;
      for (const request of output.запити || []) {
        check(request.рука === 1 && stages.length < 8, 'Неочікувана рука або кількість протокольних кроків');
        const prompt = request.модель.messages[0].content;
        const body = JSON.parse(prompt);
        const stage = request.вид;
        let fields;
        if (stage === 'складання') {
          firstOutfit = await call('скласти', body);
          fields = firstOutfit;
        } else if (stage === 'ремонт') {
          fields = firstOutfit;
        } else if (stage === 'вибір') {
          fields = {chosen: 'o1'};
        } else if (stage === 'опис') {
          fields = {text: 'A closed-shoe outfit for a cold workday.', wrong_photos: [],
            about_items: body.outfit.items.map(row => ({n: row.n, text: 'An item in this outfit.'}))};
        } else {
          throw new Error('Непередбачений вид протокольного запиту: ' + stage);
        }
        const photos = (request.фото || []).map(image => image.url);
        stages.push({stage, photos, promptBytes: new TextEncoder().encode(prompt).length,
          budget: request.розмір || null});
        modelReplies.set(prompt, {stage, fields: {version: '1', ...fields}, photos});
      }
    } else if (name === 'мова' && output?.промпт) {
      const prompt = output.промпт;
      if (data.тексти && output.розмітка) {
        const fields = {};
        for (const row of output.розмітка) {
          const source = row.текст;
          if (source === 'An item in this outfit.') fields[row.н] = 'Ця річ входить до комплекту.';
          else if (source === 'A closed-shoe outfit for a cold workday.') fields[row.н] = 'Комплект із закритим взуттям для холодного робочого дня.';
          else if (typeof source === 'string') {
            // Четвертий пункт може бути об'єднаним описом з текстів моделі.
            const remainder = source.replaceAll('An item in this outfit.', '').replaceAll('A closed-shoe outfit for a cold workday.', '').trim();
            check(!remainder, 'Нема перекладу для синтетичного тексту');
            fields[row.н] = source.replaceAll('An item in this outfit.', 'Ця річ входить до комплекту.')
              .replaceAll('A closed-shoe outfit for a cold workday.', 'Комплект із закритим взуттям для холодного робочого дня.');
          } else throw new Error('Відсутній текст у розмітці мовного шару');
        }
        modelReplies.set(prompt, {stage: 'переклад', fields, photos: []});
      } else if (data.повідомлення && output.розмітка) {
        const marker = '\nПОВІДОМЛЕННЯ:\n';
        const cert = prompt.lastIndexOf(marker);
        check(cert >= 0, 'Немає блоку повідомлень у мовному запиті');
        const input = JSON.parse(prompt.slice(cert + marker.length));
        const fields = {};
        for (const statement of input) {
          if (statement.code === 'description_written_without_photos') fields[statement.key] = warning + '.';
          if (statement.code === 'no_photo_frames_did_not_open')
            fields[statement.key] = 'Фото крамниці не відкрилося.';
        }
        modelReplies.set(prompt, {stage: 'заяви', fields, photos: []});
      } else if (data.питання && output.розмітка) {
        // Мовні питання мають окремий стан fallback. Невідомі відповіді не вигадуємо.
        modelReplies.set(prompt, {stage: 'питання', fields: {}, photos: []});
      }
    }
    return output;
  };
  const digest = async value => {
    const bytes = new TextEncoder().encode(JSON.stringify(value));
    return [...new Uint8Array(await crypto.subtle.digest('SHA-256', bytes))]
      .map(byte => byte.toString(16).padStart(2, '0')).join('');
  };
  _дзвінокП = async function(messages, model, _sampling, maxTokens) {
    const blocks = messages.flatMap(message => typeof message.content === 'string'
      ? [{type: 'text', text: message.content}] : message.content);
    const exact = blocks.map(block => modelReplies.get(block.text)).filter(Boolean);
    check(exact.length === 1 && syntheticAttempts.length < 20, 'Мок не впізнав точний запит або перевищено стелю спроб');
    const reply = exact[0];
    const urls = blocks.filter(block => block.type === 'image').map(block => block.source.url || null);
    check(JSON.stringify(urls) === JSON.stringify(reply.photos), 'Мок отримав інші URL ніж штатний протокол');
    const attempt = {stage: reply.stage, model: model || МОДЕЛЬ_П, maxTokens, urls};
    syntheticAttempts.push(attempt);
    attempt.requestSha256 = await digest(messages);
    attempt.answerSha256 = await digest(reply.fields);
    return new Response(JSON.stringify({stop_reason: 'end_turn',
      content: [{type: 'text', text: JSON.stringify(reply.fields)}]}),
    {headers: {'content-type': 'application/json', 'x-provider': 'offline-fixture', 'x-images-dropped': '0'}});
  };

  // Міняємо лише адресу мініатюри після штатного перетворення Картки. Протокол,
  // заяви, власницький звіт і підрахунок бюджету бачили справжні дані каталогу.
  const cardAdapter = карткаЯдраНаЕкранП;
  карткаЯдраНаЕкранП = function(card, seed) {
    const shown = cardAdapter(card, seed);
    if (card.рука === 1 && !shown.збій) {
      for (const [index, row] of shown.речі.entries()) {
        if (!row.фото) continue;
        const local = origin + '/synthetic-pics/' + (index + 1) + '.svg';
        displayPhotos.push({id: row.id, catalog: row.фото, local});
        row.фото = local;
      }
    }
    return shown;
  };

  // Семантичний вхід кнопки. Обидві гілки проходять через штатний збір, Worker і рендер.
  режим('очікування');
  await зібратиОбразиП();
  // П.картки читаємо після рендера. Номер руки та позиція з ядра не визначають DOM-індекс.
  const shownCards = (П?.картки || []).map(card => ({
    рука: card.рука, збій: !!card.збій, ядро: card.ядро,
    речі: card.речі.map(row => ({id: row.id, slot: row.слот})),
  }));
  for (const card of shownCards) landings.push({рука: card.рука, збій: card.збій});
  globalThis.__case15647 = {setup, budget, stages, syntheticAttempts, displayPhotos, final, landings, shownCards,
    success: !!(ЗБ?.успіх && ЗБ?.готово), ownerReport: П?.ядро?.звіт ?? null,
    zbReport: ЗБ?.ядро?.звіт ?? null, diagnosis: ЗБ?.діагноз ?? null,
    journal: ЖУРНАЛ_ВИКЛИКІВ_П.slice(), proof: await call('докази')};
}

function uniqueHandOne(cards, label) {
  assert(Array.isArray(cards), label + ': немає масиву карток');
  const positions = cards.flatMap((card, position) => card?.рука === 1 ? [position] : []);
  assert.equal(positions.length, 1, label + ': потрібна однозначна картка руки 1');
  const [position] = positions;
  const card = cards[position];
  assert(!card.збій, label + ': збій руки 1');
  return {position, card};
}

function coreIdentity(card) {
  assert(card?.рука === 1 && !card.збій, 'Показ не зберіг успішну протокольну картку руки 1');
  assert(typeof card.образ === 'string' && card.образ && typeof card.вирок === 'string' && card.вирок,
    'Відсутній ID образу або вироку руки 1');
  assert(Array.isArray(card.речі) && card.речі.length > 0, 'Порожній склад руки 1');
  const items = card.речі.map(row => ({n: row.н, id: row.ід, slot: row.слот}));
  assert(items.every(row => Object.values(row).every(value => typeof value === 'string' && value)),
    'Неповна адреса речі у складі руки 1');
  return {hand: card.рука, outfit: card.образ, verdict: card.вирок, items};
}

function selectHandOne(finalCards, shownCards) {
  const protocol = uniqueHandOne(finalCards, 'Фінал протоколу');
  const shown = uniqueHandOne(shownCards, 'П.картки');
  const identity = coreIdentity(protocol.card);
  assert.deepEqual(coreIdentity(shown.card.ядро), identity,
    'Протокол і вкладена картка показу розійшлися за рукою, образом, вироком або складом');
  assert.deepEqual(shown.card.речі, identity.items.map(({id, slot}) => ({id, slot})),
    'Адаптер показу змінив порядок, ID або слот видимих речей');
  return {position: shown.position, id: 'к-' + shown.position, identity};
}

function bindRenderedCard({position, id, identity, handOrder}) {
  const state = Екран.стан;
  if (state.режим !== 'образи' || !П?.прогін || state.образи?.прогін !== String(П.прогін))
    throw new Error('Рендер не належить поточному прогону');
  const screen = state.образи.картки;
  const live = П.картки;
  const cards = [...document.querySelectorAll('#картки > .картка')];
  if (screen?.length !== handOrder.length || live?.length !== handOrder.length || cards.length !== handOrder.length ||
      screen.some((card, index) => card?.рука !== String(handOrder[index]) ||
        live[index]?.рука !== handOrder[index] || cards[index].id !== 'к-' + index))
    throw new Error('Картки рендера не збігаються з фактичним порядком показу');
  if (screen[position]?.рука !== String(identity.hand) || screen[position]?.збій ||
      cards.filter(card => card.id === id).length !== 1 || cards[position]?.id !== id)
    throw new Error('DOM-вузол успішної руки 1 відсутній або неоднозначний');
  const current = live[position];
  const core = current.ядро;
  const items = core?.речі?.map(row => ({n: row.н, id: row.ід, slot: row.слот}));
  if (current.збій || core?.збій || core?.рука !== identity.hand ||
      core.образ !== identity.outfit || core.вирок !== identity.verdict ||
      JSON.stringify(items) !== JSON.stringify(identity.items) ||
      current.речі?.length !== identity.items.length ||
      current.речі.some((row, index) => row.id !== identity.items[index].id || row.слот !== identity.items[index].slot))
    throw new Error('Картка у фактичному П.картки змінилася після звірки');
  const activeBefore = state.образ.поз;
  if (activeBefore !== position) показатиОбраз(position);
  if (Екран.стан.образ.поз !== position)
    throw new Error('Штатний пейджер не відкрив картку руки 1');
  return {position, id, activeBefore, activeAfter: Екран.стан.образ.поз};
}

function compose(data) {
  assert(data.success && data.final?.кінець && !data.final.збій, 'Рука 1 має завершитися без загального збою');
  const {card} = uniqueHandOne(data.final.картки, 'Фінал протоколу');
  assert.equal(data.landings.filter(row => !row.збій).length, 1, 'Кількість успішних рук');
  assert(card && !card.збій && !card.збій_опису, 'Нема успішної Картки руки 1 з описом');
  assert.equal(card.образ, 'o1');
  assert.equal(card.вирок, card.образ);
  const items = card.речі.map(row => ({n: row.н, id: row.ід, slot: row.слот}));
  const ids = items.map(row => row.id);
  assert(items.length >= 3 && new Set(ids).size === ids.length, 'Цілісний унікальний склад');
  assert(!ids.includes(fixture.fixture.id) && !data.proof.речі_пулу.includes(fixture.fixture.id), 'Бита річ проникла в образ або пул');
  const [verdict] = data.proof.вироки;
  assert.equal(data.proof.вироки.length, 1, 'Кількість викликів справжнього суду');
  assert.equal(verdict.образ, card.образ);
  assert.deepEqual(verdict.склад, items.map(row => row.n), 'Склад вироку');
  assert.deepEqual(card.про_речі_en.map(([id]) => id), ids, 'Склад пояснення');
  assert.deepEqual(data.ownerReport, data.final.звіт, 'Звіт П не від протоколу');
  assert.deepEqual(data.zbReport, data.ownerReport, 'Звіти ЗБ і П розійшлися');
  assert(!JSON.stringify(card).includes('bad_record'), 'Власницький код передано в дані Картки');
  return {card, items, verdict};
}

function validate(data, withDamage) {
  const {card, items, verdict} = compose(data);
  const rows = data.ownerReport.filter(row => row.річ === fixture.fixture.id);
  assert.equal(rows.length, Number(withDamage));
  if (withDamage) {
    assert.equal(rows[0].заява, 'bad_record');
    assert.equal(rows[0].рука, 1);
    assert.deepEqual(rows[0].збої.map(row => [row.вид, row.поле]).sort(),
      [['bad_record','каблук_см'], ['bad_record','сезон_тканини']].sort());
  }
  const exclusions = data.ownerReport.filter(row => row.рука === 1 &&
    row.крок === 'опис' && row.збій?.вид === 'вікно_моделі');
  assert.equal(exclusions.length, 1, 'Очікувався один штатний відсів опису з фото');
  const rejection = exclusions[0].збій;
  assert.equal(rejection.спроба, 1);
  assert.equal(rejection.дані.limit_tokens, 25334);
  assert.equal(rejection.дані.response_reserved_tokens, 16000);
  assert.equal(rejection.дані.context_tokens, null);
  assert.equal(rejection.дані.photo_count, 4);
  assert(rejection.дані.mandatory_total_tokens_estimate > rejection.дані.limit_tokens);
  assert.deepEqual(data.stages.map(row => row.stage), data.stages.some(row => row.stage === 'ремонт')
    ? ['складання','ремонт','вибір','опис'] : ['складання','вибір','опис']);
  const descriptions = data.syntheticAttempts.filter(row => row.stage === 'опис');
  assert.equal(descriptions.length, 1, 'Другу спробу після відсіву слід видати рівно один раз');
  assert.deepEqual(descriptions[0].urls, [], 'Підставний транспорт опису одержав фото');
  assert(card.невідоме.some(row => row.код === 'description_written_without_photos'), 'Код попередження на Картці');
  assert.equal(data.dom.rows, items.length);
  assert.deepEqual(data.dom.collageIds, items.map(row => row.id), 'Склад видимого колажу');
  assert(data.dom.description, 'Опис не видно на Картці');
  assert(data.dom.warning, 'Попередження без фото не видно у viewport');
  assert(!data.dom.text.includes(fixture.fixture.id) && !data.dom.text.includes('bad_record') &&
    !/послаб[^.\n]{0,35}(меж|обмеж|вимог)|зняти[^.\n]{0,30}обмеж/i.test(data.dom.text), 'Видимий технічний діагноз або пропозиція послабити вимоги');
  assert.deepEqual(data.dom.viewport, [390, 844]);
  assert.equal(data.dom.photos.length, items.length * 2, 'Фото колажу й мініатюр');
  assert(data.dom.photos.every(image => image.loaded && image.url.startsWith(BASE + '/synthetic-pics/')));
  return {items, verdict, rejection, syntheticAttempts: data.syntheticAttempts.filter(row =>
    ['складання','ремонт','вибір','опис'].includes(row.stage))};
}

async function checkNetwork(context, page, log) {
  // Перевірити охоплення page і dedicated Worker до navigation продукту.
  await page.goto(BASE + '/_isolation.html');
  const controls = await page.evaluate(async ({canary, origin}) => {
    async function fail(url) {
      try { await fetch(url); return false; } catch { return true; }
    }
    const worker = new Worker(URL.createObjectURL(new Blob([
      'onmessage = async ({data:[blocked, local]}) => {' +
      'let allowed = false, denied = false;' +
      'try {allowed = (await fetch(local)).ok} catch {}' +
      'try {await fetch(blocked)} catch {denied = true}' +
      'postMessage([allowed, denied]);}'
    ], {type: 'text/javascript'})));
    try {
      const workerCheck = new Promise((resolve, reject) => {
        const timeout = setTimeout(() => reject(new Error('Воркер не повернув контроль ізоляції')), 10000);
        worker.onmessage = ({data}) => { clearTimeout(timeout); resolve(data); };
        worker.onerror = event => { clearTimeout(timeout); reject(new Error(event.message)); };
        worker.postMessage([canary + '/worker', origin + '/pyodide/pyodide-lock.json']);
      });
      return {pageDenied: await fail(canary + '/page'), worker: await workerCheck};
    } finally { worker.terminate(); }
  }, {canary: CANARY, origin: BASE});
  assert.deepEqual(controls, {pageDenied: true, worker: [true, true]}, 'HTTP-контроль ізоляції');
  for (const target of ['/page', '/worker']) {
    assert(log.some(row => row.url === CANARY + target && row.action === 'abort'),
      'У журналі нема блокування ' + target);
  }
  assert(log.some(row => row.url === BASE + '/pyodide/pyodide-lock.json' && row.action === 'fulfill'));
}

async function branch(browser, assets, worker, dir, withDamage) {
  const context = await browser.newContext({viewport: VIEWPORT, deviceScaleFactor: 1,
    isMobile: true, hasTouch: true, serviceWorkers: 'block', acceptDownloads: false, locale: 'uk-UA'});
  const log = [];
  const errors = [];
  let page;
  try {
    assert.equal(typeof context.routeWebSocket, 'function', 'Стенд потребує наявний Playwright із routeWebSocket');
    await context.routeWebSocket(/.*/, socket => {
      log.push({url: socket.url(), method: 'WebSocket', action: 'abort'});
      return socket.close({code: 1008, reason: 'offline fixture'});
    });
    await context.route(/.*/, async route => {
      const request = route.request();
      const url = request.url();
      const method = request.method();
      const resource = localResource(method, url, assets);
      log.push({url, method, type: request.resourceType(), action: resource ? 'fulfill' : 'abort'});
      if (resource) await route.fulfill({status: 200, ...resource});
      else await route.abort('blockedbyclient');
    });
    page = await context.newPage();
    page.on('pageerror', err => errors.push(String(err)));
    await checkNetwork(context, page, log);
    await page.goto(BASE + '/index.html#ядро=1&частин=1&вибір=list&запис=повний', {waitUntil:'domcontentloaded', timeout: 30000});
    await page.waitForFunction(() => typeof Екран !== 'undefined' && Екран.стан.запущено, null, {timeout:30000});
    let timer;
    try {
      await Promise.race([
        page.evaluate(installFixture, {caseData: fixture, withDamage, worker, origin: BASE, warning: WARNING}),
        new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('Минуло 6 хвилин роботи стенда')), 360000); }),
      ]);
    } finally { clearTimeout(timer); }
    const data = await page.evaluate(() => globalThis.__case15647);
    assert(data, 'Стенд не повернув даних');
    fs.writeFileSync(path.join(dir,'protocol.json'), JSON.stringify(data, null, 2) + '\n');
    const selected = selectHandOne(data.final?.картки, data.shownCards);
    data.rendered = {...selected, ...await page.evaluate(bindRenderedCard, {
      ...selected, handOrder: data.shownCards.map(row => row.рука),
    })};
    fs.writeFileSync(path.join(dir,'protocol.json'), JSON.stringify(data, null, 2) + '\n');
    const selector = '#картки > .картка[id="' + selected.id + '"]';
    const card = page.locator(selector);
    await card.waitFor({state:'visible', timeout:10000});
    await card.locator('img').evaluateAll(images => { for (const image of images) image.loading = 'eager'; });
    await page.waitForFunction(target => {
      const nodes = document.querySelectorAll(target);
      if (nodes.length > 1) throw new Error('DOM-вузол руки 1 дубльовано');
      const images = [...(nodes[0]?.querySelectorAll('img') || [])];
      return images.length > 0 && images.every(image => image.complete && image.naturalWidth > 0);
    }, selector, {timeout: 10000});
    await card.evaluate(el => el.scrollIntoView({block:'start', behavior:'instant'}));
    await page.screenshot({path: path.join(dir,'картка-390x844.png')});
    const warning = card.getByText(new RegExp('^' + WARNING + '\\.?$'));
    await warning.scrollIntoViewIfNeeded({timeout:10000});
    await page.screenshot({path: path.join(dir,'опис-без-фото-390x844.png')});
    data.dom = await card.evaluate((card, needle) => {
      const title = [...card.querySelectorAll('p')].find(el => el.textContent.trim().replace(/\.$/, '') === needle);
      const rectangle = title?.getBoundingClientRect();
      const shown = Boolean(title && rectangle.width && rectangle.height && rectangle.top >= 0 &&
         rectangle.bottom <= innerHeight && getComputedStyle(title).visibility === 'visible');
      return {text: card.innerText, rows: card.querySelectorAll('.список > .річ').length,
        collageIds: [...card.querySelectorAll('.колаж-вн > [data-id]')].map(el => el.dataset.id),
        description: card.innerText.includes('Комплект із закритим взуттям для холодного робочого дня.'),
        warning: shown, viewport: [innerWidth, innerHeight],
        photos: [...card.querySelectorAll('img')].map(el => ({url: el.currentSrc, loaded: el.complete && el.naturalWidth > 0}))};
    }, WARNING);

    fs.writeFileSync(path.join(dir,'protocol.json'), JSON.stringify(data, null, 2) + '\n');
    assert(!log.some(row => row.method === 'POST' || row.method === 'WebSocket'), 'Спроба поза підставним транспортом');
    assert.deepEqual(errors, [], 'Винятки сторінки');
    return validate(data, withDamage);
  } catch (error) {
    if (page) await page.screenshot({path: path.join(dir,'стоп-390x844.png'), timeout:5000}).catch(() => {});
    throw error;
  } finally {
    try { await context.close(); } finally {
      fs.writeFileSync(path.join(dir,'network.json'), JSON.stringify(log, null, 2) + '\n');
      fs.writeFileSync(path.join(dir,'page-errors.json'), JSON.stringify(errors, null, 2) + '\n');
    }
  }
}

async function main(args) {
  assert(args.length >= 2, 'node stand.cjs INDEX_HTML PYODIDE_DIR [OUTPUT_DIR]');
  const assets = verify(args[0], args[1]);
  if (args.length === 2) {
    console.log('Звірено SHA-256 HTML, вбудований штамп і п’ять файлів Pyodide. Браузер не відкривали.');
    return;
  }
  const {chromium} = require('playwright');
  const worker = fs.readFileSync(path.join(__dirname,'worker-fixture.py'),'utf8');
  const dir = path.resolve(args[2]);
  fs.mkdirSync(dir, {mode:0o700});
  const browser = await chromium.launch({headless: true, chromiumSandbox: true});
  try {
    const outputs = [];
    for (const [withDamage,name] of [[true,'з-битою'],[false,'без-речі']]) {
      const branchDir = path.join(dir,name);
      fs.mkdirSync(branchDir, {mode:0o700});
      try {
        outputs.push({name, evidence: await branch(browser, assets, worker, branchDir, withDamage)});
      } catch (error) {
        outputs.push({name, error: String(error)});
      }
    }
    fs.writeFileSync(path.join(dir,'pair.json'), JSON.stringify({head:fixture.head, outputs}, null, 2) + '\n');
    assert(outputs.every(row => row.evidence), 'Див. pair.json і журнали кожної гілки');
    assert.deepEqual(outputs[0].evidence, outputs[1].evidence, 'Склад, вирок, діагноз бюджету або спроби розійшлися');
    console.log('15647 відтворено в обох гілках. Результат браузерного контролю в ' + dir);
  } finally { await browser.close(); }
}

module.exports = {BASE, localResource, verify, validate, selectHandOne, bindRenderedCard};
if (require.main === module) {
  main(process.argv.slice(2)).catch(error => { console.error(error); process.exitCode = 1; });
}
