'use strict';
const assert = require('node:assert/strict');
const vm = require('node:vm');
const {BASE, localResource, verify, validate, selectHandOne, bindRenderedCard} = require('./stand.cjs');
const {fixture} = require('./15647.json');
const [html, runtime, prior, ...browserLogs] = process.argv.slice(2);
const assets = verify(html, runtime);
const archive = require(prior);

assert.equal(localResource('GET', BASE + '/index.html', assets).body, assets.html);
assert.equal(localResource('GET', BASE + '/build.txt?t=32', assets).body.trim(), archive.sha);
assert.equal(localResource('GET', BASE + '/pyodide/pyodide.asm.wasm', assets).contentType, 'application/wasm');
assert.equal(localResource('GET', BASE + '/synthetic-pics/4.svg', assets).contentType, 'image/svg+xml');
for (const [method, url] of [
  ['POST', BASE + '/index.html'], ['GET', BASE + '/synthetic-pics/5.svg'],
  ['GET', BASE + '/pyodide/../secret'], ['GET', BASE + '/index.html?v=other'],
  ['GET', 'http://127.0.0.1:8090/index.html'], ['GET', 'https://cdn.jsdelivr.net/pyodide/v0.26.4/full/pyodide.js'],
]) assert.equal(localResource(method, url, assets), null, method + ' ' + url);

function mock(saved) {
  const card = saved.картка;
  const report = [...saved.звіт_цілі, ...saved.проблеми_руки_1];
  const ids = card.речі.map(row => row.ід);
  return {
    success: true, final: {кінець: true, картки: [card], звіт: report},
    landings: [{рука: 1, збій: false}], ownerReport: report, zbReport: report,
    stages: saved.запити.map(row => ({stage: row.крок})),
    syntheticAttempts: saved.запити.map(row => ({stage: row.крок, urls: []})),
    proof: {вироки: saved.вироки, речі_пулу: ids},
    dom: {rows: ids.length, collageIds: ids, description: true, warning:true,
      text: 'Синтетична картка', viewport:[390,844],
      photos: ids.flatMap((_,index) => Array.from({length: 2}, () =>
        ({loaded: true, url: BASE + '/synthetic-pics/' + (index + 1) + '.svg'})))},
  };
}

const good = mock(archive.виходи.з_битою);
assert.deepEqual(validate(good, true), validate(mock(archive.виходи.без_речі), false));
for (const alter of [
  data => { data.dom.warning = false; },
  data => { data.dom.collageIds = data.dom.collageIds.toReversed(); },
  data => { data.proof.речі_пулу.push(fixture.id); },
  data => { data.final.картки = []; },
  data => { data.ownerReport = []; },
  data => { data.ownerReport[1].збій.дані.response_reserved_tokens = 4000; },
  data => { data.syntheticAttempts.at(-1).urls.push('https://example.org/photo.png'); },
  data => { data.dom.text = 'Спробуй послабити обмеження.'; },
]) {
  const corrupt = structuredClone(good);
  alter(corrupt);
  assert.throws(() => validate(corrupt, true));
}
function displayed(cards) {
  return cards.map(card => ({
    рука: card.рука, збій: !!card.збій, ядро: structuredClone(card),
    речі: card.речі.map(row => ({id: row.ід, slot: row.слот})),
  }));
}

const handOne = good.final.картки[0];
const handThree = {рука: 3, збій: {вид: 'частину_пише_Н3'}, речі: []};
const handTwo = {...handThree, рука: 2};
const ordered = [handThree, handOne, handTwo];
const shown = displayed(ordered);
const pick = selectHandOne(ordered, shown);
assert.equal(pick.position, 1, 'Заглушка руки 3 стоїть першою');
assert.equal(pick.id, 'к-1');
assert.equal(selectHandOne(ordered, displayed([handTwo, handThree, handOne])).position, 2,
  'Вибір має йти за порядком показу навіть після перестановки');
assert.equal(selectHandOne(ordered, displayed([handOne, handTwo, handThree])).position, 0);
const mutations = [
  cards => { cards.splice(1, 1); },
  cards => { cards.push({...cards[1], збій: true}); },
  cards => { cards[1].збій = true; },
  cards => { cards[1].ядро.рука = 3; },
  cards => { cards[1].ядро.образ = 'o2'; },
  cards => { cards[1].ядро.вирок = 'o2'; },
  cards => { cards[1].ядро.речі.reverse(); },
  cards => { cards[1].речі[0].id = 'інша-річ'; },
  cards => { cards[1].речі.reverse(); },
];
for (const mutate of mutations) {
  const wrong = structuredClone(shown);
  mutate(wrong);
  assert.throws(() => selectHandOne(ordered, wrong));
}
assert.throws(() => selectHandOne([handThree, handTwo], shown));
assert.throws(() => selectHandOne([...ordered, handOne], shown));
assert.throws(() => selectHandOne([handThree, {...handOne, збій: true}, handTwo], shown));

function renderMock({ids = ['к-0','к-1','к-2'], active = 0, snapshot = [3,1,2], prog = 'run',
  live = shown.map(card => ({...card, речі: card.речі.map(row => ({id: row.id, слот: row.slot}))}))}) {
  const state = {режим:'образи', образи: {прогін: prog,
    картки: snapshot.map(рука => ({рука: String(рука), збій: рука !== 1}))}, образ:{поз:active}};
  const input = {...pick, handOrder: [3,1,2]};
  const calls = [];
  const result = vm.runInNewContext('(' + bindRenderedCard.toString() + ')(input)', {
    input, Екран:{стан:state}, П:{прогін:'run', картки:live},
    document:{querySelectorAll: selector => {
      assert.equal(selector, '#картки > .картка');
      return ids.map(id => ({id}));
    }},
    показатиОбраз: position => { calls.push(position); state.образ.поз = position; },
  });
  return {result, calls};
}
assert.deepEqual(renderMock({}).calls, [1]);
assert.equal(renderMock({}).result.activeAfter, 1);
assert.deepEqual(renderMock({active:1}).calls, []);
assert.throws(() => renderMock({ids:['к-0','к-1','к-1']}));
assert.throws(() => renderMock({ids:['к-0','к-2']}));
assert.throws(() => renderMock({snapshot:[1,3,2]}));
assert.throws(() => renderMock({prog:'other'}));
const reordered = displayed([handThree, handTwo, handOne]);
assert.throws(() => renderMock({live:reordered}));

if (browserLogs.length) {
  assert.equal(browserLogs.length, 2, 'Потрібні два збережені журнали Chromium');
  const results = browserLogs.map((file, index) => {
    const log = require(file);
    const cards = displayed(log.final.картки);
    assert.deepEqual(log.landings, cards.map(({рука, збій}) => ({рука, збій})), 'Порядок протоколу й показу в журналі');
    assert.deepEqual(log.landings.map(row => row.рука), [3,1,2,4]);
    const selection = selectHandOne(log.final.картки, cards);
    assert.equal(selection.position, 1);
    assert.equal(selection.id, 'к-1');
    // Збережені журнали мають реальний протокол до зупинки. DOM тут лише підстава.
    const [target] = log.final.картки.filter(row => row.рука === 1);
    const dom = mock({картка: target, звіт_цілі: [], проблеми_руки_1: [],
      запити: [], вироки: []}).dom;
    return validate({...log, dom}, index === 0);
  });
  assert.deepEqual(results[0], results[1], 'Збережені браузерні протоколи розійшлися');
  console.log('Два журнали Chromium: порядок 3–1–2–4, вибрано руку 1 на позиції 1; рубрика даних пройшла з підставним DOM.');
}
console.log('Node: 10 URL, позитивна пара й 8 негативних контролів мірила; порядок і перестановки, 12 відмов ідентичності та 5 відмов DOM. Браузер не відкривали.');
