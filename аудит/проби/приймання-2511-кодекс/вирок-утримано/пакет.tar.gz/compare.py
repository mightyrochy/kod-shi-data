from collections import Counter
from pathlib import Path
import copy
import difflib
import json

root = Path(__file__).resolve().parent
diffs = root / "diffs"
diffs.mkdir(exist_ok=True)
states = ("провал", "пройдено", "без входу", "не стосується", "утримано")
cases = {
    "без-пальта": ("outputs/before/незастосовне", "outputs/after/незастосовне", "не стосується", "не стосується"),
    "нуль-вимірів": ("outputs/before/бракує-вимірів", "outputs/after/бракує-вимірів", "без входу", "утримано"),
    "один-вимір": ("evidence/один-вимір/before", "evidence/один-вимір/after", "пройдено", "утримано"),
    "60-100": ("outputs/before/перевірено", "outputs/after/перевірено", "пройдено", "пройдено"),
    "70-100": ("evidence/граничний-розрив/before", "evidence/граничний-розрив/after", "пройдено", "утримано"),
    "каталоговий-шов": ("evidence/каталоговий-шов/before", "evidence/каталоговий-шов/after", "не стосується", "не стосується"),
}
def read(path):
    return json.loads(path.read_text())

def lines(obj):
    return (json.dumps(obj, ensure_ascii=False, indent=2) + "\n").splitlines(keepends=True)

for label, (before, after, expect_before, expect_after) in cases.items():
    a, b = root / before, root / after
    x, y = (read(p / "суд.json") for p in (a, b))
    cell = lambda record: next(c for c in record["суд"]["checklist"]["надлишок"]["пункти"] if c["код"] == "layer_hems_apart")
    assert (cell(x)["стан"], cell(y)["стан"]) == (expect_before, expect_after), label
    counts = Counter()
    for side in y["суд"]["checklist"].values():
        section = Counter(c["стан"] for c in side["пункти"])
        assert len(side["пункти"]) == len({c["код"] for c in side["пункти"]})
        for st in states:
            val = side[st.replace(" ", "_")]
            assert section[st] == (len(val) if isinstance(val, list) else val)
        counts.update(section)
    assert set(counts) <= set(states) and sum(counts.values()) == 61, label
    if (a / "краї.json").exists():
        assert (a / "краї.json").read_bytes() == (b / "краї.json").read_bytes(), label
        assert not read(a / "перевірка-схеми.json") and not read(b / "перевірка-схеми.json"), label
    print(label, expect_before, "→", expect_after, list(counts[s] for s in states))
    for name in ("суд", "оцінка", "допит"):
        k, l = (read(p / f"{name}.json") for p in (a, b))
        diff = difflib.unified_diff(lines(k), lines(l), f"{before}/{name}.json", f"{after}/{name}.json")
        (diffs / f"{label}__{name}.diff").write_text("".join(diff))
        if name == "суд":
            assert k["суд"].get("weight") == l["суд"].get("weight")
            assert k["суд"].get("findings") == l["суд"].get("findings")
        else:
            assert k.get("unknown") == l.get("unknown")
            if label == "70-100":
                known = copy.deepcopy(k)
                gone = {"chroma_budget", "single_focus", "accent_echo", "layer_hems_apart"}
                fact = next(z for z in l["check"]["findings"] if z["rule"] == "K-OUT-03")
                assert fact["strength"] == "утримано" and fact["sila_np"] == 0
                statement = next(s for s in fact["statements"] if s["code"] == "outer_edges_gap_measured")
                assert statement["values"]["gap_cm"] == 30 and statement["values"]["error_cm"] == 21.34
                assert "outer_edges_gap_measured" in l["task"]["statement_codes"]
                known["check"]["points"]["passed"] = [p for p in known["check"]["points"]["passed"] if p not in gone]
                for code in gone:
                    del known["task"]["statement_codes"][code]
                assert known == l
            if label in ("без-пальта", "нуль-вимірів", "каталоговий-шов"):
                assert (a / f"{name}.json").read_bytes() == (b / f"{name}.json").read_bytes()
print("FAIL: 0 measurements regression; inherited 1-measure defect remains. Evidence assertions passed.")
