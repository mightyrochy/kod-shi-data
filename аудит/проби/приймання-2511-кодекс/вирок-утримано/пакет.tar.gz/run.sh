#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p outputs evidence/{граничний-розрив,один-вимір,каталоговий-шов}
for rev in before after; do
  export PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 PYTHONPATH="$PWD/$rev/джерела"
  python3 probe.py "$rev" > "outputs/$rev.log"
  python3 probe.py "$rev" --one-measure-only > "evidence/один-вимір/$rev.log"
  python3 probe.py "$rev" --boundary-only > "evidence/граничний-розрив/$rev.log"
  python3 catalogue-seam.py "$rev" > "evidence/каталоговий-шов/$rev.log"
done
node task-blocks.mjs
python3 compare.py | tee receipt.log
PYTHONPATH="$PWD/after/джерела" python3 -m unittest -v \
  тест_інваріанти.Е3_ПолеБезПисача.test_вирок_розрізняє_пять_станів_клітинки \
  тест_інваріанти.Е3_ПолеБезПисача.test_пізнє_утримання_не_входить_до_перевірених \
  тест_інваріанти.Е3_ПолеБезПисача.test_вирок_пара_вікон_відрізняє_утриманий_вхід 2>&1 | tee author-tests.log
