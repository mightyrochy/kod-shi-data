import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

package = Path(__file__).resolve().parent
root = package.parent / 'дерево'
checkout_dependencies = Path('/workspace/kod-shi-data/джерела/node_modules')
cache = Path('/tmp/liusterko-n2-pyodide-0264')
adapter = Path('/tmp/liusterko-n2-build-artifacts/інструменти/pyodide-cpython.cjs')
commit = '854485e09fc28a66a4d74980ae989cd092a1d73e'
tree = '73978068c6bcb6a92bc423d833b4e953ff3152d4'
fixture = 'аудит/проби/б1/ПІСЛЯ-Е3/06_б1_концерт_сміливо/VIDPOVIDI/'
paths = ('AGENTS.md', 'джерела', 'каталог_повний.xml.gz', 'каталог_записи_v1.jsonl.gz',
         fixture + 'seed3_08_ПАКЕТ_V1_ОБРАЗИ_V1.txt',
         fixture + 'seed3_15_ВЕРДИКТ_V1_ОБРАЗИ_V1.txt',
         'аудит/проби/репліка-підтверджені-частини')

def git(*args, **options):
    return subprocess.check_output(('git', '-C', str(root), *args),
                                   env=dict(os.environ, GIT_NO_LAZY_FETCH='1'), **options)

def entry(path):
    data = path.read_bytes()
    return {'name': path.name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

assert git('rev-parse', 'HEAD', 'HEAD^{tree}').decode().split() == [commit, tree]
records = []
for item in git('ls-tree', '-rz', 'HEAD', '--', *paths).split(b'\0'):
    if not item:
        continue
    metadata, name = item.split(b'\t', 1)
    mode, kind, blob = metadata.decode().split()
    assert kind == 'blob', (name, kind)
    records.append((mode, blob, name.decode()))
sizes = git('cat-file', '--batch-check=%(objectname) %(objectsize)',
            input=''.join(blob + '\n' for _, blob, _ in records).encode()).decode().splitlines()
missing = [name for (_, _, name), size in zip(records, sizes) if size.endswith(' missing')]
assert len(sizes) == len(records) and not missing, missing
print(f'{len(records)} об’єктів, {sum(int(row.split()[1]) for row in sizes)} байтів')

stage = sys.argv[1]
assert stage in ('до', 'після')
node_modules = root / 'джерела/node_modules'
files = []
for mode, blob, name in records:
    path = root / name
    if stage == 'до':
        data = git('cat-file', 'blob', blob)
        path.parent.mkdir(parents=True, exist_ok=True)
        if mode == '120000':
            path.symlink_to(os.fsdecode(data))
        else:
            path.write_bytes(data)
            path.chmod(0o700 if mode == '100755' else 0o600)
    data = os.fsencode(os.readlink(path)) if mode == '120000' else path.read_bytes()
    git_blob = hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()
    assert git_blob == blob, (name, git_blob, blob)
    files.append({'path': name, 'bytes': len(data), 'mode': mode, 'git_blob': git_blob,
                  'sha256': hashlib.sha256(data).hexdigest()})
if stage == 'до':
    node_modules.symlink_to(checkout_dependencies, target_is_directory=True)
assert node_modules.resolve() == checkout_dependencies
packages = {name: entry(node_modules / name / 'package.json') | {
    'version': json.loads((node_modules / name / 'package.json').read_text())['version']
} for name in ('jsdom', 'fake-indexeddb')}
data = {'commit': commit, 'tree': tree, 'files': files, 'node_dependencies': packages,
        'runtime_cache': [entry(path) for path in sorted(cache.iterdir())],
        'adapter': entry(adapter)}
(package / f'вхідні_джерела_{stage}.json').write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
