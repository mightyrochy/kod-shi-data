import base64
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import sys
from zipfile import ZipFile

pack = Path(__file__).resolve().parents[1]
evidence = pack / 'докази'
sources = (evidence / 'джерела-before.json').read_bytes()
assert sources == (evidence / 'джерела-after.json').read_bytes()
src = json.loads(sources)
log = (evidence / 'build.log').read_bytes()
status = int((evidence / 'exit-code.txt').read_text())
assert status == 0
html = (pack / 'index.html').read_bytes()
page = html.decode()
sha256 = lambda data: hashlib.sha256(data).hexdigest()

def js_constant(name):
    return re.search(r'const\s+' + name + r'\s*=\s*"([^"]+)"', page).group(1)

stamp = js_constant('ЗБІРКА_ПОКАЗУ')
assert stamp == src['commit']
fingerprint = js_constant('ВІДБИТОК_ПОКАЗУ')
assert re.fullmatch('[0-9a-f]{12}', fingerprint)
assert not any(mark in page for mark in ('__МОДУЛІ_ПОКАЗУ__', '__ЗБІРКА_ПОКАЗУ__', '__ВІДБИТОК__'))
bundle = base64.b64decode(js_constant('МОДУЛІ_ПОКАЗУ'), validate=True)
runtime = json.loads((evidence / 'CPython.json').read_bytes())
pyodide = json.loads((evidence / 'Pyodide.json').read_bytes())
source_sum = hashlib.sha256()
with ZipFile(io.BytesIO(bundle)) as z:
    manifest = z.read('байткод.json')
    m = json.loads(manifest)
    assert m['python'] == runtime['version_info'][:3] == [3, 12, 1]
    assert m['cache_tag'] == runtime['cache_tag'] == 'cpython-312'
    assert m['magic'] == runtime['magic'] == 'cb0d0d0a'
    assert m['pyodide'] == pyodide['Pyodide']['version'] == '0.26.4'
    assert m['компілятор'] == runtime['version']
    for name, meta in sorted(m['модулі'].items()):
        data = z.read(name)
        source_sum.update(name.encode('utf-8') + b'\0' + data)
        pyc = z.read(meta['pyc'])
        assert sha256(data) == meta['source_sha256'], name
        assert sha256(pyc) == meta['pyc_sha256'], meta['pyc']
        assert pyc[:4].hex() == m['magic'] and int.from_bytes(pyc[4:8], 'little') == 3, meta['pyc']
    assert source_sum.hexdigest() == m['source_sha256']
(evidence / 'байткод.json').write_bytes(manifest)

checkout = Path('/tmp/liusterko-verdict-r3-build-26849562/джерела')
deps = {name: json.loads((checkout / 'node_modules' / name / 'package.json').read_bytes())['version']
        for name in ('jsdom', 'fake-indexeddb')}
receipt = {
    'build_exit_code': status, 'git_commit': src['commit'], 'git_tree': src['tree'],
    'build_log_sha256': sha256(log), 'stamp_html': stamp, 'code_fingerprint': fingerprint,
    'source_files': len(src['files']), 'source_manifest_sha256': sha256(sources),
    'source_manifests_equal': True, 'html_sha256': sha256(html), 'html_bytes': len(html),
    'bundle_sha256': sha256(bundle), 'bytecode_manifest_sha256': sha256(manifest),
    'bytecode_modules_verified': len(m['модулі']), 'packed_python_source_sha256': m['source_sha256'],
    'bytecode_compiler': runtime, 'Pyodide': pyodide,
    'compiler_adapter_sha256': sha256((pack / 'інструменти/pyodide-cpython.cjs').read_bytes()),
    'host_python': sys.version, 'node': subprocess.check_output(['node','--version'], text=True).strip(),
    'node_modules': deps, 'command': (evidence / 'команда.txt').read_text().strip(),
}
(evidence / 'квитанція.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(receipt, ensure_ascii=False, indent=2))
