#!/usr/bin/env node
const path = require('node:path');
const cache = '/tmp/liusterko-n2-pyodide-0264';
const [isolated, mode, encoding, command, source, ...rest] = process.argv.slice(2);
if (isolated !== '-I' || mode !== '-X' || encoding !== 'utf8' || command !== '-c'
    || source === undefined || rest.length) {
  process.stderr.write('Адаптер приймає лише -I -X utf8 -c <код>\n');
  process.exit(2);
}
globalThis.fetch = async () => { throw new Error('Рантайм компілятора читає лише локальний кеш'); };
const {loadPyodide} = require(path.join(cache, 'pyodide.js'));
(async () => {
  const chunks = [];
  for await (const chunk of process.stdin) chunks.push(Buffer.from(chunk));
  const py = await loadPyodide({indexURL: cache + '/'});
  py.FS.writeFile('/tmp/lyusterko-stdin', Buffer.concat(chunks));
  py.runPython(`import sys
sys.stdin = open('/tmp/lyusterko-stdin', encoding='utf-8')
sys.stdout = open('/tmp/lyusterko-stdout', 'w', encoding='utf-8')`);
  py.runPython(source);
  py.runPython('sys.stdout.flush()');
  process.stdout.write(Buffer.from(py.FS.readFile('/tmp/lyusterko-stdout')));
})().catch(error => {
  process.stderr.write(String(error) + '\n');
  process.exitCode = 1;
});
