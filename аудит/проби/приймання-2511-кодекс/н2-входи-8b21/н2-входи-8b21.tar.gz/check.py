"""One real legacy judge per outfit. Emit only the facts named in this review."""
import json
import sys
from unittest.mock import patch
from ядро import пул, знання, суд, розбір
from ядро.тести.тест_н2 import _запис, _збір
from ядро.поняття import Ситуація
import суд_від_моделі as legacy
from колір_світлота import перевірка_value_за_слотом

def check(case):
    colours = {'grey': ([40,0,0], '#5e5e5e'), 'red': ([55,65,40], '#e23234')}
    rows = []
    clothes = [('top','верх','сорочка'),('bottom','низ','штани')] if case in ('two_large','diverges','clean_steps','word_no_input') else [('dress','сукня','сукня')]
    rest = [('shoes','взуття','лофери'), ('bag','сумка','сумка')]
    if case in ('one_measured','one_interval'):
        rest = [('jewel','прикраси','сережки')]
    for ident, slot, kind in clothes + rest:
        accented = ident == 'bag' and case in ('red','two_red','unknown_shoe') or ident == 'shoes' and case == 'two_red'
        lab, hexcolour = colours['red' if accented else 'grey']
        if (case == 'diverges' and ident == 'bag' or case == 'clean_steps' and ident == 'bottom'):
            lab, hexcolour = [85,0,0], '#d4d4d4'
        fibre = 'шкіра' if ident == 'bag' and case == 'mixed_fibre' else 'бавовна'
        colour = dict(колір_тип='вимір',колір_джерело='фото',lab=lab,hex=hexcolour)
        if case=='unknown_shoe' and ident=='shoes':
            colour = {}
        if ((case == 'one_interval' and ident == 'dress') or
                (case == 'word_no_input' and ident in ('top','bottom'))):
            colour = dict(колір_тип='інтервал', колір_не_вимір={'свідок':'shop_word','вікно':[27,72,0,7,None]})
        rows.append(_запис(ident,slot,тип=kind,волокно=fibre,**colour))
    scene = Ситуація(1, {}, {})
    pool = пул.зібрати(scene, 1, 37, rows)
    outfit, = розбір.прочитати(_збір(pool, *(r['id'] for r in rows)), 'складання', pool)
    captured = []
    original = legacy.перевірити_від_моделі
    def capture(*args, **kwargs):
        result = original(*args, **kwargs)
        captured.append(result)
        return result
    enumerations = []
    def observe(frame,event,arg):
        if event!='return' or frame.f_code is not перевірка_value_за_слотом.__code__:
            return
        variants = frame.f_locals.get('виходи')
        if variants is not None:
            enumerations.append([[s['code'] for f in result for s in f.get('заяви', ())] for result in variants])
    previous = sys.getprofile()
    try:
        sys.setprofile(observe)
        with patch.object(legacy, 'перевірити_від_моделі', side_effect=capture):
            verdict = суд.судити(outfit, scene, pool, {})
    finally:
        sys.setprofile(previous)
    assert len(captured) == 1 and captured[0]['перевірено']
    raw = captured[0]
    names = {'single_focus','lightness_steps','accent_echo','accent_surfaces_differ','declared_column_known','texture_adds','genre_dominant'}
    cells = {p['що']: p['стан'] for g in ['надлишок','прісність','аксесуари'] for p in raw['чеклісти'][g] if p['що'] in names}
    findings = { (f['правило'],c['code'],f.get('сила')) for f in знання._знахідки(raw)
                 if f['правило'] in ('K-COL-01','K-COL-05','K-ACC-10') for c in f['заяви'] }
    after = {k:v for k,v in verdict.чекліст.items() if k.split('.')[-1] in names}
    after_findings = sorted({(f.правило,f.код) for f in verdict.заяви if f.правило in ('K-COL-01','K-COL-05','K-ACC-10')})
    requests = [s['values'].get('fields') for f in знання._знахідки(raw) if f['правило']=='K-ACC-10' for s in f['заяви'] if s['code']=='rule_input_missing']
    resolved = {r['н']:r['ід'] for r in outfit.речі}
    subjects = [(f.код,[resolved[n] for n in f.речі],f.значення.get('гілка')) for f in verdict.заяви if f.правило in ('K-COL-01','K-COL-05','K-ACC-10')]
    no_input = sorted({(f['правило'],str(f['без_входу']),s['code'])
                       for f in знання._знахідки(raw) if f.get('без_входу') and f['правило'] in ('K-COL-01','K-COL-05')
                       for s in f['заяви']})
    held = [(f.код, [resolved[n] for n in f.речі], f.значення['вага']) for f in verdict.заяви
            if f.правило == 'K-COL-01' and f.значення.get('утримано')]
    return {'held':held, 'real_no_input_extracted':no_input,'lightness_variant_codes':enumerations,'judge_calls':len(captured),'subjects':subjects,'K-ACC-10_requested_fields': requests,'legacy': cells, 'n2': after, 'legacy_findings': sorted(findings,key=repr),'n2_findings': after_findings}
if __name__=='__main__':
    cases = ('red','grey','two_red','mixed_fibre','two_large','unknown_shoe','diverges','clean_steps','word_no_input','one_measured','one_interval')
    defaults = {case:check(case) for case in cases}
    backwards = {g:dict(reversed(tuple(items.items()))) for g,items in reversed(tuple(знання.ЧЕКЛІСТИ.items()))}
    test_order = '--base' not in sys.argv
    if test_order:
        with patch.object(знання,'ЧЕКЛІСТИ',backwards), patch.object(знання,'ПРАВИЛА',dict(reversed(tuple(знання.ПРАВИЛА.items())))):
            assert {case:check(case) for case in cases} == defaults
        assert defaults['red']['subjects'] == [('accent_orphan',['bag'],'сирота')]
        assert defaults['two_large']['subjects'] == [('one_lightness_level_reads_flat',['top','bottom'],'перебір_світлоти')]
        assert defaults['two_red']['n2']['accessories.accent_surfaces_differ'] == {'стан':'немає_входу','поле':'заявлена_колона'}
        assert ['заявлена_колона'] in defaults['two_red']['K-ACC-10_requested_fields']
        assert not any(defaults[c]['subjects'] for c in ['grey','mixed_fibre','unknown_shoe','diverges','clean_steps'])
        assert defaults['clean_steps']['legacy']['lightness_steps'] == 'пройдено'
        assert defaults['diverges']['legacy']['lightness_steps'] == 'без входу'
        cells = lambda c,k: defaults[c]['n2'][k]
        lightness, echo = 'excess.lightness_steps','excess.accent_echo'
        assert cells('two_large',lightness) == dict(стан='суджено',результат=1)
        assert cells('clean_steps',lightness) == dict(стан='суджено',результат=0)
        assert defaults['clean_steps']['lightness_variant_codes'] == [[[],[],[],[]]]
        assert cells('diverges',lightness) == dict(стан='немає_входу',поле='джерело_площі')
        assert cells('word_no_input',lightness) == dict(стан='немає_входу',поле='вимір світлоти')
        assert cells('unknown_shoe',echo) == dict(стан='немає_входу',поле='колір (shoes)')
        assert defaults['two_red']['subjects'] == [('accent_echoed',['shoes','bag'],'тон')]
        assert ('K-COL-01','вхід_правила','areas_not_measured') in defaults['diverges']['real_no_input_extracted']
        assert ('K-COL-01','вхід_правила','cannot_tell_lightness_structure') in defaults['word_no_input']['real_no_input_extracted']
        for c in ['one_measured','one_interval']:
            assert ('K-COL-01','one_weighty_surface','утримано') in defaults[c]['legacy_findings']
            assert defaults[c]['lightness_variant_codes'] == [[['one_weighty_surface']]]
        assert defaults['one_measured']['held'] == [('one_weighty_surface',['dress'],0)]
        assert defaults['one_interval']['held'] == []
        assert cells('one_interval',lightness) == dict(стан='суджено',результат=0)
    print(json.dumps({'reordered_equal':True if test_order else None,'cases':defaults}, ensure_ascii=False, indent=2))
