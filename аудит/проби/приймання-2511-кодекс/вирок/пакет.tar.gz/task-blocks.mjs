import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import vm from "node:vm";

const root = new URL(".", import.meta.url).pathname;
for (const revision of ["base", "candidate"]) {
  const source = fs.readFileSync(path.join(root, revision, "джерела", "показ", "приміряння.js"), "utf8");
  const blockBuilder = /^function блокиЗадачіП\(промпт, фото\)\{[\s\S]*?^\}/m.exec(source);
  assert.ok(blockBuilder);
  const makeBlocks = vm.runInNewContext(`(${blockBuilder[0]})`, Object.create(null));
  const output = path.join(root, "outputs", revision);
  for (const scenario of fs.readdirSync(output)) {
    for (const consumer of ["оцінка", "допит"]) {
      const dir = path.join(output, scenario);
      const raw = fs.readFileSync(path.join(dir, `${consumer}.json`), "utf8");
      const blocks = makeBlocks(raw, []);
      assert.equal(blocks.length, 1);
      assert.equal(blocks[0].text, raw);
      assert.equal(blocks[0].type, "text");
      fs.writeFileSync(path.join(dir, `${consumer}-блоки.json`), JSON.stringify(blocks, null, 2) + "\n");
    }
  }
}
