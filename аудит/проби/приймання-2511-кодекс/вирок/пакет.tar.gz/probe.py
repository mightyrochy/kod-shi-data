import argparse
import copy
import json
import socket
from pathlib import Path

# The probe needs no model response, browser, catalogue, or network.
class NoNetworkSocket(socket.socket):
    def connect(self, *args, **kwargs):
        raise AssertionError("offline probe attempted socket.connect")

    def connect_ex(self, *args, **kwargs):
        raise AssertionError("offline probe attempted socket.connect_ex")


def no_network(*args, **kwargs):
    raise AssertionError("offline probe attempted network access")


socket.socket = NoNetworkSocket
socket.create_connection = no_network
socket.getaddrinfo = no_network

import colorspace
import міст_оцінка
import протокол
import річ_з_фото
import верхнє_довжина as краї

p = argparse.ArgumentParser()
p.add_argument("target", choices=("base", "candidate"))
p.add_argument("--boundary-only", action="store_true")
args = p.parse_args()
root = Path(__file__).resolve().parent
output = (root / "evidence" / "граничний-розрив" if args.boundary_only else root / "outputs") / args.target
output.mkdir(parents=True, exist_ok=True)

dress = {
    "ід": "ф1", "вид": "dress_generic", "слот": "сукня", "назва": "Синтетична сукня",
    "довжина": "коліно", "в_образі": True,
    "вимір": {"lab": colorspace.hx("#375647"), "hex": "#375647", "маска": 0.45},
    "принт": "однотонний",
}
coat = {
    "ід": "ф2", "вид": "coat", "слот": "верхній_шар", "назва": "Синтетичне пальто",
    "довжина": "коліно", "в_образі": True,
    "вимір": {"lab": colorspace.hx("#6a594e"), "hex": "#6a594e", "маска": 0.50},
    "принт": "однотонний",
}
shoes = {
    "ід": "ф3", "вид": "loafers", "слот": "взуття", "назва": "Синтетичне взуття",
    "в_образі": True, "вимір": {"lab": colorspace.hx("#403831"), "hex": "#403831", "маска": 0.15},
    "принт": "однотонний",
}
cases = {
    "незастосовне": [dress, shoes],
    "бракує-вимірів": [dress, coat, shoes],
    "перевірено": [dict(dress, довжина_см=100), dict(coat, довжина_см=60), shoes],
}
if args.boundary_only:
    cases = {"межа-похибки": [dict(dress, довжина_см=100), dict(coat, довжина_см=70), shoes]}
q = {"free_text": "Чи пасують довжини в цьому образі?", "lang": "uk"}
follow = {"free_text": "Що можна сказати про край речей?", "lang": "uk"}
previous = {"answer": "Зразок попередньої відповіді.", "works": [], "change": [], "earlier": []}

def save(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

for name, garments in cases.items():
    out = output if args.boundary_only else output / name
    out.mkdir(exist_ok=True)
    args_court = {
        "крок": "суд", "речі": copy.deepcopy(garments), "крамниця": False,
        "сценарій_оцінки": {"місяць": 11}, "пікселі": {}, "пікселі_фото": {},
        "шкіра": ["#edc4ad"], "волосся": ["#66412f"], "очі": "#6f7858", "зріст": 168,
        "обхвати": {"плечі": 98, "груди": 92, "талія": 74, "стегна": 99},
    }
    save(out / "вхід.json", args_court)
    court = json.loads(міст_оцінка.оцінка(copy.deepcopy(args_court)))
    court.pop("мс")  # wall-clock timing is returned by the bridge, never passed as assessment input
    save(out / "суд.json", court)
    assert court["образ"] == [g["ід"] for g in garments], court["образ"]
    schema = протокол.ОБРАЗ_ВЕРДИКТУ["поля"]["чекліст"]
    save(out / "перевірка-схеми.json", протокол.перевірити(schema, court["суд"]["checklist"]))
    records = [річ_з_фото.запис_каталогу(g) for g in garments]
    measured = {
        "записи": records,
        "розрив_пальто_сукня": краї.розрив_країв(records[1], records[0]) if any(g["слот"] == "верхній_шар" for g in garments) else None,
        "знахідки-правила": краї.краї(records),
    }
    save(out / "краї.json", measured)
    for consumer, request in [
        ("оцінка", {"крок": "оцінка_промпт", "питання": q}),
        ("допит", {"крок": "допит_промпт", "питання": follow, "попередня": previous, "питання_оцінки": q}),
    ]:
        response = json.loads(міст_оцінка.оцінка(dict(request, суд=court, мова_тексту="Ukrainian")))
        raw = response["промпт"]
        assert json.loads(raw), (name, consumer)
        (out / f"{consumer}.json").write_text(raw, encoding="utf-8")
    nad = court["суд"]["checklist"]["надлишок"]
    print(name, "layer_hems", [r for r in nad.get("пункти", []) if r.get("код") == "layer_hems_apart"],
          "unavailable", [r for r in court["без_входу"] if r.get("point") == "layer_hems_apart"],
          "counters", {k: nad[k] for k in ("пройдено", "без_входу", "не_стосується")},
          "gap", measured["розрив_пальто_сукня"],
          "wire", json.loads((out / "оцінка.json").read_text()).get("unknown"))
