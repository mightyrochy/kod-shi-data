import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "outputs"
EVIDENCE = ROOT / "evidence"
DIFFS = ROOT / "diffs"
DIFFS.mkdir(exist_ok=True)

def read(path):
    return json.loads(path.read_bytes())

def render(data):
    return json.dumps(data, ensure_ascii=False, indent=2) + "\n"

def pointer(path):
    return "/" + "/".join(str(part).replace("~", "~0").replace("/", "~1") for part in path)

def semantic(before, after, path=()):
    if before == after:
        return []
    if isinstance(before, dict) and isinstance(after, dict):
        edits = []
        for k in dict.fromkeys([*before, *after]):
            key = path + (k,)
            if k not in before:
                edits.append({"path": pointer(key), "after": after[k]})
            elif k not in after:
                edits.append({"path": pointer(key), "before": before[k]})
            else:
                edits.extend(semantic(before[k], after[k], key))
        return edits
    if isinstance(before, list) and isinstance(after, list):
        edits = []
        matcher = difflib.SequenceMatcher(a=[render(x) for x in before], b=[render(x) for x in after], autojunk=False)
        for kind, b0, b1, a0, a1 in matcher.get_opcodes():
            if kind == "replace" and b1 - b0 == a1 - a0:
                for i, j in zip(range(b0, b1), range(a0, a1)):
                    edits.extend(semantic(before[i], after[j], path + (i,)))
            elif kind != "equal":
                edits.append({
                    "path": pointer(path), "kind": kind, "before_indices": [b0, b1], "after_indices": [a0, a1],
                    "before": before[b0:b1], "after": after[a0:a1],
                })
        return edits
    return [{"path": pointer(path), "before": before, "after": after}]

def missing_hems(court):
    return [row for row in court["без_входу"] if row.get("point") == "layer_hems_apart"]

def candidate_cell(court):
    return next(cell for cell in court["суд"]["checklist"]["надлишок"]["пункти"]
                if cell["код"] == "layer_hems_apart")

def manifest_for(files):
    return [{"file": str(p.relative_to(ROOT)), "bytes": p.stat().st_size,
             "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]

def diff_files(label, before, after, filenames):
    manifest = []
    for name in filenames:
        a, b = before / name, after / name
        x, y = read(a), read(b)
        diffs = semantic(x, y)
        unified = "".join(difflib.unified_diff(render(x).splitlines(keepends=True),
                                               render(y).splitlines(keepends=True),
                                               str(a.relative_to(ROOT)), str(b.relative_to(ROOT))))
        (DIFFS / f"{label}__{a.stem}.diff").write_text(unified)
        (DIFFS / f"{label}__{a.stem}.paths.json").write_text(render(diffs))
        manifest.append({"file": name, "byte_equal": a.read_bytes() == b.read_bytes(),
                         "changed_top_level_fields": [k for k in dict.fromkeys([*x, *y])
                                                      if x.get(k) != y.get(k)] if isinstance(x, dict) else [],
                         "changed_path_count": len(diffs), "measurements": manifest_for([a, b])})
    return manifest

expect = {
    "незастосовне": ("не стосується", "object_absent:верхній_шар"),
    "бракує-вимірів": ("без входу", "system:довжина_виробу_см"),
    "перевірено": ("пройдено", None),
}
all_results = {}
for label, (state, reason) in expect.items():
    a, b = (OUTPUT / rev / label for rev in ("base", "candidate"))
    filenames = [p.name for p in sorted(a.glob("*.json"))]
    assert filenames == [p.name for p in sorted(b.glob("*.json"))]
    old, new = read(a / "суд.json"), read(b / "суд.json")
    actual = candidate_cell(new)
    assert (actual["стан"], actual.get("чому")) == (state, reason), actual
    assert not read(a / "перевірка-схеми.json") and not read(b / "перевірка-схеми.json")
    if state == "без входу":
        assert missing_hems(old) == missing_hems(new)
        assert actual["бракує"][0]["fields"] == ["край_джерело", "довжина_виробу_см"]
    elif state == "не стосується":
        assert len(missing_hems(old)) == 1 and not missing_hems(new)
    else:
        assert not missing_hems(old) and not missing_hems(new)
        measured = read(b / "краї.json")
        assert measured["розрив_пальто_сукня"] == [40.0, 21.34, "measured_same_point"]
        assert not measured["знахідки-правила"]
    for consumer in ("оцінка", "допит"):
        before, after = [read(d / f"{consumer}.json") for d in (a, b)]
        assert before["unknown"] == after["unknown"]
        assert ("layer_hems_apart" in after["check"]["points"]["passed"]) == (state == "пройдено")
        if state == "не стосується":
            assert [k for k in before if before[k] != after[k]] == ["not_in_photo"]
            assert [k for k in after["not_in_photo"] if k not in before["not_in_photo"]] == ["outerwear"]
        else:
            assert (a / f"{consumer}.json").read_bytes() == (b / f"{consumer}.json").read_bytes()
    all_results[label] = diff_files(label, a, b, filenames)

for label in ("граничний-розрив", "каталоговий-шов"):
    a, b = (EVIDENCE / label / rev for rev in ("base", "candidate"))
    filenames = [p.name for p in sorted(a.glob("*.json"))]
    assert filenames == [p.name for p in sorted(b.glob("*.json"))]
    for consumer in ("оцінка", "допит"):
        before, after = [read(d / f"{consumer}.json") for d in (a, b)]
        if label == "каталоговий-шов":
            assert [k for k in before if before[k] != after[k]] == ["unknown"]
            expected = json.loads(json.dumps(before["unknown"]))
            entry = next(row for row in expected if row.get("why") == "catalogue_field_missing")
            entry["no_input"].remove("item_length_cm")
            assert after["unknown"] == expected
        else:
            assert before == after
            assert candidate_cell(read(b / "суд.json"))["стан"] == "пройдено"
            assert "layer_hems_apart" in after["check"]["points"]["passed"]
            assert not any("outer_edges_gap_measured" in row.get("statements", []) for row in after["unknown"])
            for directory in (a, b):
                court = read(directory / "суд.json")
                assert any(row.get("kind") == "утримано" and row.get("rule") == ["K-OUT-03"]
                           and any(z.get("code") == "outer_edges_gap_measured" for z in row.get("statements", []))
                           for row in court["без_входу"])
            assert any(row["правило"] == "K-OUT-03" and row["сила"] == "утримано"
                       for row in read(b / "краї.json")["знахідки-правила"])
    all_results[label] = diff_files(label, a, b, filenames)

(ROOT / "manifest.json").write_text(render(all_results))
for case, files in all_results.items():
    print(case, [(r["file"],r["byte_equal"],r["changed_top_level_fields"])
                 for r in files if r["file"] in ("оцінка.json", "допит.json")])
