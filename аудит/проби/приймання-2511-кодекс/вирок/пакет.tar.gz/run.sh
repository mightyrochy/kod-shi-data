#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
for revision in base candidate; do
  export PYTHONPATH="$PWD/$revision/джерела"
  export PYTHONDONTWRITEBYTECODE=1
  export PYTHONHASHSEED=0
  python3 probe.py "$revision" > "outputs/$revision.log"
  python3 probe.py "$revision" --boundary-only > "evidence/граничний-розрив/$revision.log"
  python3 catalogue-seam.py "$revision" > "evidence/каталоговий-шов/$revision.log"
done
node task-blocks.mjs
python3 compare.py
