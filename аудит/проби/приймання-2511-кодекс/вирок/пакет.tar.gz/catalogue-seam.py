"""Compare the full assessment/follow-up prompts at the catalogue-like input seam."""
import argparse
import json
import socket
from pathlib import Path


def no_network(*args, **kwargs):
    raise AssertionError("offline probe attempted network access")


socket.socket.connect = no_network
socket.socket.connect_ex = no_network
socket.create_connection = no_network
socket.getaddrinfo = no_network

import міст_оцінка as bridge
import оцінка_образу as assessment
import суд_чеклісти as checklist
import вердикт_моделі as verdict

parser = argparse.ArgumentParser()
parser.add_argument("target", choices=("base", "candidate"))
args = parser.parse_args()
root = Path(__file__).resolve().parent
out = root / "evidence" / "каталоговий-шов" / args.target
out.mkdir(parents=True, exist_ok=True)

def save(filename, obj):
    (out / filename).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n")


# Use a catalogue-like identity without the photo item prefix. The existing
# silhouette predicate already accepts a flared bottom with a named unmeasured
# hem, so it does not keep an independent item_length_cm entry alive.
# This case exercises the exact checklist and prompt seams rather than claiming
# that the stock photo endpoint accepts catalogue rows.
items = [
    {"річ":"fixture-bottom", "слот":"низ", "крій":"flared", "край_джерело":"слово",
     "візерунок":"однотон"},
    {"річ":"fixture-top", "слот":"верх", "візерунок":"однотон"},
]
checks = checklist.чеклісти([], items)
raw_court = {"чеклісти": checks}
court = {
    "речі": [
        {"ід":"fixture-bottom", "вид":"trousers", "слот":"низ", "крій":"flared"},
        {"ід":"fixture-top", "вид":"blouse", "слот":"верх"},
    ],
    "образ":["fixture-bottom", "fixture-top"],
    "суд":{"checklist": verdict.чекліст_вердикту(checks)},
    "пункти":assessment._пункти(raw_court),
    "без_входу":assessment._без_входу(raw_court, {}, []),
}
save("вхід.json", items)
save("суд.json", court)
q = {"free_text": "Чи пасують довжини в цьому образі?", "lang": "uk"}
old = {"answer": "Зразок попередньої відповіді.", "works": [], "change": [], "earlier": []}
for filename, supplied in [
    ("оцінка.json", {"крок": "оцінка_промпт", "питання": q}),
    ("допит.json", {"крок": "допит_промпт", "питання": {"free_text":"Що відомо про край?", "lang":"uk"},
                   "попередня":old, "питання_оцінки":q}),
]:
    raw = json.loads(bridge.оцінка(dict(supplied, суд=court, мова_тексту="Ukrainian")))["промпт"]
    (out / filename).write_text(raw)
    print(filename, json.loads(raw).get("unknown"))
