import datetime,hashlib,json,os,pathlib,subprocess,time
import battery_current as B
P=B.P;D=B.D;SHA=B.SHA;B.verify();s=json.loads((D/'checkpoint.json').read_text());assert s['sha']==SHA and s['status']=='FAILED' and len(s['stages'])==10
assert all(x['rc']==0 for n,x in s['stages'].items() if n!='14-збірка')
failed=s['stages']['14-збірка'];assert failed['rc']==1 and 'FileNotFoundError' in (D/'14-збірка.log').read_text() and '/assembled-current/index.html' in (D/'14-збірка.log').read_text();assert not (P/'assembled-current').exists()
(D/'checkpoint-build-path-failed.json').write_text(json.dumps(s,ensure_ascii=False,indent=2));(D/'14-збірка-спроба1-path-failure.log').write_bytes((D/'14-збірка.log').read_bytes());(P/'assembled-current').mkdir()
cmd=dict(B.stages())['14-збірка'];rec={'status':'running','sha':SHA,'command':cmd,'started_at':B.stamp(),'resources_before':B.resources(),'input_manifest_sha256':B.digest((P/'inputs-verified-current.json').read_bytes()),'attempt':2,'previous_failed_attempt':failed,'reason':'Лише власна відсутня вихідна тека; mkdir перед повтором незавершеної збірки; продукт не змінювався'};s['stages']['14-збірка']=rec;s.update(status='RUNNING',own_background_jobs=1,current='14-збірка',pid=os.getpid());B.save(s);print('ПРОДОВЖЕННЯ ЛИШЕ ЗБІРКИ14 ПІСЛЯ mkdir',SHA,flush=True);start=time.monotonic()
with (D/'14-збірка.log').open('wb') as out:rc=subprocess.call(cmd,cwd=B.S,env=B.E,stdout=out,stderr=subprocess.STDOUT)
assert B.git('rev-parse','HEAD').decode().strip()==SHA;rec.update(status='completed',rc=rc,after_sha=SHA,seconds=round(time.monotonic()-start,2),finished_at=B.stamp(),log='14-збірка.log',log_sha256=B.digest((D/'14-збірка.log').read_bytes()),resources_after=B.resources());s['current']=None
if rc:s.update(status='FAILED',own_background_jobs=0);B.save(s);raise SystemExit(rc)
B.verify();s.update(status='COMPLETED',own_background_jobs=0,finished_at=B.stamp(),source_end_sha=SHA,source_end_inputs_exact=True,build_path_setup_failure_preserved=True,completed_other_stages_repeated=0);B.save(s);print('ПРОДОВЖЕННЯ ЗАВЕРШЕНО',SHA,flush=True)
