import pathlib,subprocess,os,re,json,hashlib
P=pathlib.Path('/dev/shm/qa-batch-1510-5');R=P/'repo';W=pathlib.Path('/dev/shm/pachka-1510-5/work')
E={**os.environ,'GIT_NO_LAZY_FETCH':'1','TMPDIR':str(P/'tmp')}
def g(*x):return subprocess.check_output(['git','--git-dir='+str(R),'-c','core.quotePath=false',*x],env=E)
H='0ffb624821c5972d7361c60f73dabcd52e61d9ee';M='7f9e9f8d51c7ea135b68eb3c12aa94c456de324f';S=['1ee1f74b7fb7151e4ccc8c408a01e152c4591474','5a68ba97c03776f293b8494d85fbce8a7fee7255','3f1cb373d5aeab2635c4a22e9798854f49b23db8'];B='аудит/БЕКЛОГ.md'
def rows(v):
 d={}
 for l in v.splitlines(keepends=True):
  if q:=re.match(rb'^\|\s*(\d+)\s*\|',l):
   n=int(q[1]);assert n not in d;d[n]=l
 return d
for x in [M]+S:g('merge-base','--is-ancestor',x,H)
mb=g('show',M+':'+B);hb=g('show',H+':'+B);mr=rows(mb);hr=rows(hb);assert len(mr)==1502 and len(hr)==1503;assert [i for i in hr if i in mr]==list(mr)
for i,l in mr.items():
 if i not in {5641,5580,5685}:assert hr[i]==l
rest=hb
for i in [5641,5580]:rest=rest.replace(hr[i],mr[i],1)
rest=rest.replace(b'\n'+hr[5685],b'',1);assert rest==mb
for i,s in zip([5641,5580,5685],S):assert hr[i]==rows(g('show',s+':'+B))[i]
cur='9961b3b5ed806aaba9db7dcec5aa1f8dc691f308';steps=[]
g('merge-base','--is-ancestor',cur,H)
for s,remote in zip(S,['7e1e90e563ce08181080e7b8cf409b46cfe4e719','2bb01196e4732e619f9a62bc57fea81891ecb04a',H]):
 q=subprocess.run(['git','--git-dir='+str(R),'-c','core.quotePath=false','merge-tree','--write-tree',cur,s],env=E,capture_output=True);assert q.returncode in [0,1]
 raw=q.stdout.decode();tree=raw.splitlines()[0];assert all(B in l for l in raw.splitlines() if l.startswith('CONFLICT'))
 dif=g('diff','--name-only','-z',tree,remote).decode().split('\0')[:-1];assert all(x==B for x in dif),dif
 assert g('show','-s','--format=%P',remote).decode().split()==[cur,s]
 steps.append({'source':s,'merge':remote,'auto_tree':tree,'manual_paths':dif});cur=remote
g('diff','--check',M,H)
out={'head':H,'main':M,'ancestry':True,'steps':steps,'main_ids':len(mr),'head_ids':len(hr),'foreign_bytes_exact':True,'order_exact':True,'own_rows_exact':True,'duplicates':0,'diff_check':True,'new_build_browser_tests':0}
(P/'proof-current/composition.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(out,ensure_ascii=False))
