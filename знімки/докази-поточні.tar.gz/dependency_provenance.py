import ast,hashlib,json,pathlib
P=pathlib.Path('/dev/shm/pachka-1510-5');S=P/'work/джерела';inputs={x['path']:x for x in json.loads((P/'history-9961/inputs-verified.json').read_text())};modules={str(p.relative_to(S)).removesuffix('.py').replace('/','.'):p for p in S.rglob('*.py')};parsed={}
for name,p in modules.items():
 tree=ast.parse(p.read_bytes(),filename=str(p));deps=set();dynamic=[]
 for x in ast.walk(tree):
  if isinstance(x,ast.Import):deps.update(a.name for a in x.names)
  elif isinstance(x,ast.ImportFrom) and x.module:deps.add(x.module)
  elif isinstance(x,ast.Call) and ((isinstance(x.func,ast.Name) and x.func.id=='__import__') or (isinstance(x.func,ast.Attribute) and x.func.attr=='import_module')):
   if x.args and isinstance(x.args[0],ast.Constant) and isinstance(x.args[0].value,str):deps.add(x.args[0].value)
   else:dynamic.append(x.lineno)
 parsed[name]={'local_imports':sorted(d for d in deps if d in modules),'unresolved_dynamic_import_lines':dynamic}
roots={'03-каталоги':['чистка_каталогу','feed'],'04-дим':['стенд_знімок'],'05-живий-шлях':['тест_живого_шляху'],'06-протокол':['тест_протоколу']};out={'head':'9961b3b5ed806aaba9db7dcec5aa1f8dc691f308','method':'AST локальних import/import-from та літеральних import_module/__import__; невизначені динамічні імпорти перелічені явно, не доведені','stages':{}}
for stage,start in roots.items():
 queue=list(start);seen=set()
 while queue:
  name=queue.pop()
  if name in seen:continue
  seen.add(name);queue.extend(parsed[name]['local_imports'])
 files={};dynamic={}
 for name in sorted(seen):
  key='джерела/'+str(modules[name].relative_to(S));files[key]={'git_blob':inputs[key]['sha'],'sha256':inputs[key]['sha256']}
  if parsed[name]['unresolved_dynamic_import_lines']:dynamic[key]=parsed[name]['unresolved_dynamic_import_lines']
 out['stages'][stage]={'roots':start,'files':files,'unresolved_dynamic_imports':dynamic}
(P/'history-9961/dependency-provenance.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print({k:{'files':len(v['files']),'dynamic':v['unresolved_dynamic_imports']} for k,v in out['stages'].items()})
