import sys,os,subprocess,json,pathlib,re,base64
sys.path.insert(0,'/dev/shm/pachka-1510-5');from hydrate import git as g,E,R
P=pathlib.Path('/dev/shm/pachka-1510-5');E.update(GIT_AUTHOR_NAME='mightyrochy',GIT_AUTHOR_EMAIL='289388706+mightyrochy@users.noreply.github.com',GIT_COMMITTER_NAME='mightyrochy',GIT_COMMITTER_EMAIL='289388706+mightyrochy@users.noreply.github.com')
M='7f9e9f8d51c7ea135b68eb3c12aa94c456de324f';OLD='9961b3b5ed806aaba9db7dcec5aa1f8dc691f308';B='аудит/БЕКЛОГ.md'
heads=[(1070,'1ee1f74b7fb7151e4ccc8c408a01e152c4591474',5641),(1071,'5a68ba97c03776f293b8494d85fbce8a7fee7255',5580),(1082,'3f1cb373d5aeab2635c4a22e9798854f49b23db8',5685)]
def rows(b):
 out={}
 for l in b.decode().splitlines(keepends=True):
  if m:=re.match(r'^\|\s*(\d+)\s*\|',l):
   i=int(m[1]);assert i not in out;out[i]=l
 return out
mainboard=g('show',M+':'+B);mr=rows(mainboard);board=mainboard.decode()
for n,h,own in heads:
 source=rows(g('show',h+':'+B));line=source[own]
 if own in mr:board=board.replace(mr[own],line,1)
 else:
  assert own==5685;anchor=mr[5686];board=board.replace(anchor,'\n'+line+anchor,1)
expected=board.encode();current=OLD;steps=[]
for n,h,own in heads:
 g('merge-base','--is-ancestor',M,h)
 run=subprocess.run(['git','--git-dir='+R,'merge-tree','--write-tree',current,h],env=E,capture_output=True);(P/f'remerge-{n}.txt').write_bytes(run.stdout+run.stderr);assert run.returncode in [0,1],run.stderr
 tree=run.stdout.decode().splitlines()[0];conflicts=[l for l in run.stdout.decode().splitlines() if l.startswith('CONFLICT')];assert all('БЕКЛОГ.md' in l for l in conflicts),conflicts
 if conflicts:
  blob=g('hash-object','-w','--stdin',input=expected).decode().strip();E['GIT_INDEX_FILE']=str(P/f'reindex-{n}');g('read-tree',tree);g('update-index','--add','--cacheinfo','100644,'+blob+','+B);tree=g('write-tree','--missing-ok').decode().strip();del E['GIT_INDEX_FILE']
 assert g('show',tree+':'+B)==expected,'normal merge board differs expected full bytes'
 g('diff','--check',current,tree)
 entries=[];new=[];known={rec.split(b'\t')[0].split()[2].decode() for ref in [current,h] for rec in g('ls-tree','-rz',ref).split(b'\0') if rec};chunks=g('diff-tree','-r','--raw','-z',current,tree).split(b'\0')
 for k in range(0,len(chunks)-1,2):
  x=chunks[k].decode().split();path=chunks[k+1].decode();sha=x[3] if x[4]!='D' else None;entries.append({'path':path,'mode':x[1],'type':'blob','sha':sha})
  if sha and sha not in known:
   b=g('cat-file','blob',sha);(P/(sha+'.b64')).write_text(base64.b64encode(b).decode());new.append({'sha':sha,'path':path,'base64_length':len(base64.b64encode(b))})
 message=f'Оновити пачку 1510-5 після злиття #1078 і #1079: додати актуальний PR #{n}'
 commit=g('commit-tree',tree,'-p',current,'-p',h,input=(message+'\n').encode()).decode().strip();steps.append({'n':n,'source':h,'tree':tree,'local_parent':current,'local_commit':commit,'base_tree':g('rev-parse',current+'^{tree}').decode().strip(),'entries':entries,'newblobs':new,'own_row':own,'message':message});current=commit
for ref in [M,OLD,*[h for _,h,_ in heads]]:g('merge-base','--is-ancestor',ref,current)
rr=rows(expected);assert [i for i in rr if i in mr]==list(mr)
for i,line in mr.items():
 if i not in [5641,5580,5685]:assert rr[i]==line
rest=expected
for n,h,own in reversed(heads):
 line=rows(rest)[own]
 rest=rest.replace(line.encode(),mr[own].encode(),1) if own in mr else rest.replace(('\n'+line).encode(),b'',1)
assert rest==mainboard
oldinputs={x['path']:x for x in json.loads((P/'history-9961/inputs-verified.json').read_text())};delta=[]
for path,x in oldinputs.items():
 newsha=g('rev-parse',current+':'+path).decode().strip()
 if newsha!=x['sha']:delta.append({'path':path,'old':x['sha'],'new':newsha})
closure=json.loads((P/'history-9961/dependency-provenance.json').read_text());reuse={}
for stage,x in closure['stages'].items():
 assert not x['unresolved_dynamic_imports']
 changed=[path for path,want in x['files'].items() if g('rev-parse',current+':'+path).decode().strip()!=want['git_blob']];assert not changed,(stage,changed);reuse[stage]={'status':'BYTE_PROVENANCE_EXACT_HISTORICAL_PASS','old_head':OLD,'old_completed_stage':stage,'local_import_files':len(x['files']),'unchanged_closure':True,'unresolved_dynamic_imports':0}
out={'old_head':OLD,'main':M,'local_final':current,'tree':steps[-1]['tree'],'steps':steps,'main_ids':len(mr),'board_ids':len(rr),'foreign_board_bytes_exact':True,'delta_from9961':delta,'dated_reuse':reuse};(P/'reassembly.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in out.items() if k not in ['steps','delta_from9961']},ensure_ascii=False));print('delta',[x['path'] for x in delta]);print('steps',[(s['n'],len(s['entries']),s['newblobs']) for s in steps])
