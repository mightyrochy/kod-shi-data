import pathlib,subprocess,os,re,json,hashlib
P=pathlib.Path('/dev/shm/qa-batch-1510-5');R=P/'repo';W=pathlib.Path('/dev/shm/pachka-1510-5/work')
E={**os.environ,'GIT_NO_LAZY_FETCH':'1','TMPDIR':str(P/'tmp')}
def g(*x):return subprocess.check_output(['git','--git-dir='+str(R),'-c','core.quotePath=false',*x],env=E)
H='9961b3b5ed806aaba9db7dcec5aa1f8dc691f308';M='0750a9494e0057995d5f0b4151a71a09b6ddae14';S=['202898c4e3e0f08d88c619c7b63dec0ac95702d6','9b9d4314e1b984ce02081f71da1c12ea894abf2c','a8bed1b02dcce3eb1b5315b0ceb2976ed0669927'];B='аудит/БЕКЛОГ.md'
def rows(v):
 d={}
 for l in v.splitlines(keepends=True):
  if q:=re.match(rb'^\|\s*(\d+)\s*\|',l):
   n=int(q[1]);assert n not in d;d[n]=l
 return d
for x in [M]+S:g('merge-base','--is-ancestor',x,H)
mb=g('show',M+':'+B);hb=g('show',H+':'+B);mr=rows(mb);hr=rows(hb);assert len(mr)==1500 and len(hr)==1501;assert [i for i in hr if i in mr]==list(mr)
for i,l in mr.items():
 if i not in {5641,5580,5685}:assert hr[i]==l
rest=hb
for i in [5641,5580]:rest=rest.replace(hr[i],mr[i],1)
rest=rest.replace(b'\n'+hr[5685],b'',1);assert rest==mb
for i,s in zip([5641,5580,5685],S):assert hr[i]==rows(g('show',s+':'+B))[i]
cur=M;steps=[]
for s,remote in zip(S,['70bb8d7c6b40eaedf4e1b7e51070610dc65cfaaf','212404957965e360a6181878b104c865b3057b5a',H]):
 q=subprocess.run(['git','--git-dir='+str(R),'-c','core.quotePath=false','merge-tree','--write-tree',cur,s],env=E,capture_output=True);assert q.returncode in [0,1]
 raw=q.stdout.decode();tree=raw.splitlines()[0];assert all(B in l for l in raw.splitlines() if l.startswith('CONFLICT'))
 dif=g('diff','--name-only','-z',tree,remote).decode().split('\0')[:-1];assert all(x==B for x in dif),dif
 assert g('show','-s','--format=%P',remote).decode().split()==[cur,s]
 steps.append({'source':s,'merge':remote,'auto_tree':tree,'manual_paths':dif});cur=remote
g('diff','--check',M,H)
inputs=[];src=P/'work'
for rec in g('ls-tree','-rz',H).split(b'\0'):
 if not rec:continue
 meta,path=rec.split(b'\t');mode,typ,sha=meta.decode().split();path=path.decode();f=W/path
 if f.is_file():
  v=f.read_bytes();got=hashlib.sha1(b'blob '+str(len(v)).encode()+b'\0'+v).hexdigest();assert got==sha,(path,got,sha)
  dest=src/path;dest.parent.mkdir(parents=True,exist_ok=True);
  if not dest.exists():dest.symlink_to(f)
  inputs.append({'path':path,'blob':sha,'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()})
assert len(inputs)>=1560

(P/'proof/inputs.json').write_text(json.dumps(inputs,ensure_ascii=False,indent=2))
out={'head':H,'main':M,'ancestry':True,'steps':steps,'main_ids':len(mr),'head_ids':len(hr),'foreign_bytes_exact':True,'order_exact':True,'own_rows_exact':True,'duplicates':0,'diff_check':True,'source_inputs':len(inputs)}
(P/'proof/composition.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(out,ensure_ascii=False))
