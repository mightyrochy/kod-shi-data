import datetime,hashlib,json,os,pathlib,re,subprocess,sys,time
P=pathlib.Path('/dev/shm/pachka-1510-5');G=P/'repo';W=P/'work';S=W/'джерела';D=P/'proof';D.mkdir(exist_ok=True)
F=json.loads((P/'frozen.json').read_text());SHA=F['head'];TREE=F['tree'];MAIN=F['main']
E={**os.environ,'GIT_NO_LAZY_FETCH':'1','TMPDIR':str(P/'tmp'),'PYTHONDONTWRITEBYTECODE':'1','NODE_PATH':'/workspace/kod-shi-data/джерела/node_modules','PATH':'/workspace/liusterko-tools/bin:/workspace/liusterko-tools/node22/node_modules/node/bin:'+os.environ['PATH'],'LYUSTERKO_CATALOG':'повний'}
def git(*a):return subprocess.check_output(['git','--git-dir='+str(G),*a],env=E)
def digest(b):return hashlib.sha256(b).hexdigest()
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def resources():return {k:pathlib.Path('/sys/fs/cgroup',k).read_text().strip() for k in ['memory.current','memory.max','memory.events']}
def save(d):
 b=json.dumps(d,ensure_ascii=False,indent=2).encode();assert len(b)<50000;(D/'checkpoint.json').write_bytes(b)
def stages():
 syntax="import pathlib,subprocess,sys; fs=[p for p in pathlib.Path('.').rglob('*') if p.is_file() and 'node_modules' not in p.parts]; py=[p for p in fs if p.suffix=='.py']; js=[p for p in fs if p.suffix=='.js']; [compile(p.read_bytes(),str(p),'exec') for p in py]; rs=[subprocess.run(['node','--check',str(p)]).returncode for p in js]; print('Синтаксис Python',len(py),'JS',len(js),'збоїв',sum(x!=0 for x in rs)); sys.exit(any(rs))"
 split="import pathlib,subprocess,sys; fs=sorted(pathlib.Path('проби').glob('поділ_*_ast.py')); rs=[subprocess.run([sys.executable,str(f)]).returncode for f in fs]; print('Проби поділу',len(fs),'ВПАЛО',sum(x!=0 for x in rs)); sys.exit(any(rs))"
 prep="import чистка_каталогу as ч,feed as Ф; print('фід:',ч.забезпечити_чистим('каталог_повний.xml')); print('фікстура:',Ф.каталог_на_диску('каталог_brief.xml'))"
 py=sys.executable
 return [('01-синтаксис',[py,'-c',syntax]),('02-поділ',[py,'-c',split]),('03-каталоги',[py,'-c',prep]),('04-дим',[py,'стенд_знімок.py','--дим']),('05-живий-шлях',[py,'тест_живого_шляху.py']),('06-протокол',[py,'тест_протоколу.py']),('07-гейти',[py,'прилади/розділи_гейтів.py']),('08-контракти',[py,'audit_contracts.py']),('09-показ',['node','тест_показу.js']),('10-міст',['node','тест_мосту.js']),('11-досяжність',[py,'досяжність.py']),('12-наявність5641',[py,'-W','ignore','проби/каталог_наявність_5641.py','каталог_повний.xml']),('13-захист5685',[py,'проби/захист_ci.py']),('14-збірка',[py,'build_артефакт.py','.',str(P/'assembled/index.html'),'показ-повний'])]
def verify():
 assert git('rev-parse','HEAD').decode().strip()==SHA
 assert git('rev-parse',SHA+'^{tree}').decode().strip()==TREE
 for x in json.loads((P/'inputs-expected.json').read_text()):
  b=(W/x['path']).read_bytes();assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==x['sha'],x['path']
def prepare():
 verify()
 for ref in [MAIN,*[x['source'] for x in F['history']]]:git('merge-base','--is-ancestor',ref,SHA)
 provenance={'pr':1094,'sha':SHA,'tree':TREE,'main':MAIN,'sources':F['history'],'commands':dict(stages()),'inputs_sha256':digest((P/'inputs-verified.json').read_bytes()),'source_entries':1543,'model_calls':0,'paid_calls':0,'native_scope':'Незалежна вузька Chromium QA виконується окремим рецензентом на цій голові; авторський browser не дублює її','dependency_runtime':'Наявний спільний Node22/jsdom/fake-indexeddb, без копій node_modules чи повторного встановлення source locks','catalog_root_blob':'04d84f5556cf4654f10a594128c3531530773649','prepared_at':stamp(),'resources':resources()}
 (D/'provenance.json').write_text(json.dumps(provenance,ensure_ascii=False,indent=2));save({'sha':SHA,'tree':TREE,'status':'PREPARED_WAIT_NATIVE_RELEASE','stages':{},'battery_started':False,'own_background_jobs':0,'prepared_at':stamp()});print('ПІДГОТОВЛЕНО, етапів0',SHA)
def run():
 token=json.loads((P/'heavy-token.json').read_text());assert token['sha']==SHA and token['released_by']=='review_batch_1510_5' and token['browser_server_heavy']==0
 state=json.loads((D/'checkpoint.json').read_text());assert state['sha']==SHA and not state['battery_started'],'ONE батарею вже починали'
 verify();state.update(status='RUNNING',battery_started=True,own_background_jobs=1,started_at=stamp(),pid=os.getpid());save(state)
 for name,cmd in stages():
  assert git('rev-parse','HEAD').decode().strip()==SHA
  log=D/(name+'.log');rec={'status':'running','sha':SHA,'command':cmd,'started_at':stamp(),'resources_before':resources(),'input_manifest_sha256':digest((P/'inputs-verified.json').read_bytes())};state['stages'][name]=rec;state['current']=name;save(state);print('СТАРТ',name,flush=True);start=time.monotonic()
  with log.open('wb') as out:rc=subprocess.call(cmd,cwd=S,env=E,stdout=out,stderr=subprocess.STDOUT)
  after=git('rev-parse','HEAD').decode().strip();assert after==SHA
  if name=='12-наявність5641' and rc==0:
   facts=re.search(r'каталог / ключ / недоступні / недоступні у пулі:\s*(\d+)\s+(\d+)\s+(\d+)\s+(\d+)',log.read_text());assert facts,'Немає фактичної лічби наявності';nums=list(map(int,facts.groups()));assert nums[0]==nums[1] and nums[3]==0,nums;rec['catalog_key_unavailable_pool']=nums
  if name=='13-захист5685' and rc==0:
   facts=json.loads(log.read_text());assert facts['uses_всього']==19 and facts['npm_пакети_всього']==facts['npm_пакети_з_integrity']==41
   assert all(facts[k]==0 for k in ['uses_без_SHA40','npm_i_без_lock','pip_без_require_hashes','workflow_глобальний_write','CDN_скрипти_без_SRI','Fixel_рухомий_main']),facts;rec['security_facts']=facts
  if name=='11-досяжність':
   (D/'досяжність.md').write_bytes((S/'аудит/ДОСЯЖНІСТЬ.md').read_bytes());(S/'аудит/ДОСЯЖНІСТЬ.md').write_bytes(git('show',SHA+':джерела/аудит/ДОСЯЖНІСТЬ.md'))
   if rc==0:
    hits=re.findall(r'«НІХТО» = (\d+)',log.read_text());assert hits and hits[-1]=='0',hits
  rec.update(status='completed',rc=rc,after_sha=after,seconds=round(time.monotonic()-start,2),finished_at=stamp(),log=log.name,log_sha256=digest(log.read_bytes()),resources_after=resources());state['current']=None;save(state);print('КІНЕЦЬ',name,'rc',rc,flush=True)
  if rc:state.update(status='FAILED',own_background_jobs=0,finished_at=stamp());save(state);raise SystemExit(rc)
 verify();state.update(status='COMPLETED',own_background_jobs=0,finished_at=stamp(),source_end_sha=SHA,source_end_inputs_exact=True);save(state);print('БАТАРЕЯ ЗАВЕРШЕНА',SHA,flush=True)
if __name__=='__main__':
 if sys.argv[1]=='prepare':prepare()
 else:run()
