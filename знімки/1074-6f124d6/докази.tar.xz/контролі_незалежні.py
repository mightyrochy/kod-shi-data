"""Адресні контрприклади попередніх вад; не повтор 195 старих перевірок."""
import contextvars, copy, json, os, sys
from pathlib import Path
sys.dont_write_bytecode=True
root=Path('/dev/shm/qa1074-r3'); src=root/'repo'/'джерела'
sys.path.insert(0,str(src)); os.chdir(src)
import формальність as Ф, правило_руки2 as П, композитор_придатні as К
import суд_від_моделі as С, міст_пакет as М
checks=[]
def check(name, condition, **facts):
    checks.append(dict(перевірка=name, пройдено=bool(condition), **facts))
def item(i, level=None, **kw):
    return dict(id=i, річ=i, слот='верх', тип='qa_unknown_type', модифікатори=[], зони=[],
                **({'формальність':level} if level is not None else {}), **kw)
def findings(rows):
    return [x for x in rows if x.get('правило')=='K-KOH-02' and x.get('ремонт_заяви')]

for band, target in [([4,6],3),([1,3],4),([10,10],9),([1,10],None)]:
    scene=Ф.сценарій(місце='ресторан', нагода='побачення', смуга=band)
    with П.зламано(П.ЗА_ІД['K-KOH-02']['коди']):
        judges=Ф.формальність_образу([item('нормальна',band[0])], scene, ід_образу=['нормальна','пальто'])
        repairs=findings(judges)
        pool, removed, _=К._поза_сценою([item(str(i),i) for i in range(1,11)],dict(ошатність=band))
        check('сусідній зовнішній щабель '+str(band),
              (not repairs and not П.тінь()) if target is None else
              bool(repairs) and repairs[0]['ремонт_заяви'][0]['values']['band']==[target,target]
              and [r['формальність'] for r in pool]==[target],
              смуга=band, ціль=target, пул=[r['формальність'] for r in pool], знахідки=judges)
        check('повна адреса при прямому суді '+str(band), target is None or all(
              r.get('образ')==['нормальна','пальто'] for r in П.тінь() if r.get('де')=='judge'))
    check('доступність жеребу '+str(band), П.вхід(П.ЗА_ІД['K-KOH-02'],dict(сценарій=dict(ошатність=band)))[0] == (target is not None))

overlap=dict(item('перетин'),тип='трикотаж')
neighbor=item('сусід',3)
unknown=item('невідоме')
with П.зламано(П.ЗА_ІД['K-KOH-02']['коди']):
    pool, removed, _=К._поза_сценою([overlap,neighbor,unknown],dict(ошатність=[4,6]))
    judges=Ф.формальність_образу([overlap,neighbor,unknown],dict(діапазон=[4,6]),ід_образу=['перетин','сусід','невідоме','пальто'])
    repairs=findings(judges)
    check('перетин зі справною смугою не є поломкою', {r['id'] for r in pool}=={'сусід','невідоме'}
          and repairs and repairs[0]['речі']==['перетин'], смуга_перетину=Ф.інтервал_формальності(overlap), знахідки=judges)
    unknown_findings=[r for r in judges if r.get('без_входу')]
    check('невідоме не адресат ремонту', unknown_findings and all(r.get('сила_нп')==0 and r.get('регістр')=='питання' for r in unknown_findings)
          and all('невідоме' not in r.get('речі',[]) for r in repairs))
with П.зламано(П.ЗА_ІД['K-KOH-02']['коди']):
    judges=Ф.формальність_образу([unknown],dict(діапазон=[4,6]),ід_образу=['невідоме','пальто'])
    check('усе невідоме: питання без дії', not findings(judges) and not П.тінь()
          and any(r.get('без_входу') and r.get('сила_нп')==0 for r in judges), знахідки=judges)

base=[dict(id=str(i),слот=slot) for i,slot in enumerate(('верх','низ','взуття','сумка','пояс','верхній_шар'))]
for code in ['K-CRA-01','K-OUT-33']:
    with П.зламано(П.ЗА_ІД[code]['коди']):
        _, judges=С.структура_образу_заяви(base,сценарій=dict(нагода='побачення',місце='ресторан',темп_c=5),верхні=[base[-1]])
        card=П.тінь_образу(П.тінь(),[r['id'] for r in base])
        selected=[r for r in judges if r.get('правило') in П.ЗА_ІД[code]['коди']]
        check(code+': повна картка й точні метадані', selected and card and all(any(
            all(s.get(k)==r.get(k) for k in ['правило','речі','сила','сила_нп','суть'])
            and s.get('дія')=='remove_items' and s.get('правильна') and s.get('хибна') for s in card) for r in selected),
            знахідки=selected, тінь=card)
        check(code+': адресат не підміняє повний образ', all(not П.тінь_образу(П.тінь(),r.get('речі')) for r in selected))

other=[r for r in П.ПЕРЕЛІК if r['ід'] not in ['K-CRA-01','K-KOH-02','K-OUT-33','R-MUA-02']]
check('залишилось саме 10 інших правил', len(other)==10)
for record in other:
    with П.зламано(record['коди']):
        check(record['ід']+': чинна абляція', not П.зламані() and all(П.вимкнене(c) for c in record['коди']))
check('R-MUA-02 поза жеребом', 'R-MUA-02' in П.ПОЗА_ЖЕРЕБОМ and П.ЗА_ІД['R-MUA-02']['аспект'] is None)
def state():
    return dict(зламані=sorted(П.зламані()),вимкнені=sorted(П.вимкнені()),стежені=sorted(П.стежені()),тінь=П.тінь())
initial=state()
with П.зламано(['K-CRA-01','K-MAT-03']):
    check('змішана дія й абляція', П.зламане('K-CRA-01') and П.вимкнене('K-MAT-03'))
    prior=state()
    try:
        with П.зламано(['K-KOH-02']):
            raise ValueError('незалежна перевірка відновлення')
    except ValueError:
        pass
    check('виняток відновлює зовнішній контекст', state()==prior)
    check('окремий context не успадковує поломку', contextvars.Context().run(state)==initial)
check('остаточне відновлення', state()==initial)
keys=[]
for ctx in [П.вимкнено([]),П.вимкнено(['K-KOH-02']),П.зламано(['K-KOH-02'])]:
    with ctx:
        keys.append(М._входи_пакета({},None,None,None,вимкнені_правила=['K-KOH-02'] if П.вимкнені() or П.зламані() else []))
check('три режими мають різні ключі кешу',len({json.dumps(k,sort_keys=True) for k in keys})==3)
(root/'proof'/'контролі-результат.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
failed=[c for c in checks if not c['пройдено']]
print(json.dumps(dict(перевірок=len(checks),невдалі=failed),ensure_ascii=False))
sys.exit(bool(failed))
