"""Зафіксувати віддалене дерево джерел у власній теці без запису в checkout автора."""
from pathlib import Path
import gzip, hashlib, json, os, subprocess

root=Path('/dev/shm/qa1074-r3')
writer=Path('/dev/shm/broken5571/repo')
source=root/'repo'/'джерела'
source.mkdir(parents=True, exist_ok=True)
tree=json.loads((root/'proof'/'remote-source-tree.json').read_text())
manifest={}
def blob_sha(raw):
    return hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
for entry in tree['tree']:
    if entry['type']!='blob' or entry['path'].endswith('.jpg'):
        continue
    relative=Path('джерела')/entry['path']
    local=writer/relative
    raw=local.read_bytes() if local.is_file() else b''
    origin='робочий файл із перевіреним Git SHA'
    if blob_sha(raw)!=entry['sha']:
        raw=subprocess.check_output(['git','-C',str(writer),'cat-file','blob',entry['sha']], env={**os.environ,'GIT_NO_LAZY_FETCH':'1'})
        origin='Git blob за віддаленим SHA'
    assert blob_sha(raw)==entry['sha'], str(relative)
    dest=root/'repo'/relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(raw)
    manifest[str(relative)]={'git_blob':entry['sha'],'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'джерело':origin}
raw=(writer/'каталог_повний.xml.gz').read_bytes()
assert blob_sha(raw)=='04d84f5556cf4654f10a594128c3531530773649'
(root/'repo'/'каталог_повний.xml.gz').write_bytes(raw)
xml=gzip.decompress(raw)
(root/'repo'/'каталог_повний.xml').write_bytes(xml)
(source/'каталог_повний.xml').symlink_to('../каталог_повний.xml')
manifest['каталог_повний.xml.gz']={'git_blob':blob_sha(raw),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
manifest['каталог_повний.xml']={'sha256':hashlib.sha256(xml).hexdigest(),'bytes':len(xml),'джерело':'gzip від перевіреного Git blob'}
(root/'proof'/'source-manifest.json').write_text(json.dumps({'sha':'6f124d64056eb9458b5b78a86f40dfca8d24ed48','tree':tree['sha'],'files':manifest},ensure_ascii=False,indent=2))
print(json.dumps({'файлів':len(manifest),'байтів':sum(x['bytes'] for x in manifest.values()),'дерево':tree['sha']},ensure_ascii=False))
