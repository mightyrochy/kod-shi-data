"""Підготовка власного каталогу точно функцією job perevirka актуального zbirka.yml."""
from pathlib import Path
import json, os, sys, hashlib
root=Path('/dev/shm/qa1074-r3'); src=root/'repo'/'джерела'
sys.dont_write_bytecode=True; sys.path.insert(0,str(src)); os.chdir(src)
import чистка_каталогу as Ч, feed as Ф
result=Ч.забезпечити_чистим('каталог_повний.xml')
Ф.каталог_на_диску('каталог_brief.xml')
data=(root/'repo'/'каталог_повний.xml').read_bytes()
result.update(sha256=hashlib.sha256(data).hexdigest(),байтів=len(data),
              команда_CI="ч.забезпечити_чистим('каталог_повний.xml')")
(root/'proof'/'підготовка-каталогу.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(dict(sha256=result['sha256'],байтів=len(data),почищено=result['почищено']),ensure_ascii=False))
