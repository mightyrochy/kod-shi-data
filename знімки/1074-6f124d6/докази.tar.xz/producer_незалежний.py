"""Незалежна перевірка #1074: справжній producer, ідентичність до погодних станів, кеш і точний споживач."""
import copy, hashlib, json, os, sys
from pathlib import Path

sys.dont_write_bytecode = True
root = Path('/dev/shm/qa1074-r3')
src = root / 'repo' / 'джерела'
sys.path.insert(0, str(src)); os.chdir(src)
import bridge as Б
import feed as Фід
import формальність as Ф
import правило_руки2 as П
import суд_огляд as О
import суд_інтерес as І
import міст_пакет as М

def sha(obj):
    return hashlib.sha256(json.dumps(obj, ensure_ascii=False, sort_keys=True).encode()).hexdigest()

checks, cases, observed, consumed = [], [], [], []
def check(name, condition, **facts):
    checks.append(dict(перевірка=name, пройдено=bool(condition), **facts))

def relevant(values):
    return [copy.deepcopy(v) for v in values if v.get('правило') == 'K-KOH-02']

real_judge = Ф.формальність_образу
def spy_judge(origin):
    def call(elements, сцен=None, *args, **kwargs):
        result = real_judge(elements, сцен, *args, **kwargs)
        observed.append(dict(місце=origin, видимі=sorted({str(e.get('річ')) for e in elements}),
                             повні=copy.deepcopy(kwargs.get('ід_образу')), сцена=copy.deepcopy(сцен),
                             знахідки=relevant(result)))
        return result
    return call
О.формальність_образу = spy_judge('review')
І.формальність_образу = spy_judge('метрики')
real_consumer = П.тінь_образу
def spy_consumer(records, ids, slots=None):
    result = real_consumer(records, ids, slots)
    consumed.append(dict(картка=list(ids or []), вхід=relevant(records), вихід=copy.deepcopy(result)))
    return result
П.тінь_образу = spy_consumer
real_feed = Фід.прогін
feed_calls = []
def spy_feed(*args, **kwargs):
    feed_calls.append(len(feed_calls) + 1)
    return real_feed(*args, **kwargs)
Фід.прогін = spy_feed

input_data = dict(json.loads(Path('стенд_вх.json').read_text()), каталог='каталог_повний.xml', сід=17,
                  сценарій=dict(нагода='побачення', місце='ресторан', темп_c=5, ошатність=[4, 6]))
record = П.ЗА_ІД['K-KOH-02']
П.жереб = lambda *args, **kwargs: (П.злити([record]), ['K-KOH-02'], {}, dict(дія='pool', чому=None))
packet = json.loads(Б.виклик('запити', json.dumps(input_data, ensure_ascii=False)))
assert not packet.get('помилка'), packet
catalog = Б.каталог_останнього_пакета()
by_id = {r['id']: r for r in catalog}
ids = ['ж-01634@bella-bicchi.com', 'ж-00014@maxa.ua', 'ж-08676@cultboutique.com.ua',
       'ж-07780@giardini-shoes.com', 'ж-03852@likeangel.com.ua']
assert all(i in by_id for i in ids)
old = json.loads(Path('/workspace/scratch/qa1074-after-fix/доказ.json').read_text())
old_case = next(c for c in old['producer'] if c['режим'] == 'до' and c['правила'] == ['K-KOH-02'])
check('каталог незмінний', len(catalog) == old_case['каталог'] == 11887, записів=len(catalog))
check('рука 1 як у збереженому ДО', sha(packet['пакети']['1']) == old_case['рука1_sha256'],
      до=old_case['рука1_sha256'], після=sha(packet['пакети']['1']))

def run_case(name, outfit_ids, source_input):
    observed.clear(); consumed.clear()
    before_feed = len(feed_calls)
    verdict = json.loads(Б.виклик('від_моделі', json.dumps(dict(source_input, донор=True, ід=outfit_ids), ensure_ascii=False)))
    assert not verdict.get('помилка'), verdict
    card_ids = verdict['повнота']['ід']
    shadow = relevant(verdict['палітра']['тінь_знахідки'] or [])
    check(name + ': producer зберіг сирий склад', set(card_ids) == set(outfit_ids))
    reviews = [r for r in observed if r['місце'] == 'review' and set(r['повні'] or []) == set(outfit_ids)]
    check(name + ': повний склад передано суду', bool(reviews), викликів=len(reviews))
    check(name + ': нормалізована смуга', reviews and all(r['сцена'].get('діапазон') == (4.0, 6.0) for r in reviews))
    expected = []
    for review in reviews:
        for finding in review['знахідки']:
            if finding.get('ремонт_заяви') and finding.get('суть') == 'target_band':
                expected.append(finding)
    check(name + ': активна зовнішня ціль', expected and all(
        r['ремонт_заяви'][0]['values']['band'] == [3.0, 3.0] and r.get('сила_нп', 0) > 0 for r in expected))
    keys = ('правило', 'речі', 'сила', 'сила_нп', 'суть')
    projected = lambda v: {k:v.get(k) for k in keys}
    for finding in expected:
        check(name + ': точні адресати і метадані в картці', any(projected(s) == projected(finding) for s in shadow),
              адресати=finding['речі'])
    check(name + ': правильна й хибна рекомендації', shadow and all(
        s.get('правильна') == [4.0, 6.0] and s.get('хибна') == [3.0, 3.0] and s.get('дія') == 'target_band'
        for s in shadow))
    check(name + ': контексти відновлено', not П.зламані() and not П.вимкнені() and not П.тінь())
    result = dict(назва=name, сирі=outfit_ids, повнота=card_ids, суди=copy.deepcopy(observed),
                  споживачі=copy.deepcopy(consumed), тінь=shadow,
                  feed_до=before_feed, feed_після=len(feed_calls), кешів=len(М._КЕШ_ПАКЕТА))
    cases.append(result)
    return result

fresh = run_case('повні 5 свіжий', ids, input_data)
cached = run_case('повні 5 кеш', ids, input_data)
check('повтор справді читає кеш каталогу', cached['feed_до'] == cached['feed_після'])
check('тінь свіжого й кешованого результатів однакова', fresh['тінь'] == cached['тінь'])
check('два різні погодні стани по 4 речі', sorted({tuple(s['видимі']) for s in fresh['суди'] if s['місце']=='review'}) ==
      sorted([tuple(sorted(ids[:-1])), tuple(sorted(ids[1:]))]))
full_records = [r for c in fresh['споживачі'] for r in c['вхід'] if r.get('де') == 'judge' and r.get('образ') == sorted(ids)]
check('споживач бачить повні записи', len(full_records) >= 2, записів=len(full_records))
check('порядок ID не змінює тінь', real_consumer(full_records, ids[::-1]) == real_consumer(full_records, ids))
for index in range(len(ids)):
    check('відхилено чужу підмножину ' + str(index), not real_consumer(full_records, ids[:index] + ids[index+1:]))
check('відхилено надмножину', not real_consumer(full_records, ids + ['чужа-річ']))
check('відхилено інший образ тієї самої довжини', not real_consumer(full_records, ['чужа-річ'] + ids[1:]))
subset = run_case('фактичні 4 без пальта', ids[:-1], input_data)
check('інша картка має один погодний стан', {tuple(s['видимі']) for s in subset['суди'] if s['місце']=='review'} == {tuple(sorted(ids[:-1]))})
again = run_case('повні 5 після іншої картки', ids, input_data)
check('сусідня картка не забруднює кеш тіні', again['тінь'] == fresh['тінь'])
warm = dict(input_data, сценарій=dict(input_data['сценарій'], темп_c=25))
warm_case = run_case('повні 5 інша погода', ids, warm)
check('адреса тіні не залежить від температури', warm_case['тінь'] == fresh['тінь'])

proof = dict(sha='6f124d64056eb9458b5b78a86f40dfca8d24ed48', модельних_викликів=0,
             каталог_blob='04d84f5556cf4654f10a594128c3531530773649',
             вхід=input_data, свідки=[dict(id=i, слот=by_id[i]['слот'], смуга=Ф.інтервал_формальності(by_id[i])) for i in ids],
             перевірки=checks, випадки=cases)
(root/'proof'/'producer-результат.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2))
failed=[c for c in checks if not c['пройдено']]
print(json.dumps(dict(перевірок=len(checks), невдалі=failed,
                     тіней=[dict(випадок=c['назва'], кількість=len(c['тінь']), видимі=[len(s['видимі']) for s in c['суди'] if s['місце']=='review']) for c in cases]), ensure_ascii=False), flush=True)
sys.exit(bool(failed))
